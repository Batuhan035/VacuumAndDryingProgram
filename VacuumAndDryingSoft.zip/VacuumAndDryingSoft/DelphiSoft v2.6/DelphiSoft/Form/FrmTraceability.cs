﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//Ini
using Ini;

namespace DelphiSoft
{
    public partial class FrmTraceability : Form
    {
        IniFile ini_config = new IniFile(System.IO.Directory.GetCurrentDirectory() + @"\Config.ini");

        public FrmTraceability()
        {
            InitializeComponent();
        }

       
        
        private void FrmTraceability_Load(object sender, EventArgs e)
        {
            if (GLB.Traceability)
            {
                rad_On1.Checked = true;
                rad_Off1.Checked = false;
                
                led_trace1.Color = Color.FromArgb(153, 255, 54);

            }
            else
            {
                rad_On1.Checked = false;
                rad_Off1.Checked = true;
                led_trace1.Color = Color.Crimson;
            }

           
   
        }

        private void rad_On1_CheckedChanged(object sender, EventArgs e)
        {
            if (rad_On1.Checked)
            {
                led_trace1.Color = Color.FromArgb(153, 255, 54);
                GLB.Traceability = true;
            }
            else
            {
                led_trace1.Color = Color.Crimson;
                GLB.Traceability = false;
            }
            ini_config.IniWriteValue("Traceability", "Status", GLB.Traceability.ToString());

            //Update Trace Status
            FrmMain f1 = (FrmMain)Application.OpenForms["FrmMain"];
            f1.TraceabilityStatus();
        }

      


    }
}
