﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//Ini
using Ini;

namespace DelphiSoft
{
    public partial class FrmOutputs : Form
    {
        //For Stored Procedures
        StoredProcedures SP = new StoredProcedures();


        public FrmOutputs()
        {
            InitializeComponent();
        }


        FrmMain f1 = (FrmMain)Application.OpenForms["FrmMain"];

        private void FrmOutputs_Load(object sender, EventArgs e)
        {
            DataTable  OutputDesc= new DataTable();
            OutputDesc = SP.GetAllOutputs();

            label0.Text = OutputDesc.Rows[0]["Description"].ToString();
            label1.Text = OutputDesc.Rows[1]["Description"].ToString();
            label2.Text = OutputDesc.Rows[2]["Description"].ToString();
            label3.Text = OutputDesc.Rows[3]["Description"].ToString();
            label4.Text = OutputDesc.Rows[4]["Description"].ToString();
            label5.Text = OutputDesc.Rows[5]["Description"].ToString();
            label6.Text = OutputDesc.Rows[6]["Description"].ToString();
            label7.Text = OutputDesc.Rows[7]["Description"].ToString();
            label8.Text = OutputDesc.Rows[8]["Description"].ToString();
            label9.Text = OutputDesc.Rows[9]["Description"].ToString();
            label10.Text = OutputDesc.Rows[10]["Description"].ToString();
            label11.Text = OutputDesc.Rows[11]["Description"].ToString();
            label12.Text = OutputDesc.Rows[12]["Description"].ToString();
            label13.Text = OutputDesc.Rows[13]["Description"].ToString();
            label14.Text = OutputDesc.Rows[14]["Description"].ToString();
            label15.Text = OutputDesc.Rows[15]["Description"].ToString();

            groupBox1.Text = OutputDesc.Rows[0]["IO"].ToString();
            groupBox2.Text = OutputDesc.Rows[1]["IO"].ToString();
            groupBox3.Text = OutputDesc.Rows[2]["IO"].ToString();
            groupBox4.Text = OutputDesc.Rows[3]["IO"].ToString();
            groupBox5.Text = OutputDesc.Rows[4]["IO"].ToString();
            groupBox6.Text = OutputDesc.Rows[5]["IO"].ToString();
            groupBox7.Text = OutputDesc.Rows[6]["IO"].ToString();
            groupBox8.Text = OutputDesc.Rows[7]["IO"].ToString();
            groupBox9.Text = OutputDesc.Rows[8]["IO"].ToString();
            groupBox10.Text = OutputDesc.Rows[9]["IO"].ToString();
            groupBox11.Text = OutputDesc.Rows[10]["IO"].ToString();
            groupBox12.Text = OutputDesc.Rows[11]["IO"].ToString();
            groupBox13.Text = OutputDesc.Rows[12]["IO"].ToString();
            groupBox14.Text = OutputDesc.Rows[13]["IO"].ToString();
            groupBox15.Text = OutputDesc.Rows[14]["IO"].ToString();
            groupBox16.Text = OutputDesc.Rows[15]["IO"].ToString();

            tmr_Output.Enabled = true;

            lbl_Auto.Visible = false;


        }

        private void FrmOutputs_FormClosing(object sender, FormClosingEventArgs e)
        {
            tmr_Output.Enabled = false;
        }

        private void tmr_Output_Tick(object sender, EventArgs e)
        {
            LedRead(ledBulb0, GLB.Q_Vacuum_Start);
            LedRead(ledBulb1, GLB.Q_Blow_Start);
            LedRead(ledBulb2, GLB.Q_Tag_Read_Lamp);
            LedRead(ledBulb3, GLB.Q_Alarm_Lamp);
            LedRead(ledBulb4, GLB.Q_OK_Lamp);
            LedRead(ledBulb5, GLB.Q_Valf_Durum);
            LedRead(ledBulb6, GLB.Output_6);
            LedRead(ledBulb7, GLB.Output_7);

        }

        private  void CheckAuto(GroupBox grp , bool auto)
        {
             if (auto)
            { 
                grp.Enabled= false;
                lbl_Auto.Visible = true;
            }
             else
            {
            grp.Enabled = true;
            lbl_Auto.Visible = false;
            }
        }
        private void LedRead(LedBulb LedName, bool Input)
        {
            if (Input)
            { LedName.Color = Color.FromArgb(153, 255, 54); }
            else
            { LedName.Color = Color.FromArgb(255,128, 128); }
        }

        #region Output Write

        private void ledBulb0_Click(object sender, EventArgs e)
        {
            if (GLB.Q_Vacuum_Start) { GLB.Q_Vacuum_Start = false; }
            else { GLB.Q_Vacuum_Start = true; }
        }

        private void ledBulb1_Click(object sender, EventArgs e)
        {
            if (GLB.Q_Blow_Start) { GLB.Q_Blow_Start = false; }
            else { GLB.Q_Blow_Start = true; }
        }

        private void ledBulb2_Click(object sender, EventArgs e)
        {
            if (GLB.Q_Tag_Read_Lamp) { GLB.Q_Tag_Read_Lamp = false; }
            else { GLB.Q_Tag_Read_Lamp = true; }
        }

        private void ledBulb3_Click(object sender, EventArgs e)
        {
            if (GLB.Q_Alarm_Lamp) { GLB.Q_Alarm_Lamp = false; }
            else { GLB.Q_Alarm_Lamp = true; }
        }

        private void ledBulb4_Click(object sender, EventArgs e)
        {
            if (GLB.Q_OK_Lamp) { GLB.Q_OK_Lamp = false; }
            else { GLB.Q_OK_Lamp = true; }
        }

        private void ledBulb5_Click(object sender, EventArgs e)
        {
            if (GLB.Q_Valf_Durum) { GLB.Q_Valf_Durum = false; }
            else { GLB.Q_Valf_Durum = true; }
        }

        private void ledBulb6_Click(object sender, EventArgs e)
        {
            if (GLB.Output_6) { GLB.Output_6 = false; }
            else { GLB.Output_6 = true; }
        }

        private void ledBulb7_Click(object sender, EventArgs e)
        {
            if (GLB.Output_7) { GLB.Output_7 = false; }
            else { GLB.Output_7 = true; }
        }

        #endregion
    }
}
