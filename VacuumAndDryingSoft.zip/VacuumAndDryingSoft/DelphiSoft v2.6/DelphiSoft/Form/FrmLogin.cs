﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//Ini
using Ini;
//Keyboard Proses
using System.Diagnostics;

namespace DelphiSoft
{
    public partial class FrmLogin : Form
    {
        StoredProcedures SP = new StoredProcedures();
        IniFile ini_config = new IniFile(System.IO.Directory.GetCurrentDirectory() + @"\Config.ini");
       
        
        public FrmLogin()
        {
            InitializeComponent();
        }
        private void FrmLogin_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
        private void FrmLogin_Load(object sender, EventArgs e)
        {
        
            //Check program is already running*************************************************************************
            string RunningProcess = System.Diagnostics.Process.GetCurrentProcess().ProcessName;
            System.Diagnostics.Process[] processes = System.Diagnostics.Process.GetProcessesByName(RunningProcess);
            if (processes.Length > 1)
            {
                MessageBox.Show("Program zaten calisiyor.Yeniden programi acamazsiniz !!!", "Hata !!!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                Application.Exit();
                Application.ExitThread();
            }
            //**********************************************************************************************************
            try
            {
            //Read Sql Connection String
            GLB.Sql_Conn_String = "Data Source=" + ini_config.IniReadValue("SQL","Data_Source") + ";" +
                                               "Password=" + ini_config.IniReadValue("SQL", "Password") + ";" +
                                               "User ID=" + ini_config.IniReadValue("SQL", "User_ID") + ";" +
                                               "Initial Catalog=" + ini_config.IniReadValue("SQL", "Initial_Catalog") + ";" +
                                               "Connection Timeout=" + ini_config.IniReadValue("SQL", "Connection_Timeout");
            //Read Sql Connection String
            GLB.Sql_Conn_String2 = "Data Source=" + ini_config.IniReadValue("Traceability", "Data_Source") + ";" +
                                               "Password=" + ini_config.IniReadValue("Traceability", "Password") + ";" +
                                               "User ID=" + ini_config.IniReadValue("Traceability", "User_ID") + ";" +
                                               "Initial Catalog=" + ini_config.IniReadValue("Traceability", "Initial_Catalog") + ";" +
                                               "Connection Timeout=" + ini_config.IniReadValue("Traceability", "Connection_Timeout");

                //Load Rfid
                GLB.RfidPortName = ini_config.IniReadValue("RFID", "PortName");
                GLB.RfidBaudRate = Convert.ToInt32(ini_config.IniReadValue("RFID", "BaudRate"));



                //Get Traceability Status
                GLB.Traceability = Convert.ToBoolean(ini_config.IniReadValue("Traceability", "Status"));
                GLB.MachineID = Convert.ToInt32(ini_config.IniReadValue("Traceability", "MachineID"));
                GLB.OperationNo = Convert.ToInt32(ini_config.IniReadValue("Traceability", "OperationNo"));
                GLB.FixtureNo = Convert.ToInt32(ini_config.IniReadValue("Traceability", "FixtureNo"));
            }
            catch(Exception ErrorName)
            {
                MessageBox.Show("Ini dosyasinda veri okuma hatasi " + System.Environment.NewLine + System.Environment.NewLine + ErrorName, "Hata", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                Application.Exit();
                Application.ExitThread();
            }

            //Get All Users to Combobox;
            cmb_user_ID.DataSource = SP.GetAllUsers();
            cmb_user_ID.Text = cmb_user_ID.Items[0].ToString();

            //ReadOnly Combobox
            cmb_user_ID.DropDownStyle = ComboBoxStyle.DropDownList;

            //Read Project Info
            SP.SoftwareInfo(GLB.MachineID);
            this.Text = GLB.ProjectName + " | v " + Application.ProductVersion.Substring(0, Application.ProductVersion.Length - 2);

            //DM Variables
            GLB.DM_IP = ini_config.IniReadValue("DM", "IP");
            GLB.DM_Port = Convert.ToInt32(ini_config.IniReadValue("DM", "Port"));

        }
        
        private void btn_Cancel_Click(object sender, EventArgs e)
        {
                Application.Exit();
        }
        private void btn_OK_Click(object sender, EventArgs e)
        { 
            //Get User Name
            GLB.UserName = cmb_user_ID.Text;

            string Temp_UserRights;

            //Get User Password and Right
            if (SP.CheckLogin(cmb_user_ID.Text, txt_password.Text, out Temp_UserRights))
            {return;}
            
            GLB.UserRight=Temp_UserRights;
             //Open Main Form
            this.Hide();
             FrmSplash FormSplash = new FrmSplash();
             FormSplash.Show();
        }
        private void btn_keyboard_Click(object sender, EventArgs e)
        {
            var virtualKeyboard = new System.Diagnostics.Process();
            virtualKeyboard = System.Diagnostics.Process.Start("osk.exe"); // open
            virtualKeyboard.Kill();
        }
    }
}
