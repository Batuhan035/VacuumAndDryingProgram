﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//Ini
using Ini;


namespace DelphiSoft
{

    public partial class FrmManualTag : Form
    {
        IniFile ini_config = new IniFile(System.IO.Directory.GetCurrentDirectory() + @"\Config.ini");

        

        public FrmManualTag()
        {
            InitializeComponent();
        }

        private void FrmManualTag_Load(object sender, EventArgs e)
        {
            if(GLB.TraceabilityType=="Tag")
            {
                btn_read.Text = "Tag Oku";
                btn_read.Visible = true;
                btn_stop.Visible = true;
                btn_write.Visible = true;
            }
            else
            {
                btn_read.Text = "DM Oku";
                btn_read.Visible = false;
                btn_stop.Visible = false;
                btn_write.Visible = false;
            }
        }


        private void btn_clear1_Click(object sender, EventArgs e)
        {
            GLB.RfidReader.RfidValue = "";
            GLB.DM_No="";
        }

        private void Timer1_Tick(object sender, EventArgs e)
        {
        

            if (GLB.TraceabilityType == "Tag")
            {
                txt_TagNo1.Text = GLB.RfidReader.RfidValue;
            }
            else
            {
                txt_TagNo1.Text = GLB.DM_No;
            }
        }

        private void btn_read_Click(object sender, EventArgs e)
        {
            GLB.RfidReader.ReadRFID();
        }

        private void btn_stop_Click(object sender, EventArgs e)
        {
            GLB.RfidReader.StopRFID();
        }

        private void btn_write_Click(object sender, EventArgs e)
        {
            GLB.RfidReader.WriteRFID(txt_TagNo1.Text);
        }
    }
}
