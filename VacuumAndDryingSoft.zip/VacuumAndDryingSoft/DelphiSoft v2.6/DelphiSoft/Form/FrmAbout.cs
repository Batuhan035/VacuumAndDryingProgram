﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//Ini
using Ini;

namespace DelphiSoft
{
    public partial class FrmAbout : Form
    {
        //For Ini Files
        IniFile ini_config = new IniFile(System.IO.Directory.GetCurrentDirectory() + @"\Config.ini");

        public FrmAbout()
        {
            InitializeComponent();
        }

        

        private void FrmAbout_Load(object sender, EventArgs e)
        {
            lbl_name.Text = GLB.ProjectName;
            lbl_author.Text = GLB.ProjectAuthor;
            label3.Text = "v " +Application.ProductVersion.Substring(0, Application.ProductVersion.Length - 2);
           this.FormBorderStyle = FormBorderStyle.FixedDialog;
        }

    
    }
}
