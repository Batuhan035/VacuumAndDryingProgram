﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//Ini
using Ini;
//Text Write
using System.IO;

namespace DelphiSoft
{
    public partial class FrmAddUser : Form
    {
        //For Stored Procedures
        StoredProcedures SP = new StoredProcedures();
        //For Ini Files
        IniFile ini_config = new IniFile(System.IO.Directory.GetCurrentDirectory() + @"\Config.ini");

        //All References
        DataTable all_ref_table = new DataTable();

        //Edit Reference
        string Edit_UserName;

        //OK Buton
        string Button_Task;
        
        public FrmAddUser()
        {
            InitializeComponent();
        }
        private void FrmAddUser_Load(object sender, EventArgs e)
        {
            //Combobox Rights
            cmb_rights.DataSource = SP.GetPermissionRights(GLB.UserRight);
            cmb_rights.DropDownStyle = ComboBoxStyle.DropDownList;
            cmb_rights.SelectedIndex = 0;
            
            //Panel Visible
            groupBox1.Visible = false;
            // Configure the DataGridView so that users can manually change 
            // only the column widths, which are set to fill mode. 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AllowUserToResizeRows = false;
            dataGridView1.RowHeadersWidthSizeMode =  DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridView1.ColumnHeadersHeight = 40;
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;

            //Delete Button
            DataGridViewImageColumn img_delete = new DataGridViewImageColumn();
            Image image_delete = Image.FromFile(System.IO.Directory.GetCurrentDirectory() + @"\images\DeleteButton.png");
            img_delete.Image = image_delete;
            dataGridView1.Columns.Add(img_delete);
            img_delete.HeaderText = "Sil";
            img_delete.Name = "Delete";

            //Edit Button
            DataGridViewImageColumn img_edit = new DataGridViewImageColumn();
            Image image_edit = Image.FromFile(System.IO.Directory.GetCurrentDirectory() + @"\images\EditButton.png");
            img_edit.Image = image_edit;
            dataGridView1.Columns.Add(img_edit);
            img_edit.HeaderText = "Edt";
            img_edit.Name = "Edit";

            
            //Get All References with SP
            dataGridView1.DataSource = SP.GetUserTable();

            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.TopLeftHeaderCell.Style.BackColor = Color.White;
            dataGridView1.Columns[0].HeaderCell.Style.BackColor = Color.White;
            dataGridView1.Columns[1].HeaderCell.Style.BackColor = Color.White;

            dataGridView1.Columns[dataGridView1.ColumnCount - 1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridView1.ClearSelection();
      
        }
        private void dataGridView1_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            //TopLeft Cell
            if (e.RowIndex == -1 && e.ColumnIndex == -1)
            {
                Image img = Image.FromFile(System.IO.Directory.GetCurrentDirectory() + @"\images\AddButton.png");
                e.Paint(e.CellBounds, DataGridViewPaintParts.All & ~DataGridViewPaintParts.ContentForeground);
                e.Graphics.DrawImage(img, e.CellBounds);
                e.Handled = true;
            }
            //Column 0
            if (e.RowIndex == -1 && e.ColumnIndex == 0)
            {
                Image img2 = Image.FromFile(System.IO.Directory.GetCurrentDirectory() + @"\images\DelHeader.png");
                e.Paint(e.CellBounds, DataGridViewPaintParts.All & ~DataGridViewPaintParts.ContentForeground);
                e.Graphics.DrawImage(img2, e.CellBounds);
                e.Handled = true;
            }
            //Column 0
            if (e.RowIndex == -1 && e.ColumnIndex == 1)
            {
                Image img3 = Image.FromFile(System.IO.Directory.GetCurrentDirectory() + @"\images\EditHeader.png");
                e.Paint(e.CellBounds, DataGridViewPaintParts.All & ~DataGridViewPaintParts.ContentForeground);
                e.Graphics.DrawImage(img3, e.CellBounds);
                e.Handled = true;
            }

        }
        private void btn_add_Click(object sender, EventArgs e)
        {
            if (Button_Task == "Add")
            {
                if (SP.AddUser(textBox1.Text, cmb_rights.Text,GLB.UserRight,txt_pass1.Text,txt_pass2.Text)) return;
            }
            else
            {
                if (SP.UpdateUser(Edit_UserName, textBox1.Text,cmb_rights.Text,GLB.UserRight)) return;
            }
            groupBox1.Visible = false;
            dataGridView1.Enabled = true;
            dataGridView1.DataSource = SP.GetUserTable();
            dataGridView1.RowsDefaultCellStyle.SelectionBackColor = Color.PowderBlue;
            this.dataGridView1.ClearSelection();

            

        }
        private void btn_cancel_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
            dataGridView1.Enabled = true;
            dataGridView1.RowsDefaultCellStyle.SelectionBackColor = Color.PowderBlue;
            this.dataGridView1.ClearSelection();
        }
        private void dataGridView1_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            dataGridView1.Columns[0].DefaultCellStyle.SelectionBackColor = Color.White;
            dataGridView1.Columns[1].DefaultCellStyle.SelectionBackColor = Color.White;

            //TopLeft
            if (e.RowIndex == -1 && e.ColumnIndex == -1)
            {
                AddEditSwitch(true);
                dataGridView1.RowsDefaultCellStyle.SelectionBackColor = Color.White;
                groupBox1.Visible = true;
                groupBox1.Text = "Yeni Kullanici Ekle";
                dataGridView1.Enabled = false;
                label1.Text = dataGridView1.Columns[2].HeaderText;
                label2.Text = dataGridView1.Columns[3].HeaderText;
                textBox1.Text = "";
                txt_pass1.Text = "";
                txt_pass2.Text = "";
                Button_Task = "Add";
            }

            //Delete Button Last Column
            if (e.ColumnIndex == 0)
            {
                if (e.RowIndex == -1) return;

                DialogResult sonuc;
                sonuc = MessageBox.Show(dataGridView1.Rows[e.RowIndex].Cells[2].FormattedValue.ToString() + " kullanicisini silmek istediginize emin misiniz ?", "Kullanici Silme Ekrani", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (sonuc == DialogResult.Yes)
                {
                    if (SP.DeleteUser(dataGridView1.Rows[e.RowIndex].Cells[2].FormattedValue.ToString()))
                    { return; }
                    //Get All References with SP
                    dataGridView1.DataSource = SP.GetUserTable();
                }

            }

            //Edit Button
            if (e.ColumnIndex == 1)
            {
                if (e.RowIndex == -1) return;
                AddEditSwitch(false);
                Edit_UserName = dataGridView1.Rows[e.RowIndex].Cells[2].FormattedValue.ToString();
                dataGridView1.RowsDefaultCellStyle.SelectionBackColor = Color.White;
                groupBox1.Visible = true;
                groupBox1.Text = "Kullanici Duzenleme";
                cmb_rights.Text = dataGridView1.Rows[e.RowIndex].Cells[3].FormattedValue.ToString();
                dataGridView1.Enabled = false;
                label1.Text = dataGridView1.Columns[2].HeaderText;
                label2.Text = dataGridView1.Columns[3].HeaderText;
                textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells[2].FormattedValue.ToString();
                Button_Task = "Edit";
            }
                

           
            
   
            
        }
        private void AddEditSwitch(Boolean result)
        {
            label3.Visible = result;
            label4.Visible = result;
            txt_pass1.Visible = result;
            txt_pass2.Visible = result;

            if (result)
            {
                textBox1.Location = new Point(3, 59);
                label1.Location = new Point(6, 40);
                label2.Location = new Point(138, 40);
                cmb_rights.Location = new Point(141, 59);
            }
            else
            {
                textBox1.Location = new Point(96, 59);
                label1.Location = new Point(93, 40);
                label2.Location = new Point(243, 40);
                cmb_rights.Location = new Point(246, 59);
            }
        }
    }
}