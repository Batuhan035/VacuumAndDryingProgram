﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//For Resource
using System.Reflection;
using System.Globalization;
using System.Resources;
//Ini
using Ini;
//Text Write
using System.IO;
//XML
using System.Xml;
//System Diagnostic
using System.Diagnostics;

//TCP
using System.Net;
using System.Net.Sockets;
//Thread
using System.Threading;
//BitArray
using System.Collections;
using DelphiSoft.Classes;

namespace DelphiSoft
{

    public partial class FrmMain : Form
    {
        //Movable=false
        Point defaultLocation;
        //Stored Procedures
        StoredProcedures SP = new StoredProcedures();
        //Adventech
        Adventech Adventech = new Adventech();
        //Ini Files
        IniFile ini_config = new IniFile(Directory.GetCurrentDirectory() + @"\Config.ini");
        //References
        DataTable ref_table = new DataTable();
        //Log Results
        LogResults Log_Class = new LogResults();
        //Alarm Wav
        System.Media.SoundPlayer player = new System.Media.SoundPlayer();

        private System.Timers.Timer _delayTimer;

        //Keyboard
        private string Keyboard = (Directory.GetCurrentDirectory() + @"\Tabtip.exe");
        //Private Variable
        private double CycleTime = 0.0;
        private double PompTime = 0.0;
        private string DBResult = "";
        private string DBError = "";
        private bool DM_Trigger;
        private bool Tag_Trigger;
        private int Vakum_Zamani;
        private int Pompa_Zamani;
        private int Ufleme_Tekrar;
        private bool startButton;
       


        #region Form Main
        public FrmMain()
        {
            InitializeComponent();
            defaultLocation = this.Location;

            // initialize RFID Reader

            GLB.RfidReader = new Rfid();

            GLB.Adventech_Name = ini_config.IniReadValue("Adventech", "Name");


        }


        private void FrmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            //Force Application Exit
            Application.ExitThread();
            Environment.Exit(0);
            Application.Exit();
        }
        private void FrmMain_Move(object sender, EventArgs e)
        {
            this.Location = defaultLocation;
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
            //ResetAllOutputs
            ResetAllOutputs();

            //Reset
            ResetButtonEvent();
            //Load Trace Settings
            GLB.TraceabilityType = "DM";
            TraceType();
            //Load References
            UpdateAllReferences();

            ////Sim
            GLB.Sim_Active = ini_config.IniReadValue("General", "Sim");
            if (GLB.Sim_Active == "true")
            {
                btn_simDM.Visible = true;
                cmb_ref.Text = "28475985";
                //Load Trace Settings
                GLB.TraceabilityType = "Tag";
                TraceType();
                GLB.Sim_I_Emergency_Stop = true;
                GLB.Sim_I_Auto = true;
                lbl_sim.Visible = true;
            }
            else
            {
                btn_simDM.Visible = false;
                lbl_sim.Visible = false;
            }

            if (!GLB.Traceability)
            {
                txt_Tag_No.ReadOnly = true;
                txt_DM_No.ReadOnly = true;
                btn_simDM.Visible = false;
            }
            else
            {
                txt_Tag_No.ReadOnly = false;
                txt_DM_No.ReadOnly = false;
                btn_simDM.Visible = false;
            }
            pic_AudiHPv.Visible = false;
            pic_K9K.Visible = false;
            pic_HPs.Visible = false;
            TraceabilityStatus();
            //Machine Status
            Traffic_Light("yellow");

            //Adventech
            GLB.Adventech_Name = ini_config.IniReadValue("Adventech", "Name");
            GLB.Adventech_Name = ini_config.IniReadValue("Adventech", "Name");
            GLB.Adventech_Name = ini_config.IniReadValue("Adventech", "Name");
            GLB.Adventech_Name = ini_config.IniReadValue("Adventech", "Name");
            if (Adventech.Connect_Adventech() == "OK")
            {

                LedStatus(led_LifeBit, true);
                //tmr_IO.Enabled = true;
            }
            else
            {
                tmr_Adventech.Enabled = false;
                LedStatus(led_LifeBit, false);
                // MessageBox.Show("Adventech modul baglanti hatasi. Program Kapanacaktir!!!","Baglanti Hatasi");
                // Application.Exit();
                return;
                //tmr_IO.Enabled = false;
            }


            //Size
            this.ClientSize = new System.Drawing.Size(1920, 1080);
            //Load Rights
            Load_Rights();
            //Load Caption
            this.Text = GLB.ProjectName + " | v " + Application.ProductVersion.Substring(0, Application.ProductVersion.Length - 2);
            lbl_Author.Text = "designed by " + GLB.ProjectAuthor + " | " + GLB.ProjectDate;
            //Load User Name
            lbl_username.Text = GLB.UserName;
            lbl_userright.Text = GLB.UserRight;
            lbl_userdate.Text = DateTime.Now.ToString().Substring(0, 16);
            //Load Counter Values
            lbl_OK.Text = ini_config.IniReadValue("Counter", "OK");
            GLB.CountOK = Convert.ToInt32(lbl_OK.Text);
            lbl_NOK.Text = ini_config.IniReadValue("Counter", "NOK");
            GLB.CountNOK = Convert.ToInt32(lbl_NOK.Text);
            lbl_TOTAL.Text = ini_config.IniReadValue("Counter", "TOTAL");
            GLB.CountTOTAL = Convert.ToInt32(lbl_TOTAL.Text);
            //Load Reset Time
            lbl_reset_time.Text = ini_config.IniReadValue("General", "ResetTime");
            //Alarm Wav File
            player.SoundLocation = System.IO.Directory.GetCurrentDirectory() + @"\sound\alarm.wav";
            GLB.FixtureNo =Convert.ToInt32( ini_config.IniReadValue("Traceability", "FixtureNo"));
            //System Ready
            GLB.Step = 3;
            //Cycle Timer enable
            tmr_cycle.Enabled = true;

            //Avoid Null
            //GLB.RfidReader.RfidValue = "";

        }
        #endregion
        #region Menu Items
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (GLB.I_Auto)
            {
                MessageBox.Show("Programi sadece manuel modda kapatabilirsiniz", "Exit", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            DialogResult sonuc;
            sonuc = MessageBox.Show("Programi kapatmak istediginize emin misiniz ?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (sonuc == DialogResult.Yes)
            {
                Application.Exit();
            }
            else
            {
                return;
            }

        }
        private void kullanıcıEkleKaldırToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmAddUser FrmAdd = new FrmAddUser();
            FrmAdd.Show();
        }
        private void şifreDeğiştirmeToolStripMenuItem_Click(object sender, EventArgs e)
        {

            FrmPassword FormPassword = new FrmPassword();
            FormPassword.Show();
        }
        private void kullanıcıDeğiştirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult sonuc;

            sonuc = MessageBox.Show("Kullanici degistirmek istediginize emin misiniz ?", "Kullanici Degistir", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (sonuc == DialogResult.Yes)
            {
                System.Diagnostics.Process.Start(Application.ExecutablePath);

                Process soft_process = Process.GetCurrentProcess();
                soft_process.Kill();
                soft_process.Dispose();
            }


        }
        private void ManualMenuItem_Click(object sender, EventArgs e)
        {
            FrmManualTag FrmTag = new FrmManualTag();
            FrmTag.Show();
        }
        private void permissionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmPermissions FrmPer = new FrmPermissions();
            FrmPer.Show();
        }
        private void hakkındaToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmAbout FormAbout = new FrmAbout();
            FormAbout.Show();
        }
        private void fileToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        private void referanslarıGörüntüleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (GLB.I_Auto)
            {
                MessageBox.Show("Referansları sadece manuel modda degistirebilirsiniz", "Referans Degistirme", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            else
            {
              
                    FrmRefSettings FormRefSettings = new FrmRefSettings();
                    FormRefSettings.Show();
               
            }

        }
        private void kontrolSonuçlarıToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmQuery FormQuery = new FrmQuery();
            FormQuery.Show();
        }
        private void hesapMakinesiToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("calc");
        }
        private void notDefteriToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("notepad");
        }
        private void sanalKlavyeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            KeyboardKill();
            Process.Start("osk");
        }
        private void IzlenebilirlikToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (GLB.I_Auto)
            {
                MessageBox.Show("İzlenebilirlik ayarini sadece manuel modda degistirebilirsiniz", "İzlenebilirlik", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            else
            {
                FrmTraceability FormTraceability = new FrmTraceability();
                FormTraceability.Show();
            }
        }
        private void KeyboardKill()
        {
            Process[] _proceses = null;
            _proceses = Process.GetProcessesByName("TabTip");
            foreach (Process proces in _proceses)
            {
                proces.Kill();
            }
        }

        private void DMReadToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
        private void konfigurasyonToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (GLB.I_Auto)
            {
                MessageBox.Show("Database ayarini sadece manuel modda degistirebilirsiniz", "Database", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            else
            {
                FrmDBSettings FormDBSettings = new FrmDBSettings();
                FormDBSettings.Show();
            }
        }
        private FrmInputs FormInputs;
        private void InputsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (FormInputs == null)
            {
                FormInputs = new FrmInputs();
                FormInputs.Show();
                return;
            }

            if (FormOpen(FormInputs))
            {
                Invoke(new Action(() => { FormInputs.WindowState = FormWindowState.Normal; }));
                FormInputs.BringToFront();
                return;
            }
            else
            {
                FormInputs = new FrmInputs();
                FormInputs.Show();
            }


        }
        private FrmOutputs FormOutputs;
        private void outputsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (FormOutputs == null)
            {
                FormOutputs = new FrmOutputs();
                FormOutputs.Show();
                return;
            }

            if (FormOpen(FormOutputs))
            {
                Invoke(new Action(() => { FormOutputs.WindowState = FormWindowState.Normal; }));
                FormOutputs.BringToFront();
                return;
            }
            else
            {
                FormOutputs = new FrmOutputs();
                FormOutputs.Show();
            }

        }

        #endregion
        #region Timers
        private void tmr_datentime_Tick(object sender, EventArgs e)
        {
            
            //Date time
            DateTime dt = DateTime.Now;
            lbl_date.Text = String.Format("{0:dd/MM/yyyy }", dt) + " |";
            lbl_time.Text = String.Format("{0:HH:mm:ss}", dt);

            if (GLB.Step == 45)
            {
                Vakum_Zamani++;
            }
            
            else
            {
                Vakum_Zamani = 0;
            }
            if (GLB.Step == 55 || GLB.Step >= 12 && GLB.Step <=15)
            {
                Pompa_Zamani++;
            }
           else if (GLB.Step == 49 || GLB.Step == 23 && !GLB.I_Cycle_Start)
            {
                Pompa_Zamani++;
            }
            else
            {
                Pompa_Zamani = 0;
            }
            
        }
        private void tmr_cycle_Tick(object sender, EventArgs e)
        {
            //Adventech
            Adventech.Adventech_DI();
            Adventech.Adventech_DO();
            //Visual
            Visual_Control();
            //AutoCycle
            AutoCycle();
            //Update Info panel
            UpdateInfo();
            //Calculate Cycle Time
          
            CalcCyleTime();
           
        }
        #endregion
        #region Events
        private void btn_count_reset_Click(object sender, EventArgs e)
        {
            DialogResult sonuc;

            sonuc = MessageBox.Show("Sayaci sifirlamak istediginize emin misiniz ?", "Sayac Onay", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (sonuc == DialogResult.Yes)
            {
                //Count OK
                GLB.CountOK = 0;
                ini_config.IniWriteValue("Counter", "OK", "0");

                GLB.CountNOK = 0;
                ini_config.IniWriteValue("Counter", "NOK", "0");

                GLB.CountTOTAL = 0;
                ini_config.IniWriteValue("Counter", "TOTAL", "0");

                //Write Reset Time
                lbl_reset_time.Text = Convert.ToString(DateTime.Now);
                ini_config.IniWriteValue("General", "ResetTime", Convert.ToString(DateTime.Now));
                Log_Class.Send_Log("OK: " + lbl_OK.Text+" NOK: "+lbl_NOK.Text +" TOPLAM: " + lbl_TOTAL.Text , "Sayac Reset");

                lbl_OK.Text = "0";
                lbl_NOK.Text = "0";
                lbl_TOTAL.Text = "0";

            }
        }
        private void btn_count_reset_MouseDown(object sender, MouseEventArgs e)
        {
            btn_count_reset.Image = Image.FromFile(Directory.GetCurrentDirectory() + @"\images\reset_on.png");
        }
        private void btn_count_reset_MouseLeave(object sender, EventArgs e)
        {
            btn_count_reset.Image =Image.FromFile(Directory.GetCurrentDirectory() + @"\images\reset_off.png");
        }
        private void btn_reset_MouseDown(object sender, MouseEventArgs e)
        {
            ResetMouseDown();
        }
        private void btn_reset_MouseUp(object sender, MouseEventArgs e)
        {
            ResetMouseUp();
        }
        private void cmb_ref_MouseClick(object sender, MouseEventArgs e)
        {
            if (GLB.I_Auto)
            {
                MessageBox.Show("Referans secimi sadece manuelde yapilabilir !!", "Referans Secimi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
        }

        private void cmb_ref_SelectedIndexChanged(object sender, EventArgs e)
        {
          
            
            if (cmb_ref.SelectedValue.ToString() !="")
            {
              
;            //Get current reference parameters
            DataTable Dt_Ref = new DataTable();
            Dt_Ref = SP.GetSingleReference(GLB.MachineID, GLB.OperationNo, GLB.FixtureNo, cmb_ref.Text);
            //Get Global Ref
           

            GLB.Ref_Desc = Dt_Ref.Rows[0][5].ToString();
            GLB.Ref_Desc1 = Dt_Ref.Rows[0][6].ToString();
            GLB.Ref_Val1 = Dt_Ref.Rows[0][7].ToString();
            GLB.Ref_Desc2 = Dt_Ref.Rows[0][8].ToString();
            GLB.Ref_Val2 = Dt_Ref.Rows[0][9].ToString();
            GLB.Ref_Desc3 = Dt_Ref.Rows[0][10].ToString();
            GLB.Ref_Val3 = Dt_Ref.Rows[0][11].ToString();
            GLB.Ref_Desc4 = Dt_Ref.Rows[0][12].ToString();
            GLB.Ref_Val4 = Dt_Ref.Rows[0][13].ToString();
            GLB.Ref_Desc5 = Dt_Ref.Rows[0][14].ToString();
            GLB.Ref_Val5 = Dt_Ref.Rows[0][15].ToString();

             lbl_refdesc.Text = GLB.Ref_Desc;
            grp_desc1.Text = GLB.Ref_Desc1;
            grp_desc2.Text = GLB.Ref_Desc2;
            grp_desc3.Text = GLB.Ref_Desc3;
            grp_desc4.Text = GLB.Ref_Desc4;
                grp_desc5.Text = GLB.Ref_Desc5;
                lbl_refval1.Text = GLB.Ref_Val1;
                lbl_refval2.Text = GLB.Ref_Val2;
                lbl_refval3.Text = GLB.Ref_Val3;
                lbl_refval4.Text = GLB.Ref_Val4;
                lbl_refval5.Text = GLB.Ref_Val5;

            }
            else if(cmb_ref.SelectedValue.ToString() == "228478555")
                {
               
                
                DataTable Dt_Ref = new DataTable();
                Dt_Ref = SP.GetSingleReference(GLB.MachineID, GLB.OperationNo, GLB.FixtureNo, cmb_ref.Text);
                //Get Global Ref
                pic_AudiHPv.Visible = true;

                GLB.Ref_Desc = Dt_Ref.Rows[0][5].ToString();
                GLB.Ref_Desc1 = Dt_Ref.Rows[0][6].ToString();
                GLB.Ref_Val1 = Dt_Ref.Rows[0][7].ToString();
                GLB.Ref_Desc2 = Dt_Ref.Rows[0][8].ToString();
                GLB.Ref_Val2 = Dt_Ref.Rows[0][9].ToString();
                GLB.Ref_Desc3 = Dt_Ref.Rows[0][10].ToString();
                GLB.Ref_Val3 = Dt_Ref.Rows[0][11].ToString();
                GLB.Ref_Desc4 = Dt_Ref.Rows[0][12].ToString();
                GLB.Ref_Val4 = Dt_Ref.Rows[0][13].ToString();
                GLB.Ref_Desc5 = Dt_Ref.Rows[0][14].ToString();
                GLB.Ref_Val5 = Dt_Ref.Rows[0][15].ToString();

                lbl_refdesc.Text = GLB.Ref_Desc;
                grp_desc1.Text = GLB.Ref_Desc1;
                grp_desc2.Text = GLB.Ref_Desc2;
                grp_desc3.Text = GLB.Ref_Desc3;
                grp_desc4.Text = GLB.Ref_Desc4;
                lbl_refval1.Text = GLB.Ref_Val1;
                lbl_refval2.Text = GLB.Ref_Val2;
                lbl_refval3.Text = GLB.Ref_Val3;
                lbl_refval4.Text = GLB.Ref_Val4;
                lbl_refval5.Text = GLB.Ref_Val5;
            }
            else if(cmb_ref.SelectedValue.ToString() == "28475985")
            {
                 
                
                DataTable Dt_Ref = new DataTable();
                Dt_Ref = SP.GetSingleReference(GLB.MachineID, GLB.OperationNo, GLB.FixtureNo, cmb_ref.Text);
                //Get Global Ref

                pic_K9K.Visible = true;
                GLB.Ref_Desc = Dt_Ref.Rows[0][5].ToString();
                GLB.Ref_Desc1 = Dt_Ref.Rows[0][6].ToString();
                GLB.Ref_Val1 = Dt_Ref.Rows[0][7].ToString();
                GLB.Ref_Desc2 = Dt_Ref.Rows[0][8].ToString();
                GLB.Ref_Val2 = Dt_Ref.Rows[0][9].ToString();
                GLB.Ref_Desc3 = Dt_Ref.Rows[0][10].ToString();
                GLB.Ref_Val3 = Dt_Ref.Rows[0][11].ToString();
                GLB.Ref_Desc4 = Dt_Ref.Rows[0][12].ToString();
                GLB.Ref_Val4 = Dt_Ref.Rows[0][13].ToString();
                GLB.Ref_Desc5 = Dt_Ref.Rows[0][14].ToString();
                GLB.Ref_Val5 = Dt_Ref.Rows[0][15].ToString();
                
                lbl_refdesc.Text = GLB.Ref_Desc;
                grp_desc1.Text = GLB.Ref_Desc1;
                grp_desc2.Text = GLB.Ref_Desc2;
                grp_desc3.Text = GLB.Ref_Desc3;
                grp_desc4.Text = GLB.Ref_Desc4;
                lbl_refval1.Text = GLB.Ref_Val1;
                lbl_refval2.Text = GLB.Ref_Val2;
                lbl_refval3.Text = GLB.Ref_Val3;
                lbl_refval4.Text = GLB.Ref_Val4;
                lbl_refval5.Text = GLB.Ref_Val5;
            }
        }
        private void btn_DMConnect_Click(object sender, EventArgs e)
        {
           
        }
        private void btn_TAGDM_Click(object sender, EventArgs e)
        {

            TraceType();
        }

#endregion
            #region MachineCycle
        private void AutoCycle()
        {

            //Sıradaki Tag-DM Kısmı
            if (GLB.Step >= 45 && GLB.Step < 55)
            {
                if (GLB.TraceabilityType == "DM")
                {
                    txt_Tag2_No.Text = GLB.DM_No;
                    if (txt_DM2_No.Text != "")
                    {
                        if (!SP.DatamatrixToTag(cmb_ref.Text, txt_DM2_No.Text, ref GLB.TagNo))
                        {
                            MessageBox.Show("DatamatrixToTag Stored Procedure", "Stored procedure Hatasi", MessageBoxButtons.AbortRetryIgnore);
                        }
                        else
                        {
                            txt_Tag2_No.Text = GLB.TagNo;
                        }
                    }
                }

                else
                {
                    if (!Tag_Trigger)
                    {
                        GLB.RfidReader.ReadRFID();
                    }
                    Tag_Trigger = true;
                    txt_Tag2_No.Text = GLB.RfidReader.RfidValue;
                }
            }


            if (GLB.I_Alarm_Reset)
            {
                GLB.Q_Vacuum_Start = false;
                GLB.Q_Blow_Start = false;
            }
            
            //Valf Ac-Kapat Durumu
            if(GLB.I_Part_Presence)
            {
                GLB.Q_Valf_Durum = true;
            }
            else
            {
                GLB.Q_Valf_Durum = false;
            }

            //Pompa Calısma Suresı Izlenebilirlik Acık
            if (GLB.Step == 55 || GLB.Step >=12 && GLB.Step <=15)
            {
                lbl_pomp_saniye.Visible = true;
                lbl_pomp_time.Visible = true;
                GLB.Q_Blow_Start = false;
                lbl_pomp_time.Text = (Convert.ToInt32(lbl_refval3.Text) - Pompa_Zamani).ToString();

                if (Convert.ToInt32(lbl_pomp_time.Text) <= 0)
                {
                    lbl_pomp_saniye.Visible = false;
                    lbl_pomp_time.Visible = false;
                    GLB.Q_Vacuum_Start = false;
                    GLB.Q_Blow_Start = false;
                }
            }

            //Pompa Calisma Suresı Izlenebılırlık Kapalı
            else if (GLB.Step == 49 || GLB.Step == 23 && !GLB.I_Part_Presence)
            {
                lbl_pomp_saniye.Visible = true;
                lbl_pomp_time.Visible = true;
                GLB.Q_Blow_Start = false;
                lbl_pomp_time.Text = (Convert.ToInt32(lbl_refval3.Text) - Pompa_Zamani).ToString();

                if (Convert.ToInt32(lbl_pomp_time.Text) <= 0)
                {
                    lbl_pomp_saniye.Visible = false;
                    lbl_pomp_time.Visible = false;
                    GLB.Q_Vacuum_Start = false;
                    GLB.Q_Blow_Start = false;
                }
            }
            else

            {
                lbl_pomp_saniye.Visible = false;
                lbl_pomp_time.Visible = false;
            }

           
           
          
            if (GLB.Step > 1 && GLB.Step < 49 && !GLB.Traceability)
            {
                Traffic_Light("yellow");
            }
            if (GLB.Step > 1 && GLB.Step < 55 && GLB.Traceability)
            {
                Traffic_Light("yellow");
               
            }
            if (GLB.Step > 999)
            {
                Traffic_Light("red");
            }
            //OilTank Level
            if (!GLB.I_OilTank)
            {
                GLB.Alarm = true;
                GLB.Step = 1015;
            }

            //Termik İkaz Uyarisi
            if(GLB.I_Termik_Ikaz)
            {
                GLB.Alarm = true;
                GLB.Step = 1017;
                GLB.Q_Blow_Start = false;
                GLB.Q_Vacuum_Start=false;
            }
            //Emergency Stop
            if (!GLB.I_Emergency_Stop) { GLB.Emergency_Alarm = true; }

            //Step 0 Emergency Stop
            StepJump(!GLB.I_Emergency_Stop, 0);
            if (GLB.Step == 0)
            {
                
                txt_Tag_No.Text = "";
                txt_Tag_No.ReadOnly = true;
                txt_Tag2_No.Text = "";
                txt_Tag_No.ReadOnly = true;
                GLB.RfidReader.RfidValue = "";
                txt_Tag_No.BackColor = Color.White;
                GLB.DM_No = "";
                GLB.Q_Blow_Start = false;
                GLB.Q_Vacuum_Start = false;
               

            }
            //Step 1 Emergency Stop
            StepJump(GLB.I_Emergency_Stop && GLB.Emergency_Alarm, 1);
            //Step 2 Manual
            StepJump(GLB.I_Emergency_Stop && !GLB.Emergency_Alarm && !GLB.I_Auto, 2);
            //Step 3 Auto Check
            StepJump(GLB.Step == 2 && GLB.I_Auto, 3);
            //Step 6 Auto Reference Check
            StepJump(GLB.Step == 3 && cmb_ref.Text == "", 6);

            //Step 7 Auto Machine Unload
            StepJump(GLB.Step > 2 && GLB.Step < 20 && GLB.I_Part_Presence, 7);
            //Step 10 Auto Ready
            StepJump(!GLB.Emergency_Alarm && GLB.I_Auto && !GLB.I_Part_Presence && cmb_ref.Text != "" && GLB.Step < 25, 10);

            //Step 12 Traceability ON
            StepJump(GLB.Step == 10 && GLB.Traceability && GLB.Step < 25, 12);
           
            //Step 12 Tag Label Clear
            if (GLB.Step == 12 && !GLB.I_Tag_Sensor && GLB.Step < 25)
            {
               // lbl_pomp_time.Text = (Convert.ToInt32(lbl_refval3.Text) - Pompa_Zamani).ToString();
                txt_Tag_No.Text = "";
                GLB.RfidReader.RfidValue = "";
                txt_Tag_No.BackColor = Color.White;
                GLB.DM_No = "";
                txt_DM_No.Text = "";
               
            }

            //Step 12 Tag is reading
            StepJump(GLB.Step == 12 && GLB.I_Tag_Sensor && GLB.Step < 25, 15);
            StepJump(GLB.Step == 15 && !GLB.I_Tag_Sensor && GLB.Step < 25, 12);
          
            //DM to TAG Read
            if (GLB.Step == 15)
            {

                if (GLB.TraceabilityType == "DM")
                {
                    txt_DM_No.Text = GLB.DM_No;
                    if (txt_DM_No.Text != "")
                    {
                        if (!SP.DatamatrixToTag(cmb_ref.Text, txt_DM_No.Text, ref GLB.TagNo))
                        {
                            MessageBox.Show("DatamatrixToTag Stored Procedure", "Stored procedure Hatasi", MessageBoxButtons.AbortRetryIgnore);
                        }
                        else
                        {
                            txt_Tag_No.Text = GLB.TagNo;
                        }

                    }
                }
                else
                {
                    if (!Tag_Trigger)
                    {
                        GLB.RfidReader.ReadRFID();
                    }
                    Tag_Trigger = true;
                    txt_Tag_No.Text = GLB.RfidReader.RfidValue;
                }
            }


            //Tag Trigger
            if (GLB.Step != 15)
            {
                Tag_Trigger = false;
            }
            
            
            //Step 20 Tag is read
            StepJump(GLB.Step == 15 && txt_Tag_No.Text.Length == 16, 20);

          
            //Step 25 Request For Operation
            if (GLB.Step == 20 && GLB.I_Tag_Sensor)
            {
                if (GLB.DM_No !="")
                {

                
                    GLB.TraceResult = SP.RequestForOperation(cmb_ref.Text, GLB.MachineID, txt_Tag_No.Text, GLB.OperationNo, "");

                    //Trace OK
                    if (GLB.TraceResult.Substring(0, 3) == "10:" || GLB.TraceResult.Substring(0, 3) == "15:")
                    {
                        GLB.Step = 25;
                        txt_Tag_No.BackColor = Color.Lime;
                        //Start Cycle
                        GLB.Q_Tag_Read_Lamp = true;
                    }
                    //Step 1001 - Trace NOK
                    else
                    {
                        GLB.Step = 1004;
                        txt_Tag_No.BackColor = Color.Red;
                    }
                }
            }
            

            //Step23 Traceability OFF
            StepJump(GLB.Step == 10 && !GLB.Traceability, 23);
         
            //Step 30 Part Kontrol

            StepJump(GLB.Step == 25 && GLB.I_Part_Presence, 30);
            StepJump(GLB.Step == 30 && !GLB.I_Part_Presence && GLB.Traceability, 25);
            StepJump(GLB.Step == 30 && !GLB.I_Part_Presence && !GLB.Traceability, 23);

            StepJump(GLB.Step == 23 && GLB.I_Part_Presence, 30);
            StepJump(GLB.Step == 49 && !GLB.I_Part_Presence, 7);
            StepJump(GLB.Step == 55 && !GLB.I_Part_Presence, 7);
            
            //Step 31 first remove the part from tag reader
            StepJump(GLB.Step == 30 && GLB.I_Part_Presence && GLB.I_Tag_Sensor, 31);
            StepJump(GLB.Step == 31 && GLB.I_Part_Presence && !GLB.I_Tag_Sensor, 30);

            //Step 40
            StepJump(GLB.Step == 30 && GLB.I_Part_Presence && GLB.I_Cycle_Start && !GLB.I_Tag_Sensor, 40);

            //Step 45 Vacuum/Blowing Start
            StepJump(GLB.Step == 40, 45);
            if (GLB.Step == 45)
            {
                GLB.Q_Vacuum_Start = true;
                if (!tmr_blow.Enabled) { GLB.Q_Blow_Start = true; }
                if (Convert.ToInt32(lbl_refval2.Text) == 0 && !tmr_blow.Enabled) { GLB.Q_Blow_Start = false; }
                else
                {
                    tmr_blow.Enabled = true;
                    tmr_blow.Interval = Convert.ToInt32(lbl_refval2.Text) * 1000;
                }
                    lbl_vacuum_saniye.Visible = true;
                lbl_vacuum_time.Visible = true;
                lbl_vacuum_time.Text = (Convert.ToInt32(lbl_refval1.Text) - Vakum_Zamani).ToString();

               

                if (Vakum_Zamani >= Convert.ToInt32(lbl_refval1.Text))
                {
                    GLB.Step = 50;
                }
            
                if (Vakum_Zamani >= Convert.ToInt32(lbl_refval1.Text) && !GLB.Traceability)
                {
                    GLB.Step = 46;
                }
            }
            else
            {
               
                    lbl_vacuum_saniye.Visible = false;
                    lbl_vacuum_time.Visible = false;
                    tmr_blow.Enabled = false;
            }


                ////Part is removed during the cycle
                if (GLB.Step > 25 && GLB.Step < 55 && !GLB.I_Part_Presence && GLB.Traceability)
                {
                    //GLB.Emergency_Alarm = false;
                    Log_LocalDB("NOK", "Islem sirasinda parca alindi");
                    GLB.Step = 1006;
                    GLB.Q_Blow_Start = false;
                    GLB.Q_Vacuum_Start = false;
            }
                if (GLB.Step > 25 && GLB.Step < 49 && !GLB.I_Part_Presence && !GLB.Traceability)
                {
                    GLB.Step = 1006;
                    GLB.Q_Blow_Start = false;
                    GLB.Q_Vacuum_Start = false;
                }
                if (GLB.Step > 25 && GLB.Step < 49 && !GLB.I_Part_Presence && !GLB.Traceability)
                {
                    //GLB.Emergency_Alarm = false;
                    //Log_LocalDB("NOK", "Islem sirasinda parca alindi");
                    GLB.Step = 1006;
                }
                
            ////Step46 Trace Off
            if (GLB.Step == 46)
            {
                {
                    CountParts(1);
                    GLB.Step = 49;
                }

                //Step49 Trace Off 
                if (GLB.Step == 49)
                {
                    Traffic_Light("green");
                }
            }

            //Step 50 Local 
            if (GLB.Step == 50)
                {
                    try
                    {
                        Log_LocalDB("OK", "No Error");
                        GLB.Step = 51;

                    }
                    catch (Exception ex)
                    {
                        GLB.TraceResult = ex.ToString();
                        GLB.Step = 1001;
                        return;
                    }

                }
            

            //Step 51 Log Operation
            if (GLB.Step == 51)
            {
                try
                {
                    SP.LogOperation(cmb_ref.Text, txt_Tag_No.Text, GLB.OperationNo, GLB.MachineID, "PASS",GLB.FixtureNo, 0, "No Error",null);
                    GLB.Step = 52;
                }
                catch (Exception ex)
                {
                    GLB.TraceResult = ex.ToString();
                    GLB.Step = 1002;
                    return;
                }
            }

            //Step 52 Log Data
            if (GLB.Step == 52 && GLB.Traceability)
            {

                Double[] Log_Val = new Double[22];

                if (lbl_refval1.Text == "" || lbl_refval1.Text == null)
                {
                    Log_Val[1] = 0.0;
                }
                else
                {
                    Log_Val[1] = Convert.ToDouble(lbl_refval1.Text);
                }

                if (lbl_refval2.Text == "" || lbl_refval2.Text == null)
                {
                    Log_Val[2] = 0.0;
                }
                else
                {
                    Log_Val[2] = Convert.ToDouble(lbl_refval2.Text);
                }
                if (lbl_refval3.Text == "" || lbl_refval3.Text == null)
                {
                    Log_Val[3] = 0.0;
                }
                else
                {
                    Log_Val[3] = Convert.ToDouble(lbl_refval3.Text);
                }
                if (lbl_refval4.Text == "" || lbl_refval4.Text == null)
                {
                    Log_Val[4] = 0.0;
                }
                else
                {
                    Log_Val[4] = Convert.ToDouble(lbl_refval4.Text);
                }
                //if (lbl_refval5.Text == "" || lbl_refval5.Text == null)
                //{
                //    Log_Val[5] = 0.0;
                //}
                //else
                //{
                //    Log_Val[5] = Convert.ToDouble(lbl_refval5.Text);
                //}
                //if (lbl_refval6.Text == "" || lbl_refval6.Text == null)
                //{
                //    Log_Val[6] = 0.0;
                //}
                //else
                //{
                //    Log_Val[6] = Convert.ToDouble(lbl_refval6.Text);
                //}
                //if (lbl_refval7.Text == "" || lbl_refval7.Text == null)
                //{
                //    Log_Val[7] = 0.0;
                //}
                //else
                //{
                //    Log_Val[7] = Convert.ToDouble(lbl_refval7.Text);
                //}
                //if (lbl_refval8.Text == "" || lbl_refval8.Text == null)
                //{
                //    Log_Val[8] = 0.0;
                //}
                //else
                //{
                //    Log_Val[8] = Convert.ToDouble(lbl_refval8.Text);
                //}
                //if (lbl_refval9.Text == "" || lbl_refval9.Text == null)
                //{
                //    Log_Val[9] = 0.0;
                //}
                //else
                //{
                //    Log_Val[9] = Convert.ToDouble(lbl_refval9.Text);
                //}
                //if (lbl_refval10.Text == "" || lbl_refval10.Text == null)
                //{
                //    Log_Val[10] = 0.0;
                //}
                //else
                //{
                //    Log_Val[10] = Convert.ToDouble(lbl_refval10.Text);
                //}
                //if (lbl_refval11.Text == "" || lbl_refval11.Text == null)
                //{
                //    Log_Val[11] = 0.0;
                //}
                //else
                //{
                //    Log_Val[11] = Convert.ToDouble(lbl_refval11.Text);
                //}
                //if (lbl_refval12.Text == "" || lbl_refval12.Text == null)
                //{
                //    Log_Val[12] = 0.0;
                //}
                //else
                //{
                //    Log_Val[12] = Convert.ToDouble(lbl_refval12.Text);
                //}
                //if (lbl_refval13.Text == "" || lbl_refval13.Text == null)
                //{
                //    Log_Val[13] = 0.0;
                //}
                //else
                //{
                //    Log_Val[13] = Convert.ToDouble(lbl_refval13.Text);
                //}
                //if (lbl_refval14.Text == "" || lbl_refval14.Text == null)
                //{
                //    Log_Val[14] = 0.0;
                //}
                //else
                //{
                //    Log_Val[14] = Convert.ToDouble(lbl_refval14.Text);
                //}
                //if (lbl_refval15.Text == "" || lbl_refval15.Text == null)
                //{
                //    Log_Val[15] = 0.0;
                //}
                //else
                //{
                //    Log_Val[15] = Convert.ToDouble(lbl_refval15.Text);
                //}
                //if (lbl_refval16.Text == "" || lbl_refval16.Text == null)
                //{
                //    Log_Val[16] = 0.0;
                //}
                //else
                //{
                //    Log_Val[16] = Convert.ToDouble(lbl_refval16.Text);
                //}
                //if (lbl_refval17.Text == "" || lbl_refval17.Text == null)
                //{
                //    Log_Val[17] = 0.0;
                //}
                //else
                //{
                //    Log_Val[17] = Convert.ToDouble(lbl_refval17.Text);
                //}
                //if (lbl_refval18.Text == "" || lbl_refval18.Text == null)
                //{
                //    Log_Val[18] = 0.0;
                //}
                //else
                //{
                //    Log_Val[18] = Convert.ToDouble(lbl_refval18.Text);
                //}
                //if (lbl_refval19.Text == "" || lbl_refval19.Text == null)
                //{
                //    Log_Val[19] = 0.0;
                //}
                //else
                //{
                //    Log_Val[19] = Convert.ToDouble(lbl_refval19.Text);
                //}
                //if (lbl_refval20.Text == "" || lbl_refval20.Text == null)
                //{
                //    Log_Val[20] = 0.0;
                //}
                //else
                //{
                //    Log_Val[20] = Convert.ToDouble(lbl_refval20.Text);
                //}
                //if (lbl_refval21.Text == "" || lbl_refval21.Text == null)
                //{
                //    Log_Val[21] = 0.0;
                //}
                //else
                //{
                //    Log_Val[21] = Convert.ToDouble(lbl_refval21.Text);
                //}


                try
                {
                    SP.LogData(GLB.OperationNo, txt_Tag_No.Text, GLB.MachineID,
                        grp_desc1.Text, Log_Val[1],
                        grp_desc2.Text, Log_Val[2],
                        grp_desc3.Text, Log_Val[3],
                        grp_desc4.Text, Log_Val[4],
                        grp_desc5.Text, Log_Val[5],
                        //grp_desc6.Text, Log_Val[6],
                        //grp_desc7.Text, Log_Val[7],
                        //grp_desc8.Text, Log_Val[8],
                        //grp_desc9.Text, Log_Val[9],
                        //grp_desc10.Text, Log_Val[10],
                        //grp_desc11.Text, Log_Val[11],
                        //grp_desc12.Text, Log_Val[12],
                        //grp_desc13.Text, Log_Val[13],
                        //grp_desc14.Text, Log_Val[14],
                        //grp_desc15.Text, Log_Val[15],
                        //grp_desc16.Text, Log_Val[16],
                        //grp_desc17.Text, Log_Val[17],
                        //grp_desc18.Text, Log_Val[18],
                        //grp_desc19.Text, Log_Val[19],
                        //grp_desc20.Text, Log_Val[20],
                        //grp_desc21.Text, Log_Val[21],

                        "", "",
                        "Kullanici Adi", GLB.UserName,
                        "User Right", GLB.UserRight);


                    GLB.Step = 53;
                }

                catch (Exception ex)
                {
                    GLB.TraceResult = ex.ToString();
                    GLB.Step = 1003;
                    return;
                }



                //Step 53 Count
                if (GLB.Step == 53)
                {
                    CountParts(1);
                    GLB.Step = 55;
                }

                if (GLB.Step > 1 && GLB.Step < 55 && GLB.Traceability)
                {
                    Traffic_Light("yellow");
                }
               
                //Step 55 Part OK
                if (GLB.Step == 55)
                {
                    GLB.DM_No = "";
                    Traffic_Light("green");
                    
                }


                if (GLB.Step > 999)
                {
                    Traffic_Light("red");

                }
            }
           
        }
        private void Visual_Control()
        {
            //Reset Button
            if (GLB.I_Alarm_Reset) { ResetButtonEvent(); }
            //Vacuum
            if (GLB.Q_Vacuum_Start) { OnOffSwitch(pic_Vac_On, pic_Vac_Off, true); } else { OnOffSwitch(pic_Vac_On, pic_Vac_Off, false); }
            //Blow
            if (GLB.Q_Blow_Start) { OnOffSwitch(pic_blow_on, pic_blow_off, true); } else { OnOffSwitch(pic_blow_on, pic_blow_off, false); }
            //Step
            lbl_step.Text =GLB.Step.ToString();
            lbl_step_cycle.Text = GLB.Step.ToString();
            //Part Presence
            if (GLB.I_Part_Presence) { LedStatus(led_PartPresence, true); } else { LedStatus(led_PartPresence, false); }
            //Auto Presence
            if (GLB.I_Auto)
            {
                LedStatus(led_auto_button, true);
                cmb_ref.Enabled = false;
                btn_TagDM.Enabled = false;
            }
            else
            {
                LedStatus(led_auto_button, false);
                cmb_ref.Enabled = true;
                btn_TagDM.Enabled = true;
            }
            //Tag Presence
            if (GLB.I_Tag_Sensor) { LedStatus(led_TagPresent, true); } else { LedStatus(led_TagPresent, false); }
            //DM Presence
            if (GLB.I_Tag_Sensor) { LedStatus(led_DMPresent, true); } else { LedStatus(led_DMPresent, false); }
            //DM Presence
            if (GLB.Step>=10) { LedStatus(ledAuto, true); } else { LedStatus(ledAuto, false); }
            //Cycle Start
            if (GLB.I_Cycle_Start) { LedStatus(led_startbutton, true); } else { LedStatus(led_startbutton, false); }
            //Alarm Reset
            if (GLB.I_Alarm_Reset) { LedStatus(led_resetbutton, true); } else { LedStatus(led_resetbutton, false); }
            //OK Lamp
            if (GLB.Q_OK_Lamp) { LedStatus(led_OKLamp, true); } else { LedStatus(led_OKLamp, false); }
            //NOK Lamp
            if (GLB.Q_Alarm_Lamp) { LedStatus(led_NOKLamp, true); } else { LedStatus(led_NOKLamp, false); }

        }
        public void UpdateInfo()
        {
            lbl_step.Text = GLB.Step.ToString();
            switch (GLB.Step)
            {
                case 0:
                    Info_Panel("Acil Stop Basılı !!!", 0);
                    break;
                case 1:
                    //Emergency Reset
                    Info_Panel("Acil stop kaldırıldı. Reset butonuna basınız.", 0);
                    break;
                case 2:
                    Info_Panel("Tezgah manuel konumda", 2);
                    break;
                case 3:
                    Info_Panel("Otomatik şartlar kontrol ediliyor...", 2);
                    break;
                case 4:
                    Info_Panel("Otomatik mod için GR silindiri yukarıda olmalıdır !!!", 2);
                    break;
                case 5:
                    Info_Panel("Otomatik mod için kapı açık olmalıdır !!!", 2);
                    break;
                case 6:
                    Info_Panel("Otomatik mod için referans seçmelisiniz !!!", 2);
                    break;
                case 7:
                    Info_Panel("Baslamak icin parcayi aliniz !!!", 2);
                    break;
                case 10:
                    Info_Panel("Otomatik hazır", 2);
                    break;
                case 12:
                    Info_Panel("Parçayı "+ GLB.TraceabilityType + " okuyucuya koyunuz...", 2);
                    break;
                case 15:
                    Info_Panel(GLB.TraceabilityType+" okunuyor...", 2);
                    break;
                case 20:
                    Info_Panel(GLB.TraceabilityType+" numarasi okutuldu...", 2);
                    break;
                case 21:
                    Info_Panel("Request for operation", 2);
                    break;
                case 22:
                    Info_Panel("izlenebilirlik cevabi bekleniyor", 2);
                    break;
                case 23:
                    Info_Panel("İzlenebilirlik kapalı. Parçayı koyunuz!!!", 2);
                    break;
                case 25:
                    Info_Panel(txt_Tag_No.Text + " tag numarali parcayi baglayabilirsiniz...", 2);
                    break;
                case 30:
                    Info_Panel("Parca yuklendi. Start butonuna basiniz...", 2);
                    break;
                case 31:
                    Info_Panel("Tag okuyucudan rayı aliniz...", 2);
                    break;
                case 40:
                    Info_Panel("Start verildi islem basliyor...", 2);
                    break;
                case 45:
                    Info_Panel("Vakum ve ufleme calisiyor...", 2);
                    break;
                case 49:
                    Info_Panel("İslem basarili. Parcayi alabilirsiniz...", 1);
                    break;
                case 50:
                    Info_Panel("İslem basarili. Lokal veriler kaydediliyor...", 2);
                    break;
                case 51:
                    Info_Panel("İslem basarili. SP Log Operation yapiliyor...", 2);
                    break;
                case 52:
                    Info_Panel("İslem basarili. SP Log Data yapiliyor...", 2);
                    break;
                case 55:
                    Info_Panel("İslem basarili. Parcayi alabilirsiniz...", 1);
                    break;
                case 86:
                    Info_Panel("", 1);
                    break;
                case 87:
                    Info_Panel("", 1);
                    break;
                case 88:
                    Info_Panel("", 1);
                    break;
                case 89:
                    Info_Panel("", 1);
                    break;
                case 90:
                    Info_Panel("", 1);
                    break;
                case 91:
                    Info_Panel("", 1);
                    break;
                case 1000:
                    Info_Panel("Acil Stop Basili", 0);
                    break;
                case 1001:
                    Info_Panel("Lokal veri tabanına veriler kaydedilemedi !!! "+ GLB.TraceResult, 0);
                    break;
                case 1002:
                    Info_Panel("İzlenebilirlik log operation hatasi !!! " + GLB.TraceResult, 0);
                    break;
                case 1003:
                    Info_Panel("İzlenebilirlik log data hatasi !!! " + GLB.TraceResult, 0);
                    break;
                case 1004:
                    Info_Panel("İzlenebilirlik onay vermedi.  " + "Reset Butonuna Basiniz..."+ GLB.TraceResult, 0);
                    break;
                case 1005:
                    Info_Panel("Reset butonuna basilarak islem durduruldu !!!", 0);
                    break;
                case 1006:
                    Info_Panel( "Parca alinarak islem durduruldu !!!", 0);
                    break;
                case 1007:
                    Info_Panel("Adventech module ulasilamiyor !!!", 0);
                    break;
                case 1008:
                    Info_Panel("Adventech modul takildi. Lütfen reset butonuna basiniz !!!", 0);
                    break;
                case 1009:
                    Info_Panel("İzlenebilirlik kapali oldugu icin kayit yapilamadi", 0);
                    break;
                case 1015:
                    Info_Panel("Yag tanki dolu. Lutfen tanki bosaltip reset butonuna basiniz !!!", 0);
                    break;
                case 1016:
                    Info_Panel("Tezgah islem yapiyor...", 1);
                    break;
                case 1017:
                    Info_Panel("Termik Ikaz ve Hava Hatası!!! Lutfen Termik Acip Reset butonuna basiniz...", 0);
                    break;
                case 1018:
                    Info_Panel("", 0);
                    break;
                case 1019:
                    Info_Panel("", 0);
                    break;
                case 1020:
                    Info_Panel("Kapı aynı anda hem açık hem kapalı olamaz. Kapı sensörlerini kontrol ediniz !!!", 0);
                    break;
                case 1050:
                    Info_Panel("Torklama sonucu NOK...Reset tusuna basarak parcayi aliniz ", 0);
                    break;
                case 1051:
                    Info_Panel("Torklama sonucu alinamadi...Reset tusuna basarak parcayi aliniz ", 0);
                    break;
                case 1052:
                    Info_Panel("Hata onaylandi...Reset tusuna basarak parcayi aliniz ", 0);
                    break;
                case 1053:
                    Info_Panel("Bu parça test parçasıdır.Bu parçayı test operasyonu için ayırınız !!!", 0);
                    break;
            }

            
            //Global alarm
            if (GLB.Step > 1000) { GLB.Alarm = true; }
        }
            #endregion
            #region Functions
        public bool FormOpen(Form Frm)
        {
            foreach (Form form in Application.OpenForms)
                if (Frm.Name == form.Name)
                    return true;
            return false;
        }
        public void Info_Panel(string info_text, int color_no)
        {
            lbl_info.Text = info_text;

            if (color_no == 0)
            {
                lbl_info.BackColor = Color.Red;
            }
            else if (color_no == 1)
            {
                lbl_info.BackColor = Color.Lime;
            }
            else if (color_no == 2)
            {
                lbl_info.BackColor = Color.Yellow;
            }
        }
       
        public void UpdateAllReferences()
        {
            lbl_refdesc.Text = "-";
            lbl_refval1.Text = "-";
            lbl_refval2.Text = "-";
            delphiHelper.FillCombobox(cmb_ref,SP.GetReferenceNames(GLB.FixtureNo), "ReferenceName", "ReferenceName");
           // cmb_ref.DataSource = SP.GetReferenceNames(GLB.FixtureNo);
            cmb_ref.Text = "";
            cmb_ref.DropDownStyle = ComboBoxStyle.DropDownList;
        }
        public void CountParts(int Result)
        {
            //Write ini
            string file_path = System.IO.Directory.GetCurrentDirectory() + @"\Config.ini";
            IniFile ini = new IniFile(file_path);
            if (Result==1)
            {
                GLB.CountOK++;
            }
            else
            {
                GLB.CountNOK++;
            }
         
            
            //Count Total
            GLB.CountTOTAL = GLB.CountOK + GLB.CountNOK;
            ini.IniWriteValue("Counter", "TOTAL", Convert.ToString(GLB.CountTOTAL));

            lbl_OK.Text = Convert.ToString(GLB.CountOK);
            lbl_NOK.Text = Convert.ToString(GLB.CountNOK);
            lbl_TOTAL.Text = Convert.ToString(GLB.CountTOTAL);
        }
        public void Load_Rights()
        {
            //Execute Rights
            foreach (DataRow dtRow in SP.GetUserRight(GLB.UserName).Rows)
            {
                try
                {
                    if (string.IsNullOrEmpty(dtRow[1].ToString()))
                    {
                        menuStrip1.Items[dtRow[0].ToString()].Enabled = false;

                    }
                    else
                    {
                        ToolStripMenuItem mn_item = menuStrip1.Items[dtRow[0].ToString()] as ToolStripMenuItem;
                        mn_item.DropDownItems[dtRow[1].ToString()].Enabled = false;
                    }
                }
                catch(Exception error)
                {
                    MessageBox.Show(error.ToString(),"Kullanıcı izinleri yüklenirken hata oluştu",MessageBoxButtons.OK,MessageBoxIcon.Hand);
                }
            }
        }
        public void Log_LocalDB(string Result, string Error)
        {
                SP.LogResults(txt_Tag_No.Text, txt_DM_No.Text, GLB.OperationNo, GLB.FixtureNo, Result, Error, cmb_ref.Text, grp_desc1.Text, lbl_refval1.Text, grp_desc2.Text, lbl_refval2.Text, grp_desc3.Text, lbl_refval3.Text, grp_desc4.Text, lbl_refval4.Text,grp_desc5.Text,lbl_refval5.Text, GLB.UserName, GLB.UserRight);


            }
            public void LedStatus(LedBulb Led,bool ColorCode)
        {
            if(ColorCode)
            {
                Led.Color = Color.FromArgb(153, 255, 54); 
            } 
            else 
            {
                Led.Color = Color.Crimson; 
            }
        }
        private void ResetButtonEvent()
        {
            GLB.Emergency_Alarm = false;

            //Reset
            if (GLB.Step>999)
            {
                GLB.RfidReader.RfidValue = "";
                txt_Tag_No.Text = "";
                txt_Tag_No.BackColor = Color.White;
                GLB.Step = 0;
            }

            if(GLB.Alarm || GLB.I_Auto)
            {
                GLB.RfidReader.RfidValue = "";
                txt_Tag_No.Text = "";
                txt_Tag_No.BackColor = Color.White;
             
               
            }

            if (GLB.Step == 55 && GLB.I_Part_Presence)
            {
                Info_Panel("islem basarili...Resetlemek icin once parcayi almalisiniz...",1);
            }
            if (GLB.Step == 49 && GLB.I_Part_Presence && !GLB.Traceability)
            {
                Info_Panel("islem basarili...Resetlemek icin once parcayi almalisiniz...", 1);
            }
          
            if (GLB.Step>25 && GLB.Step<55 && GLB.I_Part_Presence && GLB.Traceability)
            {
                Log_LocalDB("NOK","Islem sirasinda resete basildi");
                GLB.Step = 1005;
            }
            if (GLB.Step > 25 && GLB.Step < 49 && GLB.I_Part_Presence && !GLB.Traceability)
            {
                GLB.Step = 1005;
            }
           
            //Alarm Stop
            player.Stop();

            //Reset Global Variables
            GLB.Alarm = false;
        }
        private void ResetMouseDown()
        {
            btn_reset.Image = System.Drawing.Image.FromFile(@System.IO.Directory.GetCurrentDirectory() + @"\images\alarm_on.png");
        }
        private void ResetMouseUp()
        {
            btn_reset.Image = System.Drawing.Image.FromFile(@System.IO.Directory.GetCurrentDirectory() + @"\images\alarm_off.png");
            ResetButtonEvent();
        }
        public void ResetAllOutputs()
        {
            GLB.Q_Vacuum_Start = false;
            GLB.Q_Blow_Start = false;
            GLB.Q_Tag_Read_Lamp = false;
            GLB.Q_Alarm_Lamp = false;
            GLB.Q_OK_Lamp = false;
            GLB.Q_Valf_Durum = false;
            GLB.Output_6 = false;
            GLB.Output_7 = false;
        }
        public void StepJump(bool Condition,int IfStep)
        {
            if (Condition)
            {
               GLB.Step=IfStep;
            }
        }
        private void CalcCyleTime()
        {
            //Calculate Cycle Time
            if (GLB.Step > 40 && !GLB.Alarm )
            {
                CycleTime = CycleTime + Convert.ToDouble(tmr_cycle.Interval)/1000.0;
            }
            else if (GLB.Step <= 40)
            {
                CycleTime = 0.0;
            }
            else
            {
                return;
            }
            
        }

        public void TraceabilityStatus()
        {
            IniFile ini_config = new IniFile(System.IO.Directory.GetCurrentDirectory() + @"\Config.ini");
            //ST1
            if (GLB.Traceability)
            {
                //LedStatus(ledTraceability, true);
                lbl_Traceability1.Text = "Izlenebilirlik Acik";
                pic_NoDBConnect.Visible = false;
            }
            else
            {
                //LedStatus(ledTraceability, false);
                lbl_Traceability1.Text = "Izlenebilirlik Kapali";
                pic_NoDBConnect.Visible = true;
                //ledTraceability.Color = Color.Crimson;
            }

            //Reset system
            ResetButtonEvent();
        }
        private void OnOffSwitch(PictureBox PicOn, PictureBox PicOff, bool Active)
    {
       if (Active)
        {
            PicOn.Visible = true;
            PicOff.Visible = false;
        }
       else
        {
            PicOn.Visible = false;
            PicOff.Visible = true;
        }
    }
        private void TraceType()
        {
            if (GLB.TraceabilityType == "Tag")
            {
                grp_Tag.Enabled = false;
                grp_DM.Enabled = true;
                GLB.TraceabilityType = "DM";
                btn_TagDM.Text = "DM Aktif";
                pic_tag.Visible = false;
                pic_DM.Visible = true;
                //Connect DM Reader

                DMTcpConnect();
               
            }
            else
            {
                grp_Tag.Enabled = true;
                grp_DM.Enabled = false;
                GLB.TraceabilityType = "Tag";
                btn_TagDM.Text = "TAG Aktif";
                pic_tag.Visible = true;
                pic_DM.Visible = false;
            }
        }
        private void Traffic_Light(string Light)
        {
            if(Light=="green")
            {
                pic_green.Visible = true;
                pic_yellow.Visible = false;
                pic_red.Visible = false;
                lbl_result.Text = "Sonuc OK";
            }
            else if (Light == "yellow")
            {
                pic_green.Visible = false;
                pic_yellow.Visible = true;
                pic_red.Visible = false;
                lbl_result.Text = "Tezgah islem yapiyor";
            }
            else if (Light == "red")
            {
                pic_green.Visible = false;
                pic_yellow.Visible = false;
                pic_red.Visible = true;
                lbl_result.Text = "Sonuc NOK";
            }
        }

            #endregion


            #region DM Tcp Socket Method
        //DM Variables
        private byte[] data = new byte[1024];
        private int size = 1024;
        private string DMTcpResult = "";
        private IPEndPoint iep = new IPEndPoint(IPAddress.Parse(GLB.DM_IP), Convert.ToInt32(GLB.DM_Port));

        private void DMTcpConnect()
        {
            Socket DMSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

            DMSocket.BeginConnect(iep, new AsyncCallback(DMTcpConnected), DMSocket);

           // Thread.Sleep(1000);

            //DM Status
            if (((DMSocket.Poll(Convert.ToInt32(GLB.DM_Port), SelectMode.SelectRead) && (DMSocket.Available == 0)) || !DMSocket.Connected))
            {
                GLB.DM_Status = "DM okuycu ile baglanti kurulamadi" + iep.ToString();
                //MessageBox.Show("DM kamera ile haberlesme saglanamadi.Kablolarini kontrol ediniz !!!", "Haberleşeme Hatası", MessageBoxButtons.OK, MessageBoxIcon.Error);
               
            }
            else
            {

                GLB.DM_Status = "OK";
               // MessageBox.Show("DM Kamera Haberleşmesi Tamam.");
               
            }
        }
        private void DMTcpConnected(IAsyncResult iar)
        {
            Socket client = (Socket)iar.AsyncState;

            client = (Socket)iar.AsyncState;
            try
            {
                //client.EndConnect(iar);
                client.BeginReceive(data, 0, size, SocketFlags.None, new AsyncCallback(DMTcpReceiveData), client);

            }
            catch (SocketException e)
            {
                GLB.DM_Status = "DM Okuyucu Hata : " + e;
            }

        }
        private void DMTcpReceiveData(IAsyncResult iar)
        {
            Socket remote = (Socket)iar.AsyncState;

            //Get Data
            try
            {
                int recv = remote.EndReceive(iar);
                DMTcpResult = Encoding.ASCII.GetString(data, 0, recv);
                //Trim Data
                DMTcpResult = DMTcpResult.Replace(Environment.NewLine, "");
            }
            catch (Exception hata)
            {
                MessageBox.Show("DM Hata : " + hata);
            }

            //Get Data
            if (!GLB.Alarm )
            {
                GLB.DM_No = DMTcpResult;
            }
            DMTcpConnect();
        }

            #endregion

        private void Btn_simDM_Click(object sender, EventArgs e)
        {
            GLB.DM_No = "VakumDenemeSil";
        }

        private void Tmr_blow_Tick(object sender, EventArgs e)
        {

            GLB.Q_Blow_Start = !GLB.Q_Blow_Start;
        }

        private void Label13_Click(object sender, EventArgs e)
        {

        }

        private void Tmr_Pomp_Tick(object sender, EventArgs e)
        {
           
        }

        private void Pic_rail_Click(object sender, EventArgs e)
        {

        }

        private void PictureBox5_Click(object sender, EventArgs e)
        {

        }
    }
}