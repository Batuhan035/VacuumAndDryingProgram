﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DelphiSoft
{
    public partial class FrmPassword : Form
    {
        //For Stored Procedures
        StoredProcedures SP = new StoredProcedures();
     
        public FrmPassword()
        {
            InitializeComponent();
        }

        private void FrmPassword_Load(object sender, EventArgs e)
        {
            groupBox4.Text = GLB.UserName;
        }

        private void btn_change_Click(object sender, EventArgs e)
        {
            //Change Password
            if (SP.ChangePassword(GLB.UserName, txt_oldpass.Text, txt_pass.Text, txt_pass_r.Text))
            { return; }

            MessageBox.Show("Şifreniz başarıyla değiştirildi", "Bilgi !!!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            this.Close();
        }
       
    }
}
