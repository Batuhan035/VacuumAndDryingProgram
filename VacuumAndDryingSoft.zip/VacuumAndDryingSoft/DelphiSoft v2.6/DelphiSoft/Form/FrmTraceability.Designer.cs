﻿namespace DelphiSoft
{
    partial class FrmTraceability
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmTraceability));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.led_trace1 = new DelphiSoft.LedBulb();
            this.rad_Off1 = new System.Windows.Forms.RadioButton();
            this.rad_On1 = new System.Windows.Forms.RadioButton();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.led_trace1);
            this.groupBox1.Controls.Add(this.rad_Off1);
            this.groupBox1.Controls.Add(this.rad_On1);
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox1.ForeColor = System.Drawing.Color.Crimson;
            this.groupBox1.Location = new System.Drawing.Point(40, 37);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(454, 197);
            this.groupBox1.TabIndex = 11;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = " Izlenebilirlik Durumu";
            // 
            // led_trace1
            // 
            this.led_trace1.Location = new System.Drawing.Point(315, 70);
            this.led_trace1.Name = "led_trace1";
            this.led_trace1.On = true;
            this.led_trace1.Size = new System.Drawing.Size(77, 84);
            this.led_trace1.TabIndex = 2;
            this.led_trace1.Text = "ledBulb1";
            // 
            // rad_Off1
            // 
            this.rad_Off1.AutoSize = true;
            this.rad_Off1.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rad_Off1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.rad_Off1.Location = new System.Drawing.Point(51, 128);
            this.rad_Off1.Name = "rad_Off1";
            this.rad_Off1.Size = new System.Drawing.Size(117, 37);
            this.rad_Off1.TabIndex = 1;
            this.rad_Off1.TabStop = true;
            this.rad_Off1.Text = "Kapali";
            this.rad_Off1.UseVisualStyleBackColor = true;
            // 
            // rad_On1
            // 
            this.rad_On1.AutoSize = true;
            this.rad_On1.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rad_On1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.rad_On1.Location = new System.Drawing.Point(51, 61);
            this.rad_On1.Name = "rad_On1";
            this.rad_On1.Size = new System.Drawing.Size(89, 37);
            this.rad_On1.TabIndex = 0;
            this.rad_On1.TabStop = true;
            this.rad_On1.Text = "Acik";
            this.rad_On1.UseVisualStyleBackColor = true;
            this.rad_On1.CheckedChanged += new System.EventHandler(this.rad_On1_CheckedChanged);
            // 
            // FrmTraceability
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.ClientSize = new System.Drawing.Size(574, 287);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmTraceability";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Izlenebilirlik Ayarlari";
            this.TopMost = true;
            this.Load += new System.EventHandler(this.FrmTraceability_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private LedBulb led_trace1;
        private System.Windows.Forms.RadioButton rad_Off1;
        private System.Windows.Forms.RadioButton rad_On1;

    }
}