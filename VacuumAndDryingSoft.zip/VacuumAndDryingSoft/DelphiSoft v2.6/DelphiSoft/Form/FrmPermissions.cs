﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//Ini
using Ini;
//Text Write
using System.IO;

namespace DelphiSoft
{
    public partial class FrmPermissions : Form
    {
        //For Stored Procedures
        StoredProcedures SP = new StoredProcedures();
        //For Ini Files
        IniFile ini_config = new IniFile(System.IO.Directory.GetCurrentDirectory() + @"\Config.ini");


        public FrmPermissions()
        {
            InitializeComponent();
        }
        private void FrmPermissions_Load(object sender, EventArgs e)
        {
            //Get All Rights to Combobox;
            cmb_rights.DataSource = SP.GetPermissionRights(GLB.UserRight);
            cmb_rights.Text = cmb_rights.Items[0].ToString();
            //ReadOnly Combobox
            cmb_rights.DropDownStyle = ComboBoxStyle.DropDownList;

            //Get All References with SP
            dataGridView1.DataSource = SP.GetPermissions(cmb_rights.Text);

            // Configure the DataGridView so that users can manually change 
            // only the column widths, which are set to fill mode. 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AllowUserToResizeRows = false;
            dataGridView1.RowHeadersWidthSizeMode =  DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridView1.ColumnHeadersHeight = 40;
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;

            //Column Editing
            dataGridView1.Columns[0].ReadOnly = true;
            dataGridView1.Columns[2].ReadOnly = true;

            dataGridView1.EnableHeadersVisualStyles = false;
            dataGridView1.TopLeftHeaderCell.Style.BackColor = Color.White;

            dataGridView1.Columns[dataGridView1.ColumnCount - 1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridView1.ClearSelection();

            this.dataGridView1.Columns[2].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
      
        }

        private void cmb_rights_SelectedIndexChanged(object sender, EventArgs e)
        {
            dataGridView1.DataSource = SP.GetPermissions(cmb_rights.Text);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DialogResult sonuc;

            sonuc = MessageBox.Show(cmb_rights.Text + " yetkisini guncellemek istediginize emin misiniz ?", "Izin Guncelleme Ekrani", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (sonuc != DialogResult.Yes)
            {
                return;
            }

            foreach (DataGridViewRow dtRow in dataGridView1.Rows)
            {
                if (SP.UpdatePermissions(cmb_rights.Text, Convert.ToInt32(dtRow.Cells[0].Value.ToString()), Convert.ToBoolean(dtRow.Cells[1].Value.ToString())))
                {
                    return;
                }
            }

            MessageBox.Show(cmb_rights.Text + " izinleri basariyla guncellendi", "izin bilgi ekrani", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}