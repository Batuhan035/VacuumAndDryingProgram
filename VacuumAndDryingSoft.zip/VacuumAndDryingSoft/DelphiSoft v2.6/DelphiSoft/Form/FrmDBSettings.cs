﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//Ini
using Ini;

namespace DelphiSoft
{
    public partial class FrmDBSettings : Form
    {
        IniFile ini_config = new IniFile(System.IO.Directory.GetCurrentDirectory() + @"\Config.ini");

        public FrmDBSettings()
        {
            InitializeComponent();
        }
        
        private void FrmDBSettings_Load(object sender, EventArgs e)
        {
           
                txt_l_datasource.Text = ini_config.IniReadValue("SQL", "Data_Source");
                txt_l_catalog.Text = ini_config.IniReadValue("SQL", "Initial_Catalog");
                txt_l_user.Text = ini_config.IniReadValue("SQL", "User_ID");
                txt_l_password.Text = ini_config.IniReadValue("SQL", "Password");
                txt_l_password.PasswordChar = '*';
                txt_l_timeout.Text = ini_config.IniReadValue("SQL", "Connection_Timeout");

                txt_t_datasource.Text = ini_config.IniReadValue("Traceability", "Data_Source");
                txt_t_catalog.Text = ini_config.IniReadValue("Traceability", "Initial_Catalog");
                txt_t_user.Text = ini_config.IniReadValue("Traceability", "User_ID");
                txt_t_password.Text = ini_config.IniReadValue("Traceability", "Password");
                txt_t_password.PasswordChar = '*';
                txt_t_timeout.Text = ini_config.IniReadValue("Traceability", "Connection_Timeout");

                this.ShowIcon = false;
                this.ShowInTaskbar = false;
                this.BackColor = Color.Lavender;
                this.TopMost = true;
                this.MinimizeBox = false;
                this.MaximizeBox = false;
                this.FormBorderStyle = FormBorderStyle.FixedDialog;
                //Load Rights
                if (GLB.UserRight != "admin")
                {
                    // Hide the tab page
                    tabControl1.TabPages.Remove(tabPage2);
                }
        }

        private void btn_cancel_loc_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_add_loc_Click(object sender, EventArgs e)
        {
            DialogResult sonuc;
            sonuc = MessageBox.Show("Lokal DB ayarlarini guncellemek istediginize emin misiniz ?", "Lokal DB Guncelleme Ekrani", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (sonuc == DialogResult.Yes)
                {
                    ini_config.IniWriteValue("SQL", "Data_Source", txt_l_datasource.Text);
                    ini_config.IniWriteValue("SQL", "Initial_Catalog", txt_l_catalog.Text);
                    ini_config.IniWriteValue("SQL", "User_ID", txt_l_user.Text);
                    ini_config.IniWriteValue("SQL", "Password", txt_l_password.Text);
                    ini_config.IniWriteValue("SQL", "Connection_Timeout", txt_l_timeout.Text);
                }
        }

        private void btn_add_t_Click(object sender, EventArgs e)
        {
            DialogResult sonuc;
            sonuc = MessageBox.Show("izlenebilirlik DB ayarlarini guncellemek istediginize emin misiniz ?", "izlenebilirlik DB Guncelleme Ekrani", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (sonuc == DialogResult.Yes)
            {
                ini_config.IniWriteValue("Traceability", "Data_Source", txt_t_datasource.Text);
                ini_config.IniWriteValue("Traceability", "Initial_Catalog", txt_t_catalog.Text);
                ini_config.IniWriteValue("Traceability", "User_ID", txt_t_user.Text);
                ini_config.IniWriteValue("Traceability", "Password", txt_t_password.Text);
                ini_config.IniWriteValue("Traceability", "Connection_Timeout", txt_t_timeout.Text);
            }
        }
        
    }
}
