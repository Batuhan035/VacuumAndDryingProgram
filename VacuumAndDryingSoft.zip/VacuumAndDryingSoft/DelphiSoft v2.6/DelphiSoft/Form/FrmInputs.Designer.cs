﻿namespace DelphiSoft
{
    partial class FrmInputs
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmInputs));
            this.tmr_Input = new System.Windows.Forms.Timer(this.components);
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label0 = new System.Windows.Forms.Label();
            this.ledBulb0 = new DelphiSoft.LedBulb();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.ledBulb1 = new DelphiSoft.LedBulb();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.ledBulb2 = new DelphiSoft.LedBulb();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.ledBulb3 = new DelphiSoft.LedBulb();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.ledBulb4 = new DelphiSoft.LedBulb();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.label5 = new System.Windows.Forms.Label();
            this.ledBulb5 = new DelphiSoft.LedBulb();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.label6 = new System.Windows.Forms.Label();
            this.ledBulb6 = new DelphiSoft.LedBulb();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.label7 = new System.Windows.Forms.Label();
            this.ledBulb7 = new DelphiSoft.LedBulb();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.ledBulb8 = new DelphiSoft.LedBulb();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.ledBulb9 = new DelphiSoft.LedBulb();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.label10 = new System.Windows.Forms.Label();
            this.ledBulb10 = new DelphiSoft.LedBulb();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.label11 = new System.Windows.Forms.Label();
            this.ledBulb11 = new DelphiSoft.LedBulb();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.ledBulb12 = new DelphiSoft.LedBulb();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.label13 = new System.Windows.Forms.Label();
            this.ledBulb13 = new DelphiSoft.LedBulb();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.label14 = new System.Windows.Forms.Label();
            this.ledBulb14 = new DelphiSoft.LedBulb();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.label15 = new System.Windows.Forms.Label();
            this.ledBulb15 = new DelphiSoft.LedBulb();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox6.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.groupBox12.SuspendLayout();
            this.groupBox13.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.SuspendLayout();
            // 
            // tmr_Input
            // 
            this.tmr_Input.Tick += new System.EventHandler(this.tmr_Input_Tick);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label0);
            this.groupBox1.Controls.Add(this.ledBulb0);
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox1.ForeColor = System.Drawing.Color.OrangeRed;
            this.groupBox1.Location = new System.Drawing.Point(27, 10);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(300, 50);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Input 0";
            // 
            // label0
            // 
            this.label0.AutoSize = true;
            this.label0.ForeColor = System.Drawing.Color.Black;
            this.label0.Location = new System.Drawing.Point(16, 19);
            this.label0.Name = "label0";
            this.label0.Size = new System.Drawing.Size(128, 16);
            this.label0.TabIndex = 2;
            this.label0.Text = "Tag Varlik Sensoru";
            // 
            // ledBulb0
            // 
            this.ledBulb0.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ledBulb0.Location = new System.Drawing.Point(248, 13);
            this.ledBulb0.Name = "ledBulb0";
            this.ledBulb0.On = true;
            this.ledBulb0.Size = new System.Drawing.Size(45, 35);
            this.ledBulb0.TabIndex = 0;
            this.ledBulb0.Text = "ledBulb1";
            this.ledBulb0.Click += new System.EventHandler(this.LedBulb0_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Controls.Add(this.ledBulb1);
            this.groupBox2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox2.ForeColor = System.Drawing.Color.OrangeRed;
            this.groupBox2.Location = new System.Drawing.Point(27, 70);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(300, 50);
            this.groupBox2.TabIndex = 2;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Input 1";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(16, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(128, 16);
            this.label1.TabIndex = 2;
            this.label1.Text = "Tag Varlik Sensoru";
            // 
            // ledBulb1
            // 
            this.ledBulb1.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ledBulb1.Location = new System.Drawing.Point(248, 13);
            this.ledBulb1.Name = "ledBulb1";
            this.ledBulb1.On = true;
            this.ledBulb1.Size = new System.Drawing.Size(45, 35);
            this.ledBulb1.TabIndex = 0;
            this.ledBulb1.Text = "ledBulb2";
            this.ledBulb1.Click += new System.EventHandler(this.LedBulb1_Click);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label2);
            this.groupBox3.Controls.Add(this.ledBulb2);
            this.groupBox3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox3.ForeColor = System.Drawing.Color.OrangeRed;
            this.groupBox3.Location = new System.Drawing.Point(27, 130);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(300, 50);
            this.groupBox3.TabIndex = 3;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Input 2";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(16, 29);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(128, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Tag Varlik Sensoru";
            // 
            // ledBulb2
            // 
            this.ledBulb2.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ledBulb2.Location = new System.Drawing.Point(248, 13);
            this.ledBulb2.Name = "ledBulb2";
            this.ledBulb2.On = true;
            this.ledBulb2.Size = new System.Drawing.Size(45, 35);
            this.ledBulb2.TabIndex = 0;
            this.ledBulb2.Text = "ledBulb3";
            this.ledBulb2.Click += new System.EventHandler(this.LedBulb2_Click);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Controls.Add(this.ledBulb3);
            this.groupBox4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox4.ForeColor = System.Drawing.Color.OrangeRed;
            this.groupBox4.Location = new System.Drawing.Point(27, 190);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(300, 50);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Input 3";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(16, 29);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(128, 16);
            this.label3.TabIndex = 2;
            this.label3.Text = "Tag Varlik Sensoru";
            // 
            // ledBulb3
            // 
            this.ledBulb3.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ledBulb3.Location = new System.Drawing.Point(248, 13);
            this.ledBulb3.Name = "ledBulb3";
            this.ledBulb3.On = true;
            this.ledBulb3.Size = new System.Drawing.Size(45, 35);
            this.ledBulb3.TabIndex = 0;
            this.ledBulb3.Text = "ledBulb4";
            this.ledBulb3.Click += new System.EventHandler(this.LedBulb3_Click);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Controls.Add(this.ledBulb4);
            this.groupBox5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox5.ForeColor = System.Drawing.Color.OrangeRed;
            this.groupBox5.Location = new System.Drawing.Point(27, 250);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(300, 50);
            this.groupBox5.TabIndex = 3;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Input 4";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(16, 29);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(128, 16);
            this.label4.TabIndex = 2;
            this.label4.Text = "Tag Varlik Sensoru";
            // 
            // ledBulb4
            // 
            this.ledBulb4.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ledBulb4.Location = new System.Drawing.Point(248, 13);
            this.ledBulb4.Name = "ledBulb4";
            this.ledBulb4.On = true;
            this.ledBulb4.Size = new System.Drawing.Size(45, 35);
            this.ledBulb4.TabIndex = 0;
            this.ledBulb4.Text = "ledBulb5";
            this.ledBulb4.Click += new System.EventHandler(this.LedBulb4_Click);
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.label5);
            this.groupBox6.Controls.Add(this.ledBulb5);
            this.groupBox6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox6.ForeColor = System.Drawing.Color.OrangeRed;
            this.groupBox6.Location = new System.Drawing.Point(27, 310);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(300, 50);
            this.groupBox6.TabIndex = 3;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Input 5";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(16, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(128, 16);
            this.label5.TabIndex = 2;
            this.label5.Text = "Tag Varlik Sensoru";
            // 
            // ledBulb5
            // 
            this.ledBulb5.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ledBulb5.Location = new System.Drawing.Point(248, 13);
            this.ledBulb5.Name = "ledBulb5";
            this.ledBulb5.On = true;
            this.ledBulb5.Size = new System.Drawing.Size(45, 35);
            this.ledBulb5.TabIndex = 0;
            this.ledBulb5.Text = "ledBulb6";
            this.ledBulb5.Click += new System.EventHandler(this.LedBulb5_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.label6);
            this.groupBox7.Controls.Add(this.ledBulb6);
            this.groupBox7.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox7.ForeColor = System.Drawing.Color.OrangeRed;
            this.groupBox7.Location = new System.Drawing.Point(27, 370);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(300, 50);
            this.groupBox7.TabIndex = 4;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Input 6";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(16, 29);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(128, 16);
            this.label6.TabIndex = 2;
            this.label6.Text = "Tag Varlik Sensoru";
            // 
            // ledBulb6
            // 
            this.ledBulb6.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ledBulb6.Location = new System.Drawing.Point(248, 13);
            this.ledBulb6.Name = "ledBulb6";
            this.ledBulb6.On = true;
            this.ledBulb6.Size = new System.Drawing.Size(45, 35);
            this.ledBulb6.TabIndex = 0;
            this.ledBulb6.Text = "ledBulb7";
            this.ledBulb6.Click += new System.EventHandler(this.LedBulb6_Click);
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.label7);
            this.groupBox8.Controls.Add(this.ledBulb7);
            this.groupBox8.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox8.ForeColor = System.Drawing.Color.OrangeRed;
            this.groupBox8.Location = new System.Drawing.Point(27, 430);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(300, 50);
            this.groupBox8.TabIndex = 5;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Input 7";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(16, 29);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(128, 16);
            this.label7.TabIndex = 2;
            this.label7.Text = "Tag Varlik Sensoru";
            // 
            // ledBulb7
            // 
            this.ledBulb7.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ledBulb7.Location = new System.Drawing.Point(248, 13);
            this.ledBulb7.Name = "ledBulb7";
            this.ledBulb7.On = true;
            this.ledBulb7.Size = new System.Drawing.Size(45, 35);
            this.ledBulb7.TabIndex = 0;
            this.ledBulb7.Text = "ledBulb8";
            this.ledBulb7.Click += new System.EventHandler(this.LedBulb7_Click);
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.label8);
            this.groupBox9.Controls.Add(this.ledBulb8);
            this.groupBox9.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox9.ForeColor = System.Drawing.Color.OrangeRed;
            this.groupBox9.Location = new System.Drawing.Point(342, 10);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(300, 50);
            this.groupBox9.TabIndex = 13;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Input 8";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(16, 29);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(128, 16);
            this.label8.TabIndex = 2;
            this.label8.Text = "Tag Varlik Sensoru";
            // 
            // ledBulb8
            // 
            this.ledBulb8.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ledBulb8.Location = new System.Drawing.Point(248, 13);
            this.ledBulb8.Name = "ledBulb8";
            this.ledBulb8.On = true;
            this.ledBulb8.Size = new System.Drawing.Size(45, 35);
            this.ledBulb8.TabIndex = 0;
            this.ledBulb8.Text = "ledBulb8";
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.label9);
            this.groupBox10.Controls.Add(this.ledBulb9);
            this.groupBox10.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox10.ForeColor = System.Drawing.Color.OrangeRed;
            this.groupBox10.Location = new System.Drawing.Point(342, 70);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(300, 50);
            this.groupBox10.TabIndex = 12;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Input 9";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(16, 29);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(128, 16);
            this.label9.TabIndex = 2;
            this.label9.Text = "Tag Varlik Sensoru";
            // 
            // ledBulb9
            // 
            this.ledBulb9.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ledBulb9.Location = new System.Drawing.Point(248, 13);
            this.ledBulb9.Name = "ledBulb9";
            this.ledBulb9.On = true;
            this.ledBulb9.Size = new System.Drawing.Size(45, 35);
            this.ledBulb9.TabIndex = 0;
            this.ledBulb9.Text = "ledBulb7";
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.label10);
            this.groupBox11.Controls.Add(this.ledBulb10);
            this.groupBox11.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox11.ForeColor = System.Drawing.Color.OrangeRed;
            this.groupBox11.Location = new System.Drawing.Point(342, 130);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(300, 50);
            this.groupBox11.TabIndex = 8;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Input 10";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(16, 29);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(128, 16);
            this.label10.TabIndex = 2;
            this.label10.Text = "Tag Varlik Sensoru";
            // 
            // ledBulb10
            // 
            this.ledBulb10.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ledBulb10.Location = new System.Drawing.Point(248, 13);
            this.ledBulb10.Name = "ledBulb10";
            this.ledBulb10.On = true;
            this.ledBulb10.Size = new System.Drawing.Size(45, 35);
            this.ledBulb10.TabIndex = 0;
            this.ledBulb10.Text = "ledBulb6";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.label11);
            this.groupBox12.Controls.Add(this.ledBulb11);
            this.groupBox12.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox12.ForeColor = System.Drawing.Color.OrangeRed;
            this.groupBox12.Location = new System.Drawing.Point(342, 190);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(300, 50);
            this.groupBox12.TabIndex = 9;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Input 11";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(16, 29);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(128, 16);
            this.label11.TabIndex = 2;
            this.label11.Text = "Tag Varlik Sensoru";
            // 
            // ledBulb11
            // 
            this.ledBulb11.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ledBulb11.Location = new System.Drawing.Point(248, 13);
            this.ledBulb11.Name = "ledBulb11";
            this.ledBulb11.On = true;
            this.ledBulb11.Size = new System.Drawing.Size(45, 35);
            this.ledBulb11.TabIndex = 0;
            this.ledBulb11.Text = "ledBulb5";
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.label12);
            this.groupBox13.Controls.Add(this.ledBulb12);
            this.groupBox13.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox13.ForeColor = System.Drawing.Color.OrangeRed;
            this.groupBox13.Location = new System.Drawing.Point(342, 250);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(300, 50);
            this.groupBox13.TabIndex = 10;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Input 12";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(16, 29);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(128, 16);
            this.label12.TabIndex = 2;
            this.label12.Text = "Tag Varlik Sensoru";
            // 
            // ledBulb12
            // 
            this.ledBulb12.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ledBulb12.Location = new System.Drawing.Point(248, 13);
            this.ledBulb12.Name = "ledBulb12";
            this.ledBulb12.On = true;
            this.ledBulb12.Size = new System.Drawing.Size(45, 35);
            this.ledBulb12.TabIndex = 0;
            this.ledBulb12.Text = "ledBulb4";
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.label13);
            this.groupBox14.Controls.Add(this.ledBulb13);
            this.groupBox14.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox14.ForeColor = System.Drawing.Color.OrangeRed;
            this.groupBox14.Location = new System.Drawing.Point(342, 310);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(300, 50);
            this.groupBox14.TabIndex = 11;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Input 13";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(16, 29);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(128, 16);
            this.label13.TabIndex = 2;
            this.label13.Text = "Tag Varlik Sensoru";
            // 
            // ledBulb13
            // 
            this.ledBulb13.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ledBulb13.Location = new System.Drawing.Point(248, 13);
            this.ledBulb13.Name = "ledBulb13";
            this.ledBulb13.On = true;
            this.ledBulb13.Size = new System.Drawing.Size(45, 35);
            this.ledBulb13.TabIndex = 0;
            this.ledBulb13.Text = "ledBulb3";
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.label14);
            this.groupBox15.Controls.Add(this.ledBulb14);
            this.groupBox15.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox15.ForeColor = System.Drawing.Color.OrangeRed;
            this.groupBox15.Location = new System.Drawing.Point(342, 370);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(300, 50);
            this.groupBox15.TabIndex = 7;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Input 14";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(16, 29);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(128, 16);
            this.label14.TabIndex = 2;
            this.label14.Text = "Tag Varlik Sensoru";
            // 
            // ledBulb14
            // 
            this.ledBulb14.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ledBulb14.Location = new System.Drawing.Point(248, 13);
            this.ledBulb14.Name = "ledBulb14";
            this.ledBulb14.On = true;
            this.ledBulb14.Size = new System.Drawing.Size(45, 35);
            this.ledBulb14.TabIndex = 0;
            this.ledBulb14.Text = "ledBulb2";
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(this.label15);
            this.groupBox16.Controls.Add(this.ledBulb15);
            this.groupBox16.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox16.ForeColor = System.Drawing.Color.OrangeRed;
            this.groupBox16.Location = new System.Drawing.Point(342, 430);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(300, 50);
            this.groupBox16.TabIndex = 6;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Input 15";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(16, 29);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(128, 16);
            this.label15.TabIndex = 2;
            this.label15.Text = "Tag Varlik Sensoru";
            // 
            // ledBulb15
            // 
            this.ledBulb15.Color = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.ledBulb15.Location = new System.Drawing.Point(248, 13);
            this.ledBulb15.Name = "ledBulb15";
            this.ledBulb15.On = true;
            this.ledBulb15.Size = new System.Drawing.Size(45, 35);
            this.ledBulb15.TabIndex = 0;
            this.ledBulb15.Text = "ledBulb1";
            // 
            // FrmInputs
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.ClientSize = new System.Drawing.Size(662, 503);
            this.Controls.Add(this.groupBox9);
            this.Controls.Add(this.groupBox10);
            this.Controls.Add(this.groupBox12);
            this.Controls.Add(this.groupBox11);
            this.Controls.Add(this.groupBox13);
            this.Controls.Add(this.groupBox14);
            this.Controls.Add(this.groupBox15);
            this.Controls.Add(this.groupBox16);
            this.Controls.Add(this.groupBox8);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.groupBox6);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "FrmInputs";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Input Sayfasi";
            this.TopMost = true;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmInputs_FormClosing);
            this.Load += new System.EventHandler(this.FrmInputs_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            this.groupBox11.PerformLayout();
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private LedBulb ledBulb0;
        private System.Windows.Forms.Timer tmr_Input;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label0;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label1;
        private LedBulb ledBulb1;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label label2;
        private LedBulb ledBulb2;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label label3;
        private LedBulb ledBulb3;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label label4;
        private LedBulb ledBulb4;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.Label label5;
        private LedBulb ledBulb5;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.Label label6;
        private LedBulb ledBulb6;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Label label7;
        private LedBulb ledBulb7;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.Label label8;
        private LedBulb ledBulb8;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.Label label9;
        private LedBulb ledBulb9;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Label label10;
        private LedBulb ledBulb10;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Label label11;
        private LedBulb ledBulb11;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label label12;
        private LedBulb ledBulb12;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.Label label13;
        private LedBulb ledBulb13;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.Label label14;
        private LedBulb ledBulb14;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.Label label15;
        private LedBulb ledBulb15;


    }
}