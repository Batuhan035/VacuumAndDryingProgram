﻿namespace DelphiSoft
{
    partial class FrmDBSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmDBSettings));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.txt_l_timeout = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_l_password = new System.Windows.Forms.TextBox();
            this.txt_l_user = new System.Windows.Forms.TextBox();
            this.txt_l_catalog = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_cancel_loc = new System.Windows.Forms.Button();
            this.btn_add_loc = new System.Windows.Forms.Button();
            this.txt_l_datasource = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.txt_t_timeout = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_t_password = new System.Windows.Forms.TextBox();
            this.txt_t_user = new System.Windows.Forms.TextBox();
            this.txt_t_catalog = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.btn_cancel_t = new System.Windows.Forms.Button();
            this.btn_add_t = new System.Windows.Forms.Button();
            this.txt_t_datasource = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(1, 2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(496, 294);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Lavender;
            this.tabPage1.Controls.Add(this.txt_l_timeout);
            this.tabPage1.Controls.Add(this.label5);
            this.tabPage1.Controls.Add(this.txt_l_password);
            this.tabPage1.Controls.Add(this.txt_l_user);
            this.tabPage1.Controls.Add(this.txt_l_catalog);
            this.tabPage1.Controls.Add(this.label4);
            this.tabPage1.Controls.Add(this.label3);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.btn_cancel_loc);
            this.tabPage1.Controls.Add(this.btn_add_loc);
            this.tabPage1.Controls.Add(this.txt_l_datasource);
            this.tabPage1.Controls.Add(this.label1);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(488, 268);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Lokal";
            // 
            // txt_l_timeout
            // 
            this.txt_l_timeout.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txt_l_timeout.Location = new System.Drawing.Point(186, 173);
            this.txt_l_timeout.Name = "txt_l_timeout";
            this.txt_l_timeout.Size = new System.Drawing.Size(205, 23);
            this.txt_l_timeout.TabIndex = 13;
            this.txt_l_timeout.Text = "localhost";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label5.ForeColor = System.Drawing.Color.Crimson;
            this.label5.Location = new System.Drawing.Point(41, 175);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(148, 16);
            this.label5.TabIndex = 12;
            this.label5.Text = "Connection Timeout  :";
            // 
            // txt_l_password
            // 
            this.txt_l_password.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txt_l_password.Location = new System.Drawing.Point(186, 133);
            this.txt_l_password.Name = "txt_l_password";
            this.txt_l_password.Size = new System.Drawing.Size(205, 23);
            this.txt_l_password.TabIndex = 11;
            this.txt_l_password.Text = "localhost";
            // 
            // txt_l_user
            // 
            this.txt_l_user.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txt_l_user.Location = new System.Drawing.Point(186, 94);
            this.txt_l_user.Name = "txt_l_user";
            this.txt_l_user.Size = new System.Drawing.Size(205, 23);
            this.txt_l_user.TabIndex = 10;
            this.txt_l_user.Text = "localhost";
            // 
            // txt_l_catalog
            // 
            this.txt_l_catalog.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txt_l_catalog.Location = new System.Drawing.Point(186, 56);
            this.txt_l_catalog.Name = "txt_l_catalog";
            this.txt_l_catalog.Size = new System.Drawing.Size(205, 23);
            this.txt_l_catalog.TabIndex = 9;
            this.txt_l_catalog.Text = "localhost";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label4.ForeColor = System.Drawing.Color.Crimson;
            this.label4.Location = new System.Drawing.Point(41, 136);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(148, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = "Password                  :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label3.ForeColor = System.Drawing.Color.Crimson;
            this.label3.Location = new System.Drawing.Point(41, 97);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(148, 16);
            this.label3.TabIndex = 7;
            this.label3.Text = "User ID                      :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.Crimson;
            this.label2.Location = new System.Drawing.Point(41, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(146, 16);
            this.label2.TabIndex = 6;
            this.label2.Text = "Initial Catalog           :";
            // 
            // btn_cancel_loc
            // 
            this.btn_cancel_loc.ForeColor = System.Drawing.Color.Black;
            this.btn_cancel_loc.Image = ((System.Drawing.Image)(resources.GetObject("btn_cancel_loc.Image")));
            this.btn_cancel_loc.Location = new System.Drawing.Point(305, 210);
            this.btn_cancel_loc.Name = "btn_cancel_loc";
            this.btn_cancel_loc.Size = new System.Drawing.Size(86, 31);
            this.btn_cancel_loc.TabIndex = 5;
            this.btn_cancel_loc.UseVisualStyleBackColor = true;
            this.btn_cancel_loc.Click += new System.EventHandler(this.btn_cancel_loc_Click);
            // 
            // btn_add_loc
            // 
            this.btn_add_loc.ForeColor = System.Drawing.Color.Black;
            this.btn_add_loc.Image = ((System.Drawing.Image)(resources.GetObject("btn_add_loc.Image")));
            this.btn_add_loc.Location = new System.Drawing.Point(186, 210);
            this.btn_add_loc.Name = "btn_add_loc";
            this.btn_add_loc.Size = new System.Drawing.Size(86, 31);
            this.btn_add_loc.TabIndex = 4;
            this.btn_add_loc.UseVisualStyleBackColor = true;
            this.btn_add_loc.Click += new System.EventHandler(this.btn_add_loc_Click);
            // 
            // txt_l_datasource
            // 
            this.txt_l_datasource.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txt_l_datasource.Location = new System.Drawing.Point(186, 16);
            this.txt_l_datasource.Name = "txt_l_datasource";
            this.txt_l_datasource.Size = new System.Drawing.Size(205, 23);
            this.txt_l_datasource.TabIndex = 1;
            this.txt_l_datasource.Text = "localhost";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.Crimson;
            this.label1.Location = new System.Drawing.Point(41, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(145, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "DataSource              :";
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Lavender;
            this.tabPage2.Controls.Add(this.txt_t_timeout);
            this.tabPage2.Controls.Add(this.label10);
            this.tabPage2.Controls.Add(this.txt_t_password);
            this.tabPage2.Controls.Add(this.txt_t_user);
            this.tabPage2.Controls.Add(this.txt_t_catalog);
            this.tabPage2.Controls.Add(this.label9);
            this.tabPage2.Controls.Add(this.label8);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.btn_cancel_t);
            this.tabPage2.Controls.Add(this.btn_add_t);
            this.tabPage2.Controls.Add(this.txt_t_datasource);
            this.tabPage2.Controls.Add(this.label6);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(488, 268);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Izlenebilirlik";
            // 
            // txt_t_timeout
            // 
            this.txt_t_timeout.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txt_t_timeout.Location = new System.Drawing.Point(186, 173);
            this.txt_t_timeout.Name = "txt_t_timeout";
            this.txt_t_timeout.Size = new System.Drawing.Size(205, 23);
            this.txt_t_timeout.TabIndex = 13;
            this.txt_t_timeout.Text = "localhost";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label10.ForeColor = System.Drawing.Color.Crimson;
            this.label10.Location = new System.Drawing.Point(41, 175);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(148, 16);
            this.label10.TabIndex = 12;
            this.label10.Text = "Connection Timeout  :";
            // 
            // txt_t_password
            // 
            this.txt_t_password.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txt_t_password.Location = new System.Drawing.Point(186, 133);
            this.txt_t_password.Name = "txt_t_password";
            this.txt_t_password.Size = new System.Drawing.Size(205, 23);
            this.txt_t_password.TabIndex = 11;
            this.txt_t_password.Text = "localhost";
            // 
            // txt_t_user
            // 
            this.txt_t_user.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txt_t_user.Location = new System.Drawing.Point(186, 94);
            this.txt_t_user.Name = "txt_t_user";
            this.txt_t_user.Size = new System.Drawing.Size(205, 23);
            this.txt_t_user.TabIndex = 10;
            this.txt_t_user.Text = "localhost";
            // 
            // txt_t_catalog
            // 
            this.txt_t_catalog.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txt_t_catalog.Location = new System.Drawing.Point(186, 56);
            this.txt_t_catalog.Name = "txt_t_catalog";
            this.txt_t_catalog.Size = new System.Drawing.Size(205, 23);
            this.txt_t_catalog.TabIndex = 9;
            this.txt_t_catalog.Text = "localhost";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label9.ForeColor = System.Drawing.Color.Crimson;
            this.label9.Location = new System.Drawing.Point(41, 136);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(148, 16);
            this.label9.TabIndex = 8;
            this.label9.Text = "Password                  :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label8.ForeColor = System.Drawing.Color.Crimson;
            this.label8.Location = new System.Drawing.Point(41, 97);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(148, 16);
            this.label8.TabIndex = 7;
            this.label8.Text = "User ID                      :";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.Color.Crimson;
            this.label7.Location = new System.Drawing.Point(41, 58);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(146, 16);
            this.label7.TabIndex = 6;
            this.label7.Text = "Initial Catalog           :";
            // 
            // btn_cancel_t
            // 
            this.btn_cancel_t.ForeColor = System.Drawing.Color.Black;
            this.btn_cancel_t.Image = ((System.Drawing.Image)(resources.GetObject("btn_cancel_t.Image")));
            this.btn_cancel_t.Location = new System.Drawing.Point(305, 210);
            this.btn_cancel_t.Name = "btn_cancel_t";
            this.btn_cancel_t.Size = new System.Drawing.Size(86, 31);
            this.btn_cancel_t.TabIndex = 5;
            this.btn_cancel_t.UseVisualStyleBackColor = true;
            this.btn_cancel_t.Click += new System.EventHandler(this.btn_cancel_loc_Click);
            // 
            // btn_add_t
            // 
            this.btn_add_t.ForeColor = System.Drawing.Color.Black;
            this.btn_add_t.Image = ((System.Drawing.Image)(resources.GetObject("btn_add_t.Image")));
            this.btn_add_t.Location = new System.Drawing.Point(186, 210);
            this.btn_add_t.Name = "btn_add_t";
            this.btn_add_t.Size = new System.Drawing.Size(86, 31);
            this.btn_add_t.TabIndex = 4;
            this.btn_add_t.UseVisualStyleBackColor = true;
            this.btn_add_t.Click += new System.EventHandler(this.btn_add_t_Click);
            // 
            // txt_t_datasource
            // 
            this.txt_t_datasource.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txt_t_datasource.Location = new System.Drawing.Point(186, 16);
            this.txt_t_datasource.Name = "txt_t_datasource";
            this.txt_t_datasource.Size = new System.Drawing.Size(205, 23);
            this.txt_t_datasource.TabIndex = 1;
            this.txt_t_datasource.Text = "localhost";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label6.ForeColor = System.Drawing.Color.Crimson;
            this.label6.Location = new System.Drawing.Point(41, 19);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(145, 16);
            this.label6.TabIndex = 0;
            this.label6.Text = "DataSource              :";
            // 
            // FrmDBSettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(433, 285);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "FrmDBSettings";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Database Ayarlari";
            this.Load += new System.EventHandler(this.FrmDBSettings_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TextBox txt_l_datasource;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_cancel_loc;
        private System.Windows.Forms.Button btn_add_loc;
        private System.Windows.Forms.TextBox txt_l_timeout;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_l_password;
        private System.Windows.Forms.TextBox txt_l_user;
        private System.Windows.Forms.TextBox txt_l_catalog;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_t_datasource;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btn_cancel_t;
        private System.Windows.Forms.Button btn_add_t;
        private System.Windows.Forms.TextBox txt_t_timeout;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txt_t_password;
        private System.Windows.Forms.TextBox txt_t_user;
        private System.Windows.Forms.TextBox txt_t_catalog;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
    }
}