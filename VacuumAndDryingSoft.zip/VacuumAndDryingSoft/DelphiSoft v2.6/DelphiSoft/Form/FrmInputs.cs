﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//Ini
using Ini;

namespace DelphiSoft
{
    public partial class FrmInputs : Form
    {
        //For Stored Procedures
        StoredProcedures SP = new StoredProcedures();

        public FrmInputs()
        {
            InitializeComponent();
        }

        private void FrmInputs_Load(object sender, EventArgs e)
        {
            DataTable  InputDesc= new DataTable();
            InputDesc = SP.GetAllInputs();

            label0.Text = InputDesc.Rows[0]["Description"].ToString();
            label1.Text = InputDesc.Rows[1]["Description"].ToString();
            label2.Text = InputDesc.Rows[2]["Description"].ToString();
            label3.Text = InputDesc.Rows[3]["Description"].ToString();
            label4.Text = InputDesc.Rows[4]["Description"].ToString();
            label5.Text = InputDesc.Rows[5]["Description"].ToString();
            label6.Text = InputDesc.Rows[6]["Description"].ToString();
            label7.Text = InputDesc.Rows[7]["Description"].ToString();
            label8.Text = InputDesc.Rows[8]["Description"].ToString();
            label9.Text = InputDesc.Rows[9]["Description"].ToString();
            label10.Text = InputDesc.Rows[10]["Description"].ToString();
            label11.Text = InputDesc.Rows[11]["Description"].ToString();
            label12.Text = InputDesc.Rows[12]["Description"].ToString();
            label13.Text = InputDesc.Rows[13]["Description"].ToString();
            label14.Text = InputDesc.Rows[14]["Description"].ToString();
            label15.Text = InputDesc.Rows[15]["Description"].ToString();

            groupBox1.Text = InputDesc.Rows[0]["IO"].ToString();
            groupBox2.Text = InputDesc.Rows[1]["IO"].ToString();
            groupBox3.Text = InputDesc.Rows[2]["IO"].ToString();
            groupBox4.Text = InputDesc.Rows[3]["IO"].ToString();
            groupBox5.Text = InputDesc.Rows[4]["IO"].ToString();
            groupBox6.Text = InputDesc.Rows[5]["IO"].ToString();
            groupBox7.Text = InputDesc.Rows[6]["IO"].ToString();
            groupBox8.Text = InputDesc.Rows[7]["IO"].ToString();
            groupBox9.Text = InputDesc.Rows[8]["IO"].ToString();
            groupBox10.Text = InputDesc.Rows[9]["IO"].ToString();
            groupBox11.Text = InputDesc.Rows[10]["IO"].ToString();
            groupBox12.Text = InputDesc.Rows[11]["IO"].ToString();
            groupBox13.Text = InputDesc.Rows[12]["IO"].ToString();
            groupBox14.Text = InputDesc.Rows[13]["IO"].ToString();
            groupBox15.Text = InputDesc.Rows[14]["IO"].ToString();
            groupBox16.Text = InputDesc.Rows[15]["IO"].ToString();

            tmr_Input.Enabled = true;
        }

        private void FrmInputs_FormClosing(object sender, FormClosingEventArgs e)
        {
            tmr_Input.Enabled = false;
        }

        private void tmr_Input_Tick(object sender, EventArgs e)
        {
            LedRead(ledBulb0, GLB.I_Part_Presence);
            LedRead(ledBulb1, GLB.I_Tag_Sensor);
            LedRead(ledBulb2, GLB.I_Alarm_Reset);
            LedRead(ledBulb3, GLB.I_Cycle_Start);
            LedRead(ledBulb4, GLB.I_Auto);
            LedRead(ledBulb5, GLB.I_Emergency_Stop);
            LedRead(ledBulb6, GLB.I_Termik_Ikaz);
            LedRead(ledBulb7, GLB.I_OilTank);
        }

        private void LedRead (LedBulb LedName,bool Input)
        {
        if (Input) 
            { LedName.Color = Color.FromArgb(153, 255, 54); }
        else
        { LedName.Color = Color.FromArgb(255, 128, 128); }
        }

        #region Sim
        private bool Reverse(bool Val)
        {
            if (Val)
            {
                Val = false;
            }
            else
            {
                Val = true;
            }
            return Val;
        }
        private void LedBulb0_Click(object sender, EventArgs e)
        {
            GLB.Sim_I_Part_Presence=Reverse(GLB.Sim_I_Part_Presence);
        }
        private void LedBulb1_Click(object sender, EventArgs e)
        {
            GLB.Sim_I_Tag_Sensor= Reverse(GLB.Sim_I_Tag_Sensor);
        }

        private void LedBulb2_Click(object sender, EventArgs e)
        {
            GLB.Sim_I_Alarm_Reset=Reverse(GLB.Sim_I_Alarm_Reset);
        }

        private void LedBulb3_Click(object sender, EventArgs e)
        {
            GLB.Sim_I_Cycle_Start=Reverse(GLB.Sim_I_Cycle_Start);
        }

        private void LedBulb4_Click(object sender, EventArgs e)
        {
            GLB.Sim_I_Auto= Reverse(GLB.Sim_I_Auto);
        }

        private void LedBulb5_Click(object sender, EventArgs e)
        {
            GLB.Sim_I_Emergency_Stop=Reverse(GLB.Sim_I_Emergency_Stop);
        }

        private void LedBulb6_Click(object sender, EventArgs e)
        {
            GLB.Sim_I_Termik_Ikaz= Reverse(GLB.Sim_I_Termik_Ikaz);
        }

        private void LedBulb7_Click(object sender, EventArgs e)
        {
            GLB.Sim_I_OilTank= Reverse(GLB.Sim_I_OilTank);
        }
        #endregion
    }
}
