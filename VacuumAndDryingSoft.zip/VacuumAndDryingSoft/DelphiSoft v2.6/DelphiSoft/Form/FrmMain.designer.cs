﻿namespace DelphiSoft
{
    partial class FrmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmMain));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.userswitchMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.useraddMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.passwordchangeMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.permissionsMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.settingsMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.referenceMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.databaseMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ızlenebilirlikToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.Manual_MenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ManualMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.IOTestMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.InputsMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.outputsMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.recordsMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.notepadMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.calcStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.oskMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lbl_info = new System.Windows.Forms.Label();
            this.tmr_datentime = new System.Windows.Forms.Timer(this.components);
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.lbl_sim = new System.Windows.Forms.Label();
            this.grp_DM = new System.Windows.Forms.GroupBox();
            this.lbl_S_DM = new System.Windows.Forms.Label();
            this.txt_DM2_No = new System.Windows.Forms.TextBox();
            this.btn_simDM = new System.Windows.Forms.Button();
            this.txt_DM_No = new System.Windows.Forms.TextBox();
            this.led_DMPresent = new DelphiSoft.LedBulb();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.pic_red = new System.Windows.Forms.PictureBox();
            this.pic_yellow = new System.Windows.Forms.PictureBox();
            this.lbl_result = new System.Windows.Forms.Label();
            this.pic_green = new System.Windows.Forms.PictureBox();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lbl_step_cycle = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.led_OKLamp = new DelphiSoft.LedBulb();
            this.led_NOKLamp = new DelphiSoft.LedBulb();
            this.pic_DM = new System.Windows.Forms.PictureBox();
            this.pic_tag = new System.Windows.Forms.PictureBox();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.pic_blow_off = new System.Windows.Forms.PictureBox();
            this.pic_blow_on = new System.Windows.Forms.PictureBox();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.lbl_vacuum_saniye = new System.Windows.Forms.Label();
            this.pic_Vac_Off = new System.Windows.Forms.PictureBox();
            this.lbl_vacuum_time = new System.Windows.Forms.Label();
            this.pic_Vac_On = new System.Windows.Forms.PictureBox();
            this.btn_TagDM = new System.Windows.Forms.Button();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.led_auto_button = new DelphiSoft.LedBulb();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.led_resetbutton = new DelphiSoft.LedBulb();
            this.led_startbutton = new DelphiSoft.LedBulb();
            this.label1 = new System.Windows.Forms.Label();
            this.led_PartPresence = new DelphiSoft.LedBulb();
            this.grp_traceability = new System.Windows.Forms.GroupBox();
            this.pic_NoDBConnect = new System.Windows.Forms.PictureBox();
            this.pic_DBConnect = new System.Windows.Forms.PictureBox();
            this.lbl_Traceability1 = new System.Windows.Forms.Label();
            this.grp_Tag = new System.Windows.Forms.GroupBox();
            this.lbl_S_Tag = new System.Windows.Forms.Label();
            this.txt_Tag2_No = new System.Windows.Forms.TextBox();
            this.txt_Tag_No = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.led_TagPresent = new DelphiSoft.LedBulb();
            this.label9 = new System.Windows.Forms.Label();
            this.lbl1 = new System.Windows.Forms.Label();
            this.tmr_cycle = new System.Windows.Forms.Timer(this.components);
            this.lbl12 = new System.Windows.Forms.Label();
            this.lbl_step = new System.Windows.Forms.Label();
            this.lbl_date = new System.Windows.Forms.Label();
            this.lbl_time = new System.Windows.Forms.Label();
            this.lbl_Author = new System.Windows.Forms.Label();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.lbl_pomp_saniye = new System.Windows.Forms.Label();
            this.lbl_pomp_time = new System.Windows.Forms.Label();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.btn_count_reset = new System.Windows.Forms.Button();
            this.lbl_TOTAL = new System.Windows.Forms.Label();
            this.lbl_NOK = new System.Windows.Forms.Label();
            this.lbl_OK = new System.Windows.Forms.Label();
            this.lbl16 = new System.Windows.Forms.Label();
            this.lbl17 = new System.Windows.Forms.Label();
            this.lbl18 = new System.Windows.Forms.Label();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.lbl_reset_time = new System.Windows.Forms.Label();
            this.pic_kayit = new System.Windows.Forms.PictureBox();
            this.label51 = new System.Windows.Forms.Label();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lbl_userdate = new System.Windows.Forms.Label();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lbl_userright = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.pic_user = new System.Windows.Forms.PictureBox();
            this.lbl_username = new System.Windows.Forms.Label();
            this.lbl_Auto = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lbl_LifeBit = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.tmr_blow = new System.Windows.Forms.Timer(this.components);
            this.tmr_Adventech = new System.Windows.Forms.Timer(this.components);
            this.tmr_Pomp = new System.Windows.Forms.Timer(this.components);
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.cmb_ref = new System.Windows.Forms.ComboBox();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.lbl_refdesc = new System.Windows.Forms.Label();
            this.grp_desc1 = new System.Windows.Forms.GroupBox();
            this.lbl_refval1 = new System.Windows.Forms.Label();
            this.grp_desc3 = new System.Windows.Forms.GroupBox();
            this.lbl_refval3 = new System.Windows.Forms.Label();
            this.grp_desc2 = new System.Windows.Forms.GroupBox();
            this.lbl_refval2 = new System.Windows.Forms.Label();
            this.grp_desc4 = new System.Windows.Forms.GroupBox();
            this.lbl_refval4 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.grp_desc5 = new System.Windows.Forms.GroupBox();
            this.lbl_refval5 = new System.Windows.Forms.Label();
            this.pic_K9K = new System.Windows.Forms.PictureBox();
            this.pic_AudiHPv = new System.Windows.Forms.PictureBox();
            this.pic_HPs = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.btn_reset = new System.Windows.Forms.Button();
            this.led_LifeBit = new DelphiSoft.LedBulb();
            this.ledAuto = new DelphiSoft.LedBulb();
            this.menuStrip1.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.grp_DM.SuspendLayout();
            this.groupBox14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_red)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_yellow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_green)).BeginInit();
            this.groupBox13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_DM)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_tag)).BeginInit();
            this.groupBox12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_blow_off)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_blow_on)).BeginInit();
            this.groupBox9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Vac_Off)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Vac_On)).BeginInit();
            this.groupBox18.SuspendLayout();
            this.grp_traceability.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_NoDBConnect)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_DBConnect)).BeginInit();
            this.grp_Tag.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox15.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_kayit)).BeginInit();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_user)).BeginInit();
            this.groupBox3.SuspendLayout();
            this.groupBox11.SuspendLayout();
            this.grp_desc1.SuspendLayout();
            this.grp_desc3.SuspendLayout();
            this.grp_desc2.SuspendLayout();
            this.grp_desc4.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.grp_desc5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_K9K)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_AudiHPv)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_HPs)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.menuStrip1.GripMargin = new System.Windows.Forms.Padding(20, 0, 0, 0);
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(50, 50);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileMenuItem,
            this.userMenuItem,
            this.settingsMenuItem,
            this.Manual_MenuItem,
            this.IOTestMenuItem,
            this.recordsMenuItem,
            this.toolsMenuItem,
            this.helpMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(20, 2, 0, 2);
            this.menuStrip1.Size = new System.Drawing.Size(1926, 58);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileMenuItem
            // 
            this.fileMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exitMenuItem});
            this.fileMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("fileMenuItem.Image")));
            this.fileMenuItem.Name = "fileMenuItem";
            this.fileMenuItem.Size = new System.Drawing.Size(120, 54);
            this.fileMenuItem.Text = "Dosya";
            this.fileMenuItem.Click += new System.EventHandler(this.fileToolStripMenuItem_Click);
            // 
            // exitMenuItem
            // 
            this.exitMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("exitMenuItem.Image")));
            this.exitMenuItem.Name = "exitMenuItem";
            this.exitMenuItem.Size = new System.Drawing.Size(151, 56);
            this.exitMenuItem.Text = "Çıkış";
            this.exitMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // userMenuItem
            // 
            this.userMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.userswitchMenuItem,
            this.useraddMenuItem,
            this.passwordchangeMenuItem,
            this.permissionsMenuItem});
            this.userMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("userMenuItem.Image")));
            this.userMenuItem.Name = "userMenuItem";
            this.userMenuItem.Size = new System.Drawing.Size(217, 54);
            this.userMenuItem.Text = "Kullanıcı İşlemleri";
            // 
            // userswitchMenuItem
            // 
            this.userswitchMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("userswitchMenuItem.Image")));
            this.userswitchMenuItem.Name = "userswitchMenuItem";
            this.userswitchMenuItem.Size = new System.Drawing.Size(288, 56);
            this.userswitchMenuItem.Text = "Kullanıcı Değiştir";
            this.userswitchMenuItem.Click += new System.EventHandler(this.kullanıcıDeğiştirToolStripMenuItem_Click);
            // 
            // useraddMenuItem
            // 
            this.useraddMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("useraddMenuItem.Image")));
            this.useraddMenuItem.Name = "useraddMenuItem";
            this.useraddMenuItem.Size = new System.Drawing.Size(288, 56);
            this.useraddMenuItem.Text = "Kullanıcı Ekle / Kaldır";
            this.useraddMenuItem.Click += new System.EventHandler(this.kullanıcıEkleKaldırToolStripMenuItem_Click);
            // 
            // passwordchangeMenuItem
            // 
            this.passwordchangeMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("passwordchangeMenuItem.Image")));
            this.passwordchangeMenuItem.Name = "passwordchangeMenuItem";
            this.passwordchangeMenuItem.Size = new System.Drawing.Size(288, 56);
            this.passwordchangeMenuItem.Text = "Şifre Değiştir";
            this.passwordchangeMenuItem.Click += new System.EventHandler(this.şifreDeğiştirmeToolStripMenuItem_Click);
            // 
            // permissionsMenuItem
            // 
            this.permissionsMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("permissionsMenuItem.Image")));
            this.permissionsMenuItem.Name = "permissionsMenuItem";
            this.permissionsMenuItem.Size = new System.Drawing.Size(288, 56);
            this.permissionsMenuItem.Text = "Kullanıcı İzinleri";
            this.permissionsMenuItem.Click += new System.EventHandler(this.permissionsToolStripMenuItem_Click);
            // 
            // settingsMenuItem
            // 
            this.settingsMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.referenceMenuItem,
            this.databaseMenuItem,
            this.ızlenebilirlikToolStripMenuItem});
            this.settingsMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("settingsMenuItem.Image")));
            this.settingsMenuItem.Name = "settingsMenuItem";
            this.settingsMenuItem.Size = new System.Drawing.Size(131, 54);
            this.settingsMenuItem.Text = "Ayarlar";
            // 
            // referenceMenuItem
            // 
            this.referenceMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("referenceMenuItem.Image")));
            this.referenceMenuItem.Name = "referenceMenuItem";
            this.referenceMenuItem.Size = new System.Drawing.Size(215, 56);
            this.referenceMenuItem.Text = "Referanslar";
            this.referenceMenuItem.Click += new System.EventHandler(this.referanslarıGörüntüleToolStripMenuItem_Click);
            // 
            // databaseMenuItem
            // 
            this.databaseMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("databaseMenuItem.Image")));
            this.databaseMenuItem.Name = "databaseMenuItem";
            this.databaseMenuItem.Size = new System.Drawing.Size(215, 56);
            this.databaseMenuItem.Text = "Database";
            this.databaseMenuItem.Click += new System.EventHandler(this.konfigurasyonToolStripMenuItem_Click);
            // 
            // ızlenebilirlikToolStripMenuItem
            // 
            this.ızlenebilirlikToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("ızlenebilirlikToolStripMenuItem.Image")));
            this.ızlenebilirlikToolStripMenuItem.Name = "ızlenebilirlikToolStripMenuItem";
            this.ızlenebilirlikToolStripMenuItem.Size = new System.Drawing.Size(215, 56);
            this.ızlenebilirlikToolStripMenuItem.Text = "Izlenebilirlik";
            this.ızlenebilirlikToolStripMenuItem.Click += new System.EventHandler(this.IzlenebilirlikToolStripMenuItem_Click);
            // 
            // Manual_MenuItem
            // 
            this.Manual_MenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ManualMenuItem});
            this.Manual_MenuItem.Image = ((System.Drawing.Image)(resources.GetObject("Manual_MenuItem.Image")));
            this.Manual_MenuItem.Name = "Manual_MenuItem";
            this.Manual_MenuItem.Size = new System.Drawing.Size(223, 54);
            this.Manual_MenuItem.Text = "Manuel Hareketler";
            // 
            // ManualMenuItem
            // 
            this.ManualMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("ManualMenuItem.Image")));
            this.ManualMenuItem.Name = "ManualMenuItem";
            this.ManualMenuItem.Size = new System.Drawing.Size(228, 56);
            this.ManualMenuItem.Text = "Manuel Ekrani";
            this.ManualMenuItem.Click += new System.EventHandler(this.ManualMenuItem_Click);
            // 
            // IOTestMenuItem
            // 
            this.IOTestMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.InputsMenuItem,
            this.outputsMenuItem});
            this.IOTestMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("IOTestMenuItem.Image")));
            this.IOTestMenuItem.Name = "IOTestMenuItem";
            this.IOTestMenuItem.Size = new System.Drawing.Size(131, 54);
            this.IOTestMenuItem.Text = "IO Test";
            // 
            // InputsMenuItem
            // 
            this.InputsMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("InputsMenuItem.Image")));
            this.InputsMenuItem.Name = "InputsMenuItem";
            this.InputsMenuItem.Size = new System.Drawing.Size(176, 56);
            this.InputsMenuItem.Text = "Inputs";
            this.InputsMenuItem.Click += new System.EventHandler(this.InputsToolStripMenuItem_Click);
            // 
            // outputsMenuItem
            // 
            this.outputsMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("outputsMenuItem.Image")));
            this.outputsMenuItem.Name = "outputsMenuItem";
            this.outputsMenuItem.Size = new System.Drawing.Size(176, 56);
            this.outputsMenuItem.Text = "Outputs";
            this.outputsMenuItem.Click += new System.EventHandler(this.outputsToolStripMenuItem_Click);
            // 
            // recordsMenuItem
            // 
            this.recordsMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.reportMenuItem});
            this.recordsMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("recordsMenuItem.Image")));
            this.recordsMenuItem.Name = "recordsMenuItem";
            this.recordsMenuItem.Size = new System.Drawing.Size(142, 54);
            this.recordsMenuItem.Text = "Raporlar";
            // 
            // reportMenuItem
            // 
            this.reportMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("reportMenuItem.Image")));
            this.reportMenuItem.Name = "reportMenuItem";
            this.reportMenuItem.Size = new System.Drawing.Size(255, 56);
            this.reportMenuItem.Text = "Lokal Veri Tabanı";
            this.reportMenuItem.Click += new System.EventHandler(this.kontrolSonuçlarıToolStripMenuItem_Click);
            // 
            // toolsMenuItem
            // 
            this.toolsMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.notepadMenuItem,
            this.calcStripMenuItem,
            this.oskMenuItem});
            this.toolsMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("toolsMenuItem.Image")));
            this.toolsMenuItem.Name = "toolsMenuItem";
            this.toolsMenuItem.Size = new System.Drawing.Size(130, 54);
            this.toolsMenuItem.Text = "Araçlar";
            // 
            // notepadMenuItem
            // 
            this.notepadMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("notepadMenuItem.Image")));
            this.notepadMenuItem.Name = "notepadMenuItem";
            this.notepadMenuItem.Size = new System.Drawing.Size(239, 56);
            this.notepadMenuItem.Text = "Not Defteri";
            this.notepadMenuItem.Click += new System.EventHandler(this.notDefteriToolStripMenuItem_Click);
            // 
            // calcStripMenuItem
            // 
            this.calcStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("calcStripMenuItem.Image")));
            this.calcStripMenuItem.Name = "calcStripMenuItem";
            this.calcStripMenuItem.Size = new System.Drawing.Size(239, 56);
            this.calcStripMenuItem.Text = "Hesap Makinesi";
            this.calcStripMenuItem.Click += new System.EventHandler(this.hesapMakinesiToolStripMenuItem_Click);
            // 
            // oskMenuItem
            // 
            this.oskMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("oskMenuItem.Image")));
            this.oskMenuItem.Name = "oskMenuItem";
            this.oskMenuItem.Size = new System.Drawing.Size(239, 56);
            this.oskMenuItem.Text = "Sanal Klavye";
            this.oskMenuItem.Click += new System.EventHandler(this.sanalKlavyeToolStripMenuItem_Click);
            // 
            // helpMenuItem
            // 
            this.helpMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutMenuItem});
            this.helpMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("helpMenuItem.Image")));
            this.helpMenuItem.Name = "helpMenuItem";
            this.helpMenuItem.Size = new System.Drawing.Size(129, 54);
            this.helpMenuItem.Text = "Yardım";
            // 
            // aboutMenuItem
            // 
            this.aboutMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("aboutMenuItem.Image")));
            this.aboutMenuItem.Name = "aboutMenuItem";
            this.aboutMenuItem.Size = new System.Drawing.Size(189, 56);
            this.aboutMenuItem.Text = "Hakkında";
            this.aboutMenuItem.Click += new System.EventHandler(this.hakkındaToolStripMenuItem_Click);
            // 
            // lbl_info
            // 
            this.lbl_info.BackColor = System.Drawing.Color.Yellow;
            this.lbl_info.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lbl_info.Font = new System.Drawing.Font("Tahoma", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_info.Location = new System.Drawing.Point(-2, 948);
            this.lbl_info.Name = "lbl_info";
            this.lbl_info.Size = new System.Drawing.Size(1746, 110);
            this.lbl_info.TabIndex = 5;
            this.lbl_info.Text = "info screen";
            this.lbl_info.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tmr_datentime
            // 
            this.tmr_datentime.Enabled = true;
            this.tmr_datentime.Interval = 1000;
            this.tmr_datentime.Tick += new System.EventHandler(this.tmr_datentime_Tick);
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.lbl_sim);
            this.groupBox5.Controls.Add(this.grp_DM);
            this.groupBox5.Controls.Add(this.groupBox14);
            this.groupBox5.Controls.Add(this.groupBox13);
            this.groupBox5.Controls.Add(this.pic_DM);
            this.groupBox5.Controls.Add(this.pic_tag);
            this.groupBox5.Controls.Add(this.groupBox12);
            this.groupBox5.Controls.Add(this.groupBox9);
            this.groupBox5.Controls.Add(this.btn_TagDM);
            this.groupBox5.Controls.Add(this.groupBox18);
            this.groupBox5.Controls.Add(this.grp_traceability);
            this.groupBox5.Controls.Add(this.grp_Tag);
            this.groupBox5.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox5.ForeColor = System.Drawing.Color.Crimson;
            this.groupBox5.Location = new System.Drawing.Point(377, 68);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(1153, 823);
            this.groupBox5.TabIndex = 10;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Uretim Verileri";
            // 
            // lbl_sim
            // 
            this.lbl_sim.AutoSize = true;
            this.lbl_sim.BackColor = System.Drawing.Color.Crimson;
            this.lbl_sim.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_sim.ForeColor = System.Drawing.Color.White;
            this.lbl_sim.Location = new System.Drawing.Point(436, 15);
            this.lbl_sim.Name = "lbl_sim";
            this.lbl_sim.Size = new System.Drawing.Size(278, 39);
            this.lbl_sim.TabIndex = 5;
            this.lbl_sim.Text = "Simulasyon Acik";
            // 
            // grp_DM
            // 
            this.grp_DM.Controls.Add(this.lbl_S_DM);
            this.grp_DM.Controls.Add(this.txt_DM2_No);
            this.grp_DM.Controls.Add(this.btn_simDM);
            this.grp_DM.Controls.Add(this.txt_DM_No);
            this.grp_DM.Controls.Add(this.led_DMPresent);
            this.grp_DM.Controls.Add(this.label2);
            this.grp_DM.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.grp_DM.ForeColor = System.Drawing.Color.SteelBlue;
            this.grp_DM.Location = new System.Drawing.Point(740, 36);
            this.grp_DM.Name = "grp_DM";
            this.grp_DM.Size = new System.Drawing.Size(400, 179);
            this.grp_DM.TabIndex = 49;
            this.grp_DM.TabStop = false;
            this.grp_DM.Text = "Datamatrix Numarası";
            // 
            // lbl_S_DM
            // 
            this.lbl_S_DM.AutoSize = true;
            this.lbl_S_DM.Location = new System.Drawing.Point(10, 72);
            this.lbl_S_DM.Name = "lbl_S_DM";
            this.lbl_S_DM.Size = new System.Drawing.Size(107, 19);
            this.lbl_S_DM.TabIndex = 11;
            this.lbl_S_DM.Text = "Sıradaki DM";
            // 
            // txt_DM2_No
            // 
            this.txt_DM2_No.Location = new System.Drawing.Point(14, 96);
            this.txt_DM2_No.Name = "txt_DM2_No";
            this.txt_DM2_No.Size = new System.Drawing.Size(356, 27);
            this.txt_DM2_No.TabIndex = 56;
            this.txt_DM2_No.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // btn_simDM
            // 
            this.btn_simDM.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_simDM.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_simDM.Location = new System.Drawing.Point(14, 135);
            this.btn_simDM.Name = "btn_simDM";
            this.btn_simDM.Size = new System.Drawing.Size(91, 40);
            this.btn_simDM.TabIndex = 55;
            this.btn_simDM.Text = "DM Gönder";
            this.btn_simDM.UseVisualStyleBackColor = true;
            this.btn_simDM.Click += new System.EventHandler(this.Btn_simDM_Click);
            // 
            // txt_DM_No
            // 
            this.txt_DM_No.Location = new System.Drawing.Point(14, 26);
            this.txt_DM_No.Name = "txt_DM_No";
            this.txt_DM_No.Size = new System.Drawing.Size(356, 27);
            this.txt_DM_No.TabIndex = 7;
            this.txt_DM_No.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // led_DMPresent
            // 
            this.led_DMPresent.Color = System.Drawing.Color.Crimson;
            this.led_DMPresent.Location = new System.Drawing.Point(303, 129);
            this.led_DMPresent.Name = "led_DMPresent";
            this.led_DMPresent.On = true;
            this.led_DMPresent.Size = new System.Drawing.Size(67, 44);
            this.led_DMPresent.TabIndex = 5;
            this.led_DMPresent.Text = "led";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(125, 151);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(172, 19);
            this.label2.TabIndex = 5;
            this.label2.Text = "Datamatrix Sensoru";
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.pic_red);
            this.groupBox14.Controls.Add(this.pic_yellow);
            this.groupBox14.Controls.Add(this.lbl_result);
            this.groupBox14.Controls.Add(this.pic_green);
            this.groupBox14.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox14.ForeColor = System.Drawing.Color.SteelBlue;
            this.groupBox14.Location = new System.Drawing.Point(800, 437);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(340, 368);
            this.groupBox14.TabIndex = 51;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Sonuç";
            // 
            // pic_red
            // 
            this.pic_red.Image = ((System.Drawing.Image)(resources.GetObject("pic_red.Image")));
            this.pic_red.Location = new System.Drawing.Point(101, 56);
            this.pic_red.Name = "pic_red";
            this.pic_red.Size = new System.Drawing.Size(164, 266);
            this.pic_red.TabIndex = 54;
            this.pic_red.TabStop = false;
            // 
            // pic_yellow
            // 
            this.pic_yellow.Image = ((System.Drawing.Image)(resources.GetObject("pic_yellow.Image")));
            this.pic_yellow.Location = new System.Drawing.Point(101, 56);
            this.pic_yellow.Name = "pic_yellow";
            this.pic_yellow.Size = new System.Drawing.Size(164, 266);
            this.pic_yellow.TabIndex = 53;
            this.pic_yellow.TabStop = false;
            // 
            // lbl_result
            // 
            this.lbl_result.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_result.Location = new System.Drawing.Point(6, 29);
            this.lbl_result.Name = "lbl_result";
            this.lbl_result.Size = new System.Drawing.Size(328, 19);
            this.lbl_result.TabIndex = 52;
            this.lbl_result.Text = "Makine Hazır";
            this.lbl_result.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pic_green
            // 
            this.pic_green.Image = ((System.Drawing.Image)(resources.GetObject("pic_green.Image")));
            this.pic_green.Location = new System.Drawing.Point(101, 56);
            this.pic_green.Name = "pic_green";
            this.pic_green.Size = new System.Drawing.Size(164, 266);
            this.pic_green.TabIndex = 51;
            this.pic_green.TabStop = false;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(this.label3);
            this.groupBox13.Controls.Add(this.lbl_step_cycle);
            this.groupBox13.Controls.Add(this.label4);
            this.groupBox13.Controls.Add(this.led_OKLamp);
            this.groupBox13.Controls.Add(this.led_NOKLamp);
            this.groupBox13.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox13.ForeColor = System.Drawing.Color.SteelBlue;
            this.groupBox13.Location = new System.Drawing.Point(414, 437);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(340, 368);
            this.groupBox13.TabIndex = 51;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Anlik Adimlar";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(25, 221);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(104, 19);
            this.label3.TabIndex = 13;
            this.label3.Text = "OK Lambasi";
            // 
            // lbl_step_cycle
            // 
            this.lbl_step_cycle.Font = new System.Drawing.Font("Tahoma", 60F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_step_cycle.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_step_cycle.Location = new System.Drawing.Point(12, 60);
            this.lbl_step_cycle.Name = "lbl_step_cycle";
            this.lbl_step_cycle.Size = new System.Drawing.Size(319, 97);
            this.lbl_step_cycle.TabIndex = 9;
            this.lbl_step_cycle.Text = "1000";
            this.lbl_step_cycle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Location = new System.Drawing.Point(25, 312);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(116, 19);
            this.label4.TabIndex = 12;
            this.label4.Text = "NOK Lambasi";
            // 
            // led_OKLamp
            // 
            this.led_OKLamp.Color = System.Drawing.Color.Crimson;
            this.led_OKLamp.Location = new System.Drawing.Point(263, 200);
            this.led_OKLamp.Name = "led_OKLamp";
            this.led_OKLamp.On = true;
            this.led_OKLamp.Size = new System.Drawing.Size(60, 60);
            this.led_OKLamp.TabIndex = 10;
            this.led_OKLamp.Text = "led";
            // 
            // led_NOKLamp
            // 
            this.led_NOKLamp.Color = System.Drawing.Color.Crimson;
            this.led_NOKLamp.Location = new System.Drawing.Point(263, 287);
            this.led_NOKLamp.Name = "led_NOKLamp";
            this.led_NOKLamp.On = true;
            this.led_NOKLamp.Size = new System.Drawing.Size(60, 60);
            this.led_NOKLamp.TabIndex = 11;
            this.led_NOKLamp.Text = "led";
            // 
            // pic_DM
            // 
            this.pic_DM.Image = ((System.Drawing.Image)(resources.GetObject("pic_DM.Image")));
            this.pic_DM.Location = new System.Drawing.Point(627, 58);
            this.pic_DM.Name = "pic_DM";
            this.pic_DM.Size = new System.Drawing.Size(110, 129);
            this.pic_DM.TabIndex = 48;
            this.pic_DM.TabStop = false;
            // 
            // pic_tag
            // 
            this.pic_tag.Image = ((System.Drawing.Image)(resources.GetObject("pic_tag.Image")));
            this.pic_tag.Location = new System.Drawing.Point(421, 58);
            this.pic_tag.Name = "pic_tag";
            this.pic_tag.Size = new System.Drawing.Size(121, 129);
            this.pic_tag.TabIndex = 48;
            this.pic_tag.TabStop = false;
            this.pic_tag.Tag = "";
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.pic_blow_off);
            this.groupBox12.Controls.Add(this.pic_blow_on);
            this.groupBox12.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox12.ForeColor = System.Drawing.Color.SteelBlue;
            this.groupBox12.Location = new System.Drawing.Point(414, 225);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(340, 206);
            this.groupBox12.TabIndex = 54;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Ufleme";
            // 
            // pic_blow_off
            // 
            this.pic_blow_off.Image = ((System.Drawing.Image)(resources.GetObject("pic_blow_off.Image")));
            this.pic_blow_off.Location = new System.Drawing.Point(52, 33);
            this.pic_blow_off.Name = "pic_blow_off";
            this.pic_blow_off.Size = new System.Drawing.Size(225, 164);
            this.pic_blow_off.TabIndex = 1;
            this.pic_blow_off.TabStop = false;
            // 
            // pic_blow_on
            // 
            this.pic_blow_on.Image = ((System.Drawing.Image)(resources.GetObject("pic_blow_on.Image")));
            this.pic_blow_on.Location = new System.Drawing.Point(52, 33);
            this.pic_blow_on.Name = "pic_blow_on";
            this.pic_blow_on.Size = new System.Drawing.Size(225, 164);
            this.pic_blow_on.TabIndex = 0;
            this.pic_blow_on.TabStop = false;
            // 
            // groupBox9
            // 
            this.groupBox9.BackColor = System.Drawing.Color.Lavender;
            this.groupBox9.Controls.Add(this.lbl_vacuum_saniye);
            this.groupBox9.Controls.Add(this.pic_Vac_Off);
            this.groupBox9.Controls.Add(this.lbl_vacuum_time);
            this.groupBox9.Controls.Add(this.pic_Vac_On);
            this.groupBox9.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox9.ForeColor = System.Drawing.Color.SteelBlue;
            this.groupBox9.Location = new System.Drawing.Point(19, 225);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(340, 206);
            this.groupBox9.TabIndex = 53;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Vakum Pompasi";
            // 
            // lbl_vacuum_saniye
            // 
            this.lbl_vacuum_saniye.Font = new System.Drawing.Font("Tahoma", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_vacuum_saniye.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_vacuum_saniye.Location = new System.Drawing.Point(183, 123);
            this.lbl_vacuum_saniye.Name = "lbl_vacuum_saniye";
            this.lbl_vacuum_saniye.Size = new System.Drawing.Size(121, 60);
            this.lbl_vacuum_saniye.TabIndex = 54;
            this.lbl_vacuum_saniye.Text = "saniye";
            this.lbl_vacuum_saniye.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pic_Vac_Off
            // 
            this.pic_Vac_Off.Image = ((System.Drawing.Image)(resources.GetObject("pic_Vac_Off.Image")));
            this.pic_Vac_Off.Location = new System.Drawing.Point(42, 33);
            this.pic_Vac_Off.Name = "pic_Vac_Off";
            this.pic_Vac_Off.Size = new System.Drawing.Size(120, 164);
            this.pic_Vac_Off.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pic_Vac_Off.TabIndex = 50;
            this.pic_Vac_Off.TabStop = false;
            // 
            // lbl_vacuum_time
            // 
            this.lbl_vacuum_time.Font = new System.Drawing.Font("Tahoma", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_vacuum_time.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_vacuum_time.Location = new System.Drawing.Point(185, 71);
            this.lbl_vacuum_time.Name = "lbl_vacuum_time";
            this.lbl_vacuum_time.Size = new System.Drawing.Size(121, 60);
            this.lbl_vacuum_time.TabIndex = 53;
            this.lbl_vacuum_time.Text = "100";
            this.lbl_vacuum_time.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pic_Vac_On
            // 
            this.pic_Vac_On.Image = ((System.Drawing.Image)(resources.GetObject("pic_Vac_On.Image")));
            this.pic_Vac_On.Location = new System.Drawing.Point(42, 33);
            this.pic_Vac_On.Name = "pic_Vac_On";
            this.pic_Vac_On.Size = new System.Drawing.Size(120, 164);
            this.pic_Vac_On.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pic_Vac_On.TabIndex = 49;
            this.pic_Vac_On.TabStop = false;
            // 
            // btn_TagDM
            // 
            this.btn_TagDM.ImageAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btn_TagDM.Location = new System.Drawing.Point(550, 55);
            this.btn_TagDM.Name = "btn_TagDM";
            this.btn_TagDM.Size = new System.Drawing.Size(70, 139);
            this.btn_TagDM.TabIndex = 52;
            this.btn_TagDM.Text = "TAG";
            this.btn_TagDM.UseVisualStyleBackColor = true;
            this.btn_TagDM.Click += new System.EventHandler(this.btn_TAGDM_Click);
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(this.label12);
            this.groupBox18.Controls.Add(this.led_auto_button);
            this.groupBox18.Controls.Add(this.label10);
            this.groupBox18.Controls.Add(this.label8);
            this.groupBox18.Controls.Add(this.led_resetbutton);
            this.groupBox18.Controls.Add(this.led_startbutton);
            this.groupBox18.Controls.Add(this.label1);
            this.groupBox18.Controls.Add(this.led_PartPresence);
            this.groupBox18.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox18.ForeColor = System.Drawing.Color.SteelBlue;
            this.groupBox18.Location = new System.Drawing.Point(19, 437);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(340, 368);
            this.groupBox18.TabIndex = 50;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Genel Veriler";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label12.Location = new System.Drawing.Point(25, 130);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(148, 19);
            this.label12.TabIndex = 10;
            this.label12.Text = "Otomatik Butonu";
            // 
            // led_auto_button
            // 
            this.led_auto_button.Color = System.Drawing.Color.Crimson;
            this.led_auto_button.Location = new System.Drawing.Point(263, 113);
            this.led_auto_button.Name = "led_auto_button";
            this.led_auto_button.On = true;
            this.led_auto_button.Size = new System.Drawing.Size(60, 60);
            this.led_auto_button.TabIndex = 9;
            this.led_auto_button.Text = "led";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label10.Location = new System.Drawing.Point(25, 221);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(161, 19);
            this.label10.TabIndex = 8;
            this.label10.Text = "Cycle Start Butonu";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label8.Location = new System.Drawing.Point(25, 312);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(163, 19);
            this.label8.TabIndex = 7;
            this.label8.Text = "Hata Reset Butonu";
            // 
            // led_resetbutton
            // 
            this.led_resetbutton.Color = System.Drawing.Color.Crimson;
            this.led_resetbutton.Location = new System.Drawing.Point(263, 287);
            this.led_resetbutton.Name = "led_resetbutton";
            this.led_resetbutton.On = true;
            this.led_resetbutton.Size = new System.Drawing.Size(60, 60);
            this.led_resetbutton.TabIndex = 6;
            this.led_resetbutton.Text = "led";
            // 
            // led_startbutton
            // 
            this.led_startbutton.Color = System.Drawing.Color.Crimson;
            this.led_startbutton.Location = new System.Drawing.Point(263, 200);
            this.led_startbutton.Name = "led_startbutton";
            this.led_startbutton.On = true;
            this.led_startbutton.Size = new System.Drawing.Size(60, 60);
            this.led_startbutton.TabIndex = 4;
            this.led_startbutton.Text = "led";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(25, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(108, 19);
            this.label1.TabIndex = 3;
            this.label1.Text = "Parca Varlik";
            // 
            // led_PartPresence
            // 
            this.led_PartPresence.Color = System.Drawing.Color.Crimson;
            this.led_PartPresence.Location = new System.Drawing.Point(263, 26);
            this.led_PartPresence.Name = "led_PartPresence";
            this.led_PartPresence.On = true;
            this.led_PartPresence.Size = new System.Drawing.Size(60, 60);
            this.led_PartPresence.TabIndex = 1;
            this.led_PartPresence.Text = "led";
            // 
            // grp_traceability
            // 
            this.grp_traceability.Controls.Add(this.pic_NoDBConnect);
            this.grp_traceability.Controls.Add(this.pic_DBConnect);
            this.grp_traceability.Controls.Add(this.lbl_Traceability1);
            this.grp_traceability.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.grp_traceability.ForeColor = System.Drawing.Color.SteelBlue;
            this.grp_traceability.Location = new System.Drawing.Point(800, 225);
            this.grp_traceability.Name = "grp_traceability";
            this.grp_traceability.Size = new System.Drawing.Size(340, 206);
            this.grp_traceability.TabIndex = 46;
            this.grp_traceability.TabStop = false;
            this.grp_traceability.Text = "Izlenebilirlik Durumu";
            // 
            // pic_NoDBConnect
            // 
            this.pic_NoDBConnect.Image = ((System.Drawing.Image)(resources.GetObject("pic_NoDBConnect.Image")));
            this.pic_NoDBConnect.Location = new System.Drawing.Point(247, 80);
            this.pic_NoDBConnect.Name = "pic_NoDBConnect";
            this.pic_NoDBConnect.Size = new System.Drawing.Size(64, 64);
            this.pic_NoDBConnect.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pic_NoDBConnect.TabIndex = 4;
            this.pic_NoDBConnect.TabStop = false;
            // 
            // pic_DBConnect
            // 
            this.pic_DBConnect.Image = ((System.Drawing.Image)(resources.GetObject("pic_DBConnect.Image")));
            this.pic_DBConnect.Location = new System.Drawing.Point(247, 80);
            this.pic_DBConnect.Name = "pic_DBConnect";
            this.pic_DBConnect.Size = new System.Drawing.Size(64, 64);
            this.pic_DBConnect.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pic_DBConnect.TabIndex = 3;
            this.pic_DBConnect.TabStop = false;
            // 
            // lbl_Traceability1
            // 
            this.lbl_Traceability1.AutoSize = true;
            this.lbl_Traceability1.Location = new System.Drawing.Point(6, 104);
            this.lbl_Traceability1.Name = "lbl_Traceability1";
            this.lbl_Traceability1.Size = new System.Drawing.Size(168, 19);
            this.lbl_Traceability1.TabIndex = 2;
            this.lbl_Traceability1.Text = "İzlenebilirlik Kapalı";
            // 
            // grp_Tag
            // 
            this.grp_Tag.Controls.Add(this.lbl_S_Tag);
            this.grp_Tag.Controls.Add(this.txt_Tag2_No);
            this.grp_Tag.Controls.Add(this.txt_Tag_No);
            this.grp_Tag.Controls.Add(this.label5);
            this.grp_Tag.Controls.Add(this.led_TagPresent);
            this.grp_Tag.Controls.Add(this.label9);
            this.grp_Tag.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.grp_Tag.ForeColor = System.Drawing.Color.SteelBlue;
            this.grp_Tag.Location = new System.Drawing.Point(17, 41);
            this.grp_Tag.Name = "grp_Tag";
            this.grp_Tag.Size = new System.Drawing.Size(400, 174);
            this.grp_Tag.TabIndex = 45;
            this.grp_Tag.TabStop = false;
            this.grp_Tag.Text = "Tag Numarası";
            // 
            // lbl_S_Tag
            // 
            this.lbl_S_Tag.AutoSize = true;
            this.lbl_S_Tag.Location = new System.Drawing.Point(7, 69);
            this.lbl_S_Tag.Name = "lbl_S_Tag";
            this.lbl_S_Tag.Size = new System.Drawing.Size(112, 19);
            this.lbl_S_Tag.TabIndex = 10;
            this.lbl_S_Tag.Text = "Sıradaki Tag";
            // 
            // txt_Tag2_No
            // 
            this.txt_Tag2_No.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txt_Tag2_No.Location = new System.Drawing.Point(7, 91);
            this.txt_Tag2_No.Name = "txt_Tag2_No";
            this.txt_Tag2_No.Size = new System.Drawing.Size(356, 30);
            this.txt_Tag2_No.TabIndex = 9;
            this.txt_Tag2_No.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_Tag_No
            // 
            this.txt_Tag_No.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.txt_Tag_No.Location = new System.Drawing.Point(7, 26);
            this.txt_Tag_No.Name = "txt_Tag_No";
            this.txt_Tag_No.Size = new System.Drawing.Size(356, 30);
            this.txt_Tag_No.TabIndex = 8;
            this.txt_Tag_No.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(27, 44);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 19);
            this.label5.TabIndex = 6;
            // 
            // led_TagPresent
            // 
            this.led_TagPresent.Color = System.Drawing.Color.Crimson;
            this.led_TagPresent.Location = new System.Drawing.Point(294, 124);
            this.led_TagPresent.Name = "led_TagPresent";
            this.led_TagPresent.On = true;
            this.led_TagPresent.Size = new System.Drawing.Size(69, 44);
            this.led_TagPresent.TabIndex = 5;
            this.led_TagPresent.Text = "led";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label9.Location = new System.Drawing.Point(178, 146);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(110, 19);
            this.label9.TabIndex = 5;
            this.label9.Text = "Tag Sensoru";
            // 
            // lbl1
            // 
            this.lbl1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.lbl1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl1.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl1.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.lbl1.Location = new System.Drawing.Point(5, 907);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(1747, 41);
            this.lbl1.TabIndex = 16;
            this.lbl1.Text = "MESAJLAR";
            this.lbl1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // tmr_cycle
            // 
            this.tmr_cycle.Tick += new System.EventHandler(this.tmr_cycle_Tick);
            // 
            // lbl12
            // 
            this.lbl12.AutoSize = true;
            this.lbl12.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.lbl12.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl12.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl12.Location = new System.Drawing.Point(196, 918);
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(110, 18);
            this.lbl12.TabIndex = 21;
            this.lbl12.Text = "Cycle Step :";
            // 
            // lbl_step
            // 
            this.lbl_step.AutoSize = true;
            this.lbl_step.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.lbl_step.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_step.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_step.Location = new System.Drawing.Point(309, 919);
            this.lbl_step.Name = "lbl_step";
            this.lbl_step.Size = new System.Drawing.Size(19, 18);
            this.lbl_step.TabIndex = 22;
            this.lbl_step.Text = "0";
            // 
            // lbl_date
            // 
            this.lbl_date.AutoSize = true;
            this.lbl_date.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.lbl_date.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_date.ForeColor = System.Drawing.Color.White;
            this.lbl_date.Location = new System.Drawing.Point(1493, 920);
            this.lbl_date.Name = "lbl_date";
            this.lbl_date.Size = new System.Drawing.Size(108, 18);
            this.lbl_date.TabIndex = 14;
            this.lbl_date.Text = "08.09.2013";
            this.lbl_date.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_time
            // 
            this.lbl_time.AutoSize = true;
            this.lbl_time.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.lbl_time.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_time.ForeColor = System.Drawing.Color.White;
            this.lbl_time.Location = new System.Drawing.Point(1622, 920);
            this.lbl_time.Name = "lbl_time";
            this.lbl_time.Size = new System.Drawing.Size(86, 18);
            this.lbl_time.TabIndex = 15;
            this.lbl_time.Text = "18:56:43";
            this.lbl_time.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_Author
            // 
            this.lbl_Author.AutoSize = true;
            this.lbl_Author.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(250)))), ((int)(((byte)(250)))));
            this.lbl_Author.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_Author.ForeColor = System.Drawing.Color.Navy;
            this.lbl_Author.Location = new System.Drawing.Point(1243, 22);
            this.lbl_Author.Name = "lbl_Author";
            this.lbl_Author.Size = new System.Drawing.Size(62, 16);
            this.lbl_Author.TabIndex = 24;
            this.lbl_Author.Text = "design by";
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(this.groupBox15);
            this.groupBox7.Controls.Add(this.groupBox8);
            this.groupBox7.Controls.Add(this.groupBox4);
            this.groupBox7.Controls.Add(this.groupBox10);
            this.groupBox7.Controls.Add(this.groupBox6);
            this.groupBox7.Controls.Add(this.groupBox2);
            this.groupBox7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox7.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox7.ForeColor = System.Drawing.Color.Crimson;
            this.groupBox7.Location = new System.Drawing.Point(12, 65);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(335, 827);
            this.groupBox7.TabIndex = 14;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Kullanıcı Detayları";
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(this.lbl_pomp_saniye);
            this.groupBox15.Controls.Add(this.lbl_pomp_time);
            this.groupBox15.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox15.ForeColor = System.Drawing.Color.SteelBlue;
            this.groupBox15.Location = new System.Drawing.Point(17, 730);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(299, 87);
            this.groupBox15.TabIndex = 18;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Pompa Calisma Süresi";
            // 
            // lbl_pomp_saniye
            // 
            this.lbl_pomp_saniye.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_pomp_saniye.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_pomp_saniye.Location = new System.Drawing.Point(94, 22);
            this.lbl_pomp_saniye.Name = "lbl_pomp_saniye";
            this.lbl_pomp_saniye.Size = new System.Drawing.Size(123, 62);
            this.lbl_pomp_saniye.TabIndex = 55;
            this.lbl_pomp_saniye.Text = "saniye";
            this.lbl_pomp_saniye.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl_pomp_saniye.Click += new System.EventHandler(this.Label13_Click);
            // 
            // lbl_pomp_time
            // 
            this.lbl_pomp_time.Font = new System.Drawing.Font("Tahoma", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_pomp_time.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbl_pomp_time.Location = new System.Drawing.Point(7, 25);
            this.lbl_pomp_time.Name = "lbl_pomp_time";
            this.lbl_pomp_time.Size = new System.Drawing.Size(87, 59);
            this.lbl_pomp_time.TabIndex = 54;
            this.lbl_pomp_time.Text = "100";
            this.lbl_pomp_time.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(this.btn_count_reset);
            this.groupBox8.Controls.Add(this.lbl_TOTAL);
            this.groupBox8.Controls.Add(this.lbl_NOK);
            this.groupBox8.Controls.Add(this.lbl_OK);
            this.groupBox8.Controls.Add(this.lbl16);
            this.groupBox8.Controls.Add(this.lbl17);
            this.groupBox8.Controls.Add(this.lbl18);
            this.groupBox8.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox8.ForeColor = System.Drawing.Color.SteelBlue;
            this.groupBox8.Location = new System.Drawing.Point(17, 415);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(300, 143);
            this.groupBox8.TabIndex = 27;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Parça Sayıcı";
            // 
            // btn_count_reset
            // 
            this.btn_count_reset.FlatAppearance.BorderColor = System.Drawing.Color.Lavender;
            this.btn_count_reset.FlatAppearance.BorderSize = 0;
            this.btn_count_reset.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Lavender;
            this.btn_count_reset.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Lavender;
            this.btn_count_reset.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_count_reset.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btn_count_reset.ForeColor = System.Drawing.Color.Indigo;
            this.btn_count_reset.Image = ((System.Drawing.Image)(resources.GetObject("btn_count_reset.Image")));
            this.btn_count_reset.Location = new System.Drawing.Point(170, 40);
            this.btn_count_reset.Name = "btn_count_reset";
            this.btn_count_reset.Size = new System.Drawing.Size(105, 88);
            this.btn_count_reset.TabIndex = 16;
            this.btn_count_reset.TabStop = false;
            this.btn_count_reset.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btn_count_reset.UseVisualStyleBackColor = true;
            this.btn_count_reset.Click += new System.EventHandler(this.btn_count_reset_Click);
            this.btn_count_reset.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btn_count_reset_MouseDown);
            this.btn_count_reset.MouseLeave += new System.EventHandler(this.btn_count_reset_MouseLeave);
            // 
            // lbl_TOTAL
            // 
            this.lbl_TOTAL.AutoSize = true;
            this.lbl_TOTAL.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_TOTAL.ForeColor = System.Drawing.Color.RoyalBlue;
            this.lbl_TOTAL.Location = new System.Drawing.Point(101, 109);
            this.lbl_TOTAL.Name = "lbl_TOTAL";
            this.lbl_TOTAL.Size = new System.Drawing.Size(58, 23);
            this.lbl_TOTAL.TabIndex = 5;
            this.lbl_TOTAL.Text = "9999";
            this.lbl_TOTAL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_NOK
            // 
            this.lbl_NOK.AutoSize = true;
            this.lbl_NOK.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_NOK.ForeColor = System.Drawing.Color.Crimson;
            this.lbl_NOK.Location = new System.Drawing.Point(101, 70);
            this.lbl_NOK.Name = "lbl_NOK";
            this.lbl_NOK.Size = new System.Drawing.Size(58, 23);
            this.lbl_NOK.TabIndex = 4;
            this.lbl_NOK.Text = "9999";
            this.lbl_NOK.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_OK
            // 
            this.lbl_OK.AutoSize = true;
            this.lbl_OK.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_OK.ForeColor = System.Drawing.Color.Lime;
            this.lbl_OK.Location = new System.Drawing.Point(101, 27);
            this.lbl_OK.Name = "lbl_OK";
            this.lbl_OK.Size = new System.Drawing.Size(58, 23);
            this.lbl_OK.TabIndex = 3;
            this.lbl_OK.Text = "9999";
            this.lbl_OK.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl16
            // 
            this.lbl16.AutoSize = true;
            this.lbl16.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl16.ForeColor = System.Drawing.Color.SteelBlue;
            this.lbl16.Location = new System.Drawing.Point(5, 109);
            this.lbl16.Name = "lbl16";
            this.lbl16.Size = new System.Drawing.Size(89, 19);
            this.lbl16.TabIndex = 2;
            this.lbl16.Text = "TOPLAM :";
            this.lbl16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl17
            // 
            this.lbl17.AutoSize = true;
            this.lbl17.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl17.ForeColor = System.Drawing.Color.SteelBlue;
            this.lbl17.Location = new System.Drawing.Point(9, 68);
            this.lbl17.Name = "lbl17";
            this.lbl17.Size = new System.Drawing.Size(85, 19);
            this.lbl17.TabIndex = 1;
            this.lbl17.Text = "NOK       :";
            this.lbl17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl18
            // 
            this.lbl18.AutoSize = true;
            this.lbl18.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl18.ForeColor = System.Drawing.Color.SteelBlue;
            this.lbl18.Location = new System.Drawing.Point(10, 27);
            this.lbl18.Name = "lbl18";
            this.lbl18.Size = new System.Drawing.Size(83, 19);
            this.lbl18.TabIndex = 0;
            this.lbl18.Text = "OK         :";
            this.lbl18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.lbl_reset_time);
            this.groupBox4.Controls.Add(this.pic_kayit);
            this.groupBox4.Controls.Add(this.label51);
            this.groupBox4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox4.ForeColor = System.Drawing.Color.SteelBlue;
            this.groupBox4.Location = new System.Drawing.Point(18, 586);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(299, 124);
            this.groupBox4.TabIndex = 26;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Son Resetlenme Zamanı";
            // 
            // lbl_reset_time
            // 
            this.lbl_reset_time.AutoSize = true;
            this.lbl_reset_time.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_reset_time.ForeColor = System.Drawing.Color.Black;
            this.lbl_reset_time.Location = new System.Drawing.Point(106, 64);
            this.lbl_reset_time.Name = "lbl_reset_time";
            this.lbl_reset_time.Size = new System.Drawing.Size(176, 19);
            this.lbl_reset_time.TabIndex = 2;
            this.lbl_reset_time.Text = "08.09.2013 18:56:43";
            this.lbl_reset_time.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pic_kayit
            // 
            this.pic_kayit.Image = ((System.Drawing.Image)(resources.GetObject("pic_kayit.Image")));
            this.pic_kayit.Location = new System.Drawing.Point(4, 25);
            this.pic_kayit.Name = "pic_kayit";
            this.pic_kayit.Size = new System.Drawing.Size(82, 90);
            this.pic_kayit.TabIndex = 6;
            this.pic_kayit.TabStop = false;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label51.ForeColor = System.Drawing.Color.RoyalBlue;
            this.label51.Location = new System.Drawing.Point(101, 82);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(0, 23);
            this.label51.TabIndex = 5;
            this.label51.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(this.pictureBox2);
            this.groupBox10.Controls.Add(this.lbl_userdate);
            this.groupBox10.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox10.ForeColor = System.Drawing.Color.SteelBlue;
            this.groupBox10.Location = new System.Drawing.Point(17, 280);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(299, 116);
            this.groupBox10.TabIndex = 17;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "Giriş Tarihi";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(6, 28);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(84, 82);
            this.pictureBox2.TabIndex = 13;
            this.pictureBox2.TabStop = false;
            // 
            // lbl_userdate
            // 
            this.lbl_userdate.AutoSize = true;
            this.lbl_userdate.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_userdate.ForeColor = System.Drawing.Color.Black;
            this.lbl_userdate.Location = new System.Drawing.Point(96, 54);
            this.lbl_userdate.Name = "lbl_userdate";
            this.lbl_userdate.Size = new System.Drawing.Size(120, 19);
            this.lbl_userdate.TabIndex = 0;
            this.lbl_userdate.Text = "administrator";
            this.lbl_userdate.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(this.pictureBox1);
            this.groupBox6.Controls.Add(this.lbl_userright);
            this.groupBox6.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox6.ForeColor = System.Drawing.Color.SteelBlue;
            this.groupBox6.Location = new System.Drawing.Point(18, 145);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(299, 116);
            this.groupBox6.TabIndex = 16;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Yetkisi";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(2, 28);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(78, 79);
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // lbl_userright
            // 
            this.lbl_userright.AutoSize = true;
            this.lbl_userright.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_userright.ForeColor = System.Drawing.Color.Black;
            this.lbl_userright.Location = new System.Drawing.Point(96, 54);
            this.lbl_userright.Name = "lbl_userright";
            this.lbl_userright.Size = new System.Drawing.Size(120, 19);
            this.lbl_userright.TabIndex = 0;
            this.lbl_userright.Text = "administrator";
            this.lbl_userright.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.pic_user);
            this.groupBox2.Controls.Add(this.lbl_username);
            this.groupBox2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox2.ForeColor = System.Drawing.Color.SteelBlue;
            this.groupBox2.Location = new System.Drawing.Point(14, 34);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(302, 100);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Adı";
            // 
            // pic_user
            // 
            this.pic_user.Image = ((System.Drawing.Image)(resources.GetObject("pic_user.Image")));
            this.pic_user.Location = new System.Drawing.Point(12, 26);
            this.pic_user.Name = "pic_user";
            this.pic_user.Size = new System.Drawing.Size(78, 66);
            this.pic_user.TabIndex = 13;
            this.pic_user.TabStop = false;
            // 
            // lbl_username
            // 
            this.lbl_username.AutoSize = true;
            this.lbl_username.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_username.ForeColor = System.Drawing.Color.Black;
            this.lbl_username.Location = new System.Drawing.Point(132, 54);
            this.lbl_username.Name = "lbl_username";
            this.lbl_username.Size = new System.Drawing.Size(120, 19);
            this.lbl_username.TabIndex = 0;
            this.lbl_username.Text = "administrator";
            this.lbl_username.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lbl_Auto
            // 
            this.lbl_Auto.AutoSize = true;
            this.lbl_Auto.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.lbl_Auto.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_Auto.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_Auto.Location = new System.Drawing.Point(445, 919);
            this.lbl_Auto.Name = "lbl_Auto";
            this.lbl_Auto.Size = new System.Drawing.Size(134, 18);
            this.lbl_Auto.TabIndex = 42;
            this.lbl_Auto.Text = "Otomatik Sarti";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label7.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label7.Location = new System.Drawing.Point(372, 918);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(16, 18);
            this.label7.TabIndex = 43;
            this.label7.Text = "|";
            // 
            // lbl_LifeBit
            // 
            this.lbl_LifeBit.AutoSize = true;
            this.lbl_LifeBit.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.lbl_LifeBit.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_LifeBit.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.lbl_LifeBit.Location = new System.Drawing.Point(55, 918);
            this.lbl_LifeBit.Name = "lbl_LifeBit";
            this.lbl_LifeBit.Size = new System.Drawing.Size(87, 18);
            this.lbl_LifeBit.TabIndex = 44;
            this.lbl_LifeBit.Text = "IO Modul";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.label11.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label11.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label11.Location = new System.Drawing.Point(159, 917);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(16, 18);
            this.label11.TabIndex = 44;
            this.label11.Text = "|";
            // 
            // tmr_blow
            // 
            this.tmr_blow.Tick += new System.EventHandler(this.Tmr_blow_Tick);
            // 
            // tmr_Pomp
            // 
            this.tmr_Pomp.Tick += new System.EventHandler(this.Tmr_Pomp_Tick);
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.cmb_ref);
            this.groupBox3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox3.ForeColor = System.Drawing.Color.SteelBlue;
            this.groupBox3.Location = new System.Drawing.Point(10, 20);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(302, 68);
            this.groupBox3.TabIndex = 22;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Referans Seçimi";
            // 
            // cmb_ref
            // 
            this.cmb_ref.FormattingEnabled = true;
            this.cmb_ref.Location = new System.Drawing.Point(15, 28);
            this.cmb_ref.Name = "cmb_ref";
            this.cmb_ref.Size = new System.Drawing.Size(245, 27);
            this.cmb_ref.TabIndex = 0;
            this.cmb_ref.SelectedIndexChanged += new System.EventHandler(this.cmb_ref_SelectedIndexChanged);
            this.cmb_ref.MouseClick += new System.Windows.Forms.MouseEventHandler(this.cmb_ref_MouseClick);
            // 
            // groupBox11
            // 
            this.groupBox11.Controls.Add(this.lbl_refdesc);
            this.groupBox11.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox11.ForeColor = System.Drawing.Color.SteelBlue;
            this.groupBox11.Location = new System.Drawing.Point(10, 88);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(302, 57);
            this.groupBox11.TabIndex = 24;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "Referans Aciklamasi";
            // 
            // lbl_refdesc
            // 
            this.lbl_refdesc.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_refdesc.ForeColor = System.Drawing.Color.Orange;
            this.lbl_refdesc.Location = new System.Drawing.Point(9, 23);
            this.lbl_refdesc.Name = "lbl_refdesc";
            this.lbl_refdesc.Size = new System.Drawing.Size(283, 23);
            this.lbl_refdesc.TabIndex = 3;
            this.lbl_refdesc.Text = "-";
            this.lbl_refdesc.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // grp_desc1
            // 
            this.grp_desc1.Controls.Add(this.lbl_refval1);
            this.grp_desc1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.grp_desc1.ForeColor = System.Drawing.Color.SteelBlue;
            this.grp_desc1.Location = new System.Drawing.Point(10, 145);
            this.grp_desc1.Name = "grp_desc1";
            this.grp_desc1.Size = new System.Drawing.Size(144, 45);
            this.grp_desc1.TabIndex = 33;
            this.grp_desc1.TabStop = false;
            this.grp_desc1.Text = "Desc1";
            // 
            // lbl_refval1
            // 
            this.lbl_refval1.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_refval1.ForeColor = System.Drawing.Color.Orange;
            this.lbl_refval1.Location = new System.Drawing.Point(12, 19);
            this.lbl_refval1.Name = "lbl_refval1";
            this.lbl_refval1.Size = new System.Drawing.Size(120, 23);
            this.lbl_refval1.TabIndex = 5;
            this.lbl_refval1.Text = "-";
            this.lbl_refval1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // grp_desc3
            // 
            this.grp_desc3.Controls.Add(this.lbl_refval3);
            this.grp_desc3.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.grp_desc3.ForeColor = System.Drawing.Color.SteelBlue;
            this.grp_desc3.Location = new System.Drawing.Point(10, 190);
            this.grp_desc3.Name = "grp_desc3";
            this.grp_desc3.Size = new System.Drawing.Size(144, 45);
            this.grp_desc3.TabIndex = 35;
            this.grp_desc3.TabStop = false;
            this.grp_desc3.Text = "Desc1";
            // 
            // lbl_refval3
            // 
            this.lbl_refval3.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_refval3.ForeColor = System.Drawing.Color.Orange;
            this.lbl_refval3.Location = new System.Drawing.Point(12, 19);
            this.lbl_refval3.Name = "lbl_refval3";
            this.lbl_refval3.Size = new System.Drawing.Size(120, 23);
            this.lbl_refval3.TabIndex = 5;
            this.lbl_refval3.Text = "-";
            this.lbl_refval3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // grp_desc2
            // 
            this.grp_desc2.Controls.Add(this.lbl_refval2);
            this.grp_desc2.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.grp_desc2.ForeColor = System.Drawing.Color.SteelBlue;
            this.grp_desc2.Location = new System.Drawing.Point(168, 145);
            this.grp_desc2.Name = "grp_desc2";
            this.grp_desc2.Size = new System.Drawing.Size(144, 45);
            this.grp_desc2.TabIndex = 55;
            this.grp_desc2.TabStop = false;
            this.grp_desc2.Text = "Desc1";
            // 
            // lbl_refval2
            // 
            this.lbl_refval2.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_refval2.ForeColor = System.Drawing.Color.Orange;
            this.lbl_refval2.Location = new System.Drawing.Point(12, 19);
            this.lbl_refval2.Name = "lbl_refval2";
            this.lbl_refval2.Size = new System.Drawing.Size(120, 23);
            this.lbl_refval2.TabIndex = 5;
            this.lbl_refval2.Text = "-";
            this.lbl_refval2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // grp_desc4
            // 
            this.grp_desc4.Controls.Add(this.lbl_refval4);
            this.grp_desc4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.grp_desc4.ForeColor = System.Drawing.Color.SteelBlue;
            this.grp_desc4.Location = new System.Drawing.Point(168, 190);
            this.grp_desc4.Name = "grp_desc4";
            this.grp_desc4.Size = new System.Drawing.Size(144, 45);
            this.grp_desc4.TabIndex = 58;
            this.grp_desc4.TabStop = false;
            this.grp_desc4.Text = "Desc1";
            // 
            // lbl_refval4
            // 
            this.lbl_refval4.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_refval4.ForeColor = System.Drawing.Color.Orange;
            this.lbl_refval4.Location = new System.Drawing.Point(12, 19);
            this.lbl_refval4.Name = "lbl_refval4";
            this.lbl_refval4.Size = new System.Drawing.Size(120, 23);
            this.lbl_refval4.TabIndex = 5;
            this.lbl_refval4.Text = "-";
            this.lbl_refval4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.grp_desc5);
            this.groupBox1.Controls.Add(this.pic_K9K);
            this.groupBox1.Controls.Add(this.pic_AudiHPv);
            this.groupBox1.Controls.Add(this.pic_HPs);
            this.groupBox1.Controls.Add(this.grp_desc4);
            this.groupBox1.Controls.Add(this.grp_desc2);
            this.groupBox1.Controls.Add(this.grp_desc3);
            this.groupBox1.Controls.Add(this.grp_desc1);
            this.groupBox1.Controls.Add(this.groupBox11);
            this.groupBox1.Controls.Add(this.groupBox3);
            this.groupBox1.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.groupBox1.ForeColor = System.Drawing.Color.Crimson;
            this.groupBox1.Location = new System.Drawing.Point(1549, 65);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(345, 827);
            this.groupBox1.TabIndex = 9;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Referans Detaylari";
            // 
            // grp_desc5
            // 
            this.grp_desc5.Controls.Add(this.lbl_refval5);
            this.grp_desc5.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.grp_desc5.ForeColor = System.Drawing.Color.SteelBlue;
            this.grp_desc5.Location = new System.Drawing.Point(10, 241);
            this.grp_desc5.Name = "grp_desc5";
            this.grp_desc5.Size = new System.Drawing.Size(144, 45);
            this.grp_desc5.TabIndex = 36;
            this.grp_desc5.TabStop = false;
            this.grp_desc5.Text = "Desc1";
            // 
            // lbl_refval5
            // 
            this.lbl_refval5.Font = new System.Drawing.Font("Tahoma", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_refval5.ForeColor = System.Drawing.Color.Orange;
            this.lbl_refval5.Location = new System.Drawing.Point(12, 19);
            this.lbl_refval5.Name = "lbl_refval5";
            this.lbl_refval5.Size = new System.Drawing.Size(120, 23);
            this.lbl_refval5.TabIndex = 5;
            this.lbl_refval5.Text = "-";
            this.lbl_refval5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pic_K9K
            // 
            this.pic_K9K.Image = ((System.Drawing.Image)(resources.GetObject("pic_K9K.Image")));
            this.pic_K9K.Location = new System.Drawing.Point(100, 332);
            this.pic_K9K.Name = "pic_K9K";
            this.pic_K9K.Size = new System.Drawing.Size(143, 392);
            this.pic_K9K.TabIndex = 64;
            this.pic_K9K.TabStop = false;
            // 
            // pic_AudiHPv
            // 
            this.pic_AudiHPv.Image = ((System.Drawing.Image)(resources.GetObject("pic_AudiHPv.Image")));
            this.pic_AudiHPv.Location = new System.Drawing.Point(102, 332);
            this.pic_AudiHPv.Name = "pic_AudiHPv";
            this.pic_AudiHPv.Size = new System.Drawing.Size(142, 392);
            this.pic_AudiHPv.TabIndex = 63;
            this.pic_AudiHPv.TabStop = false;
            this.pic_AudiHPv.Click += new System.EventHandler(this.PictureBox5_Click);
            // 
            // pic_HPs
            // 
            this.pic_HPs.Image = ((System.Drawing.Image)(resources.GetObject("pic_HPs.Image")));
            this.pic_HPs.Location = new System.Drawing.Point(102, 332);
            this.pic_HPs.Name = "pic_HPs";
            this.pic_HPs.Size = new System.Drawing.Size(142, 392);
            this.pic_HPs.TabIndex = 62;
            this.pic_HPs.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.Color.White;
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.pictureBox3.Location = new System.Drawing.Point(1651, 3);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(269, 50);
            this.pictureBox3.TabIndex = 45;
            this.pictureBox3.TabStop = false;
            // 
            // btn_reset
            // 
            this.btn_reset.BackColor = System.Drawing.Color.White;
            this.btn_reset.FlatAppearance.BorderColor = System.Drawing.Color.Lavender;
            this.btn_reset.FlatAppearance.BorderSize = 0;
            this.btn_reset.FlatAppearance.MouseDownBackColor = System.Drawing.Color.SpringGreen;
            this.btn_reset.FlatAppearance.MouseOverBackColor = System.Drawing.Color.CornflowerBlue;
            this.btn_reset.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_reset.Image = ((System.Drawing.Image)(resources.GetObject("btn_reset.Image")));
            this.btn_reset.Location = new System.Drawing.Point(1742, 907);
            this.btn_reset.Name = "btn_reset";
            this.btn_reset.Size = new System.Drawing.Size(180, 169);
            this.btn_reset.TabIndex = 17;
            this.btn_reset.UseVisualStyleBackColor = false;
            this.btn_reset.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btn_reset_MouseDown);
            this.btn_reset.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_reset_MouseUp);
            // 
            // led_LifeBit
            // 
            this.led_LifeBit.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.led_LifeBit.Color = System.Drawing.Color.Crimson;
            this.led_LifeBit.Location = new System.Drawing.Point(12, 910);
            this.led_LifeBit.Name = "led_LifeBit";
            this.led_LifeBit.On = true;
            this.led_LifeBit.Size = new System.Drawing.Size(35, 35);
            this.led_LifeBit.TabIndex = 46;
            this.led_LifeBit.Text = "led";
            // 
            // ledAuto
            // 
            this.ledAuto.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.ledAuto.Color = System.Drawing.Color.Crimson;
            this.ledAuto.Location = new System.Drawing.Point(401, 910);
            this.ledAuto.Name = "ledAuto";
            this.ledAuto.On = true;
            this.ledAuto.Size = new System.Drawing.Size(35, 35);
            this.ledAuto.TabIndex = 41;
            this.ledAuto.Text = "led";
            // 
            // FrmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.ClientSize = new System.Drawing.Size(1926, 1044);
            this.ControlBox = false;
            this.Controls.Add(this.led_LifeBit);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.pictureBox3);
            this.Controls.Add(this.lbl_LifeBit);
            this.Controls.Add(this.btn_reset);
            this.Controls.Add(this.ledAuto);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.lbl_Auto);
            this.Controls.Add(this.lbl_date);
            this.Controls.Add(this.lbl_time);
            this.Controls.Add(this.lbl_step);
            this.Controls.Add(this.lbl12);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.groupBox7);
            this.Controls.Add(this.lbl_Author);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.lbl_info);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FrmMain_FormClosing);
            this.Load += new System.EventHandler(this.FrmMain_Load);
            this.Move += new System.EventHandler(this.FrmMain_Move);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.grp_DM.ResumeLayout(false);
            this.grp_DM.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pic_red)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_yellow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_green)).EndInit();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_DM)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_tag)).EndInit();
            this.groupBox12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pic_blow_off)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_blow_on)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Vac_Off)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_Vac_On)).EndInit();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            this.grp_traceability.ResumeLayout(false);
            this.grp_traceability.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_NoDBConnect)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_DBConnect)).EndInit();
            this.grp_Tag.ResumeLayout(false);
            this.grp_Tag.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            this.groupBox15.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_kayit)).EndInit();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pic_user)).EndInit();
            this.groupBox3.ResumeLayout(false);
            this.groupBox11.ResumeLayout(false);
            this.grp_desc1.ResumeLayout(false);
            this.grp_desc3.ResumeLayout(false);
            this.grp_desc2.ResumeLayout(false);
            this.grp_desc4.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.grp_desc5.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pic_K9K)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_AudiHPv)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pic_HPs)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userMenuItem;
        private System.Windows.Forms.ToolStripMenuItem useraddMenuItem;
        private System.Windows.Forms.ToolStripMenuItem passwordchangeMenuItem;
        private System.Windows.Forms.ToolStripMenuItem userswitchMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutMenuItem;
        private System.Windows.Forms.Label lbl_info;
        private System.Windows.Forms.ToolStripMenuItem settingsMenuItem;
        private System.Windows.Forms.ToolStripMenuItem referenceMenuItem;
        private System.Windows.Forms.Timer tmr_datentime;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Timer tmr_cycle;
        private System.Windows.Forms.Button btn_reset;
        private System.Windows.Forms.Label lbl12;
        private System.Windows.Forms.Label lbl_step;
        private System.Windows.Forms.ToolStripMenuItem toolsMenuItem;
        private System.Windows.Forms.ToolStripMenuItem notepadMenuItem;
        private System.Windows.Forms.ToolStripMenuItem calcStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem oskMenuItem;
        private System.Windows.Forms.Label lbl_date;
        private System.Windows.Forms.Label lbl_time;
        private System.Windows.Forms.ToolStripMenuItem recordsMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportMenuItem;
        private System.Windows.Forms.ToolStripMenuItem Manual_MenuItem;
        private System.Windows.Forms.ToolStripMenuItem ManualMenuItem;
        private System.Windows.Forms.Label lbl_Author;
        private System.Windows.Forms.ToolStripMenuItem databaseMenuItem;
        private System.Windows.Forms.ToolStripMenuItem permissionsMenuItem;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label lbl_userdate;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lbl_userright;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.PictureBox pic_user;
        private System.Windows.Forms.Label lbl_username;
        private System.Windows.Forms.ToolStripMenuItem IOTestMenuItem;
        private System.Windows.Forms.ToolStripMenuItem InputsMenuItem;
        private System.Windows.Forms.ToolStripMenuItem outputsMenuItem;
        private LedBulb ledAuto;
        private System.Windows.Forms.Label lbl_Auto;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.Button btn_count_reset;
        private System.Windows.Forms.Label lbl_TOTAL;
        private System.Windows.Forms.Label lbl_NOK;
        private System.Windows.Forms.Label lbl_OK;
        private System.Windows.Forms.Label lbl16;
        private System.Windows.Forms.Label lbl17;
        private System.Windows.Forms.Label lbl18;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Label lbl_reset_time;
        private System.Windows.Forms.PictureBox pic_kayit;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.Label lbl_LifeBit;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private LedBulb led_resetbutton;
        private LedBulb led_startbutton;
        private System.Windows.Forms.Label label1;
        private LedBulb led_PartPresence;
        private System.Windows.Forms.GroupBox grp_traceability;
        private System.Windows.Forms.PictureBox pic_tag;
        private System.Windows.Forms.Button btn_TagDM;
        private System.Windows.Forms.GroupBox grp_DM;
        private LedBulb led_DMPresent;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pic_DM;
        private System.Windows.Forms.Label lbl_Traceability1;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.PictureBox pic_Vac_On;
        private System.Windows.Forms.PictureBox pic_Vac_Off;
        private System.Windows.Forms.ToolStripMenuItem ızlenebilirlikToolStripMenuItem;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.PictureBox pic_red;
        private System.Windows.Forms.PictureBox pic_yellow;
        private System.Windows.Forms.Label lbl_result;
        private System.Windows.Forms.PictureBox pic_green;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.Label lbl_step_cycle;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private LedBulb led_auto_button;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private LedBulb led_OKLamp;
        private LedBulb led_NOKLamp;
        private System.Windows.Forms.TextBox txt_DM_No;
        private System.Windows.Forms.GroupBox grp_Tag;
        private System.Windows.Forms.TextBox txt_Tag_No;
        private System.Windows.Forms.Label label5;
        private LedBulb led_TagPresent;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lbl_vacuum_saniye;
        private System.Windows.Forms.Label lbl_vacuum_time;
        private System.Windows.Forms.Timer tmr_blow;
        private System.Windows.Forms.PictureBox pic_NoDBConnect;
        private System.Windows.Forms.PictureBox pic_DBConnect;
        private System.Windows.Forms.Timer tmr_Adventech;
        private LedBulb led_LifeBit;
        private System.Windows.Forms.PictureBox pic_blow_on;
        private System.Windows.Forms.PictureBox pic_blow_off;
        private System.Windows.Forms.Button btn_simDM;
        private System.Windows.Forms.Label lbl_sim;
        private System.Windows.Forms.Label lbl_pomp_saniye;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.Label lbl_pomp_time;
        private System.Windows.Forms.Timer tmr_Pomp;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.ComboBox cmb_ref;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.Label lbl_refdesc;
        private System.Windows.Forms.GroupBox grp_desc1;
        private System.Windows.Forms.Label lbl_refval1;
        private System.Windows.Forms.GroupBox grp_desc3;
        private System.Windows.Forms.Label lbl_refval3;
        private System.Windows.Forms.GroupBox grp_desc2;
        private System.Windows.Forms.Label lbl_refval2;
        private System.Windows.Forms.GroupBox grp_desc4;
        private System.Windows.Forms.Label lbl_refval4;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.PictureBox pic_K9K;
        private System.Windows.Forms.PictureBox pic_AudiHPv;
        private System.Windows.Forms.PictureBox pic_HPs;
        private System.Windows.Forms.GroupBox grp_desc5;
        private System.Windows.Forms.Label lbl_refval5;
        private System.Windows.Forms.Label lbl_S_DM;
        private System.Windows.Forms.TextBox txt_DM2_No;
        private System.Windows.Forms.Label lbl_S_Tag;
        private System.Windows.Forms.TextBox txt_Tag2_No;
    }
}