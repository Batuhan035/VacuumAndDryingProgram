﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//Ini
using Ini;
//Text Write
using System.IO;
//Excel
using System.Data.OleDb;

using DelphiSoft.Classes;

namespace DelphiSoft
{
    public partial class FrmQuery : Form
    {
        //For Stored Procedures
        StoredProcedures SP = new StoredProcedures();
        //For Ini Files
        IniFile ini_config = new IniFile(System.IO.Directory.GetCurrentDirectory() + @"\Config.ini");

        public FrmQuery()
        {
            InitializeComponent();
        }
        private void FrmQuery_Load(object sender, EventArgs e)
        {
            //Load Radiobutton
            rad_date.Checked = true;
            rad_dm.Checked = false;
            rad_tagno.Checked = false;
            grp_first.Visible = true;
            grp_last.Visible = true;
            grp_dm.Visible = false;
            txt_data.Text = "";

            //Label Query False
            lbl_query_info.Visible = false;

            //Date Start
            date_start.Format = DateTimePickerFormat.Custom;
            date_start.CustomFormat = "dd/MM/yyyy hh:mm";
           
            date_finish.Format = DateTimePickerFormat.Custom;
            date_finish.CustomFormat = "dd/MM/yyyy hh:mm";
            
            // Datagridview
            dataGridView1.AllowUserToAddRows = false;
                dataGridView1.AllowUserToDeleteRows = false;
                dataGridView1.AllowUserToResizeRows = false;
                dataGridView1.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
                dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
                dataGridView1.ColumnHeadersHeight = 40;
                dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
                dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;

                dataGridView1.EnableHeadersVisualStyles = false;
                dataGridView1.TopLeftHeaderCell.Style.BackColor = Color.White;
                dataGridView1.ColumnHeadersDefaultCellStyle.BackColor = Color.SteelBlue;
                dataGridView1.ColumnHeadersDefaultCellStyle.ForeColor = Color.White;
                dataGridView1.ClearSelection();

                //Yesterday
                date_start.Value = DateTime.Now.AddDays(-1);
                //Tomorrow
                date_finish.Value = DateTime.Now.AddDays(1);
        }
        
   

        private void rad_dm_CheckedChanged(object sender, EventArgs e)
        {
            CheckRad();
        }

        private void CheckRad()
        {
            if (!rad_date.Checked)
            {
                grp_first.Visible = false;
                grp_last.Visible = false;
                grp_dm.Visible = true;
                txt_data.Text = "";
            }
            else
            {
                grp_first.Visible = true;
                grp_last.Visible = true;
                grp_dm.Visible = false;
                txt_data.Text = "";
            }

            if (rad_dm.Checked)
            {
                grp_dm.Text = "Dm Numarasi";
            }
            else
            {
                grp_dm.Text = "Tag Numarasi";
            }

        }
        private void btn_query_Click(object sender, EventArgs e)
        {
            if (rad_date.Checked)
            {
                DateTime D1 = Convert.ToDateTime(date_start.Text);
                DateTime D2 = Convert.ToDateTime(date_finish.Text);


                //SP
                dataGridView1.DataSource = SP.GetDateReport(D1, D2);
            }
            else if (rad_tagno.Checked)
            {
                //SP
                dataGridView1.DataSource = SP.GetCompReport(txt_data.Text, 0);
            }
            else if (rad_dm.Checked)
            {
                //SP
                dataGridView1.DataSource = SP.GetCompReport(txt_data.Text,1);
            }
           

        }

        private void btn_export_Click(object sender, EventArgs e)
        {
            delphiHelper.ExportToExcel(dataGridView1);
        //    FolderBrowserDialog fbd = new FolderBrowserDialog();
        //    fbd.Description = "Raporu kaydetmek istediğiniz klasörü seçiniz. Rapor, tarih+zaman formatında kaydedilecektir.";
        //    DialogResult result = fbd.ShowDialog();
        //    string FilePath = "";
        //    if (result == DialogResult.OK)
        //    {
        //        FilePath = fbd.SelectedPath + @"\" + DateTime.Now.ToString().Replace(':', '.') + ".xls";
        //    }
        //    else
        //    {
        //        return;
        //    }
        //    try
        //    {
        //        writeCSV(dataGridView1, FilePath);
        //        MessageBox.Show("Rapor " +FilePath +" olarak kaydedildi.", "Rapor Sonucu", MessageBoxButtons.OK, MessageBoxIcon.Information);
        //    }
        //    catch(Exception hata)
        //    {
        //        MessageBox.Show( hata.ToString(), "Dosya Kayıt Hatası", MessageBoxButtons.OK, MessageBoxIcon.Error);
        //    }
        }

       
        //public void writeCSV(DataGridView gridIn, string outputFile)
        //{
        //    //test to see if the DataGridView has any rows
        //    if (gridIn.RowCount > 0)
        //    {
        //        string value = "";
        //        DataGridViewRow dr = new DataGridViewRow();
        //        StreamWriter swOut = new StreamWriter(outputFile);

        //        //write header rows to csv
        //        for (int i = 0; i <= gridIn.Columns.Count - 1; i++)
        //        {
        //            if (i > 0)
        //            {
        //                swOut.Write(",");
        //            }
        //            swOut.Write(gridIn.Columns[i].HeaderText);
        //        }

        //        swOut.WriteLine();

        //        //write DataGridView rows to csv
        //        for (int j = 0; j <= gridIn.Rows.Count - 1; j++)
        //        {
        //            if (j > 0)
        //            {
        //                swOut.WriteLine();
        //            }

        //            dr = gridIn.Rows[j];

        //            for (int i = 0; i <= gridIn.Columns.Count - 1; i++)
        //            {
        //                if (i > 0)
        //                {
        //                    swOut.Write(",");
        //                }

        //                value = dr.Cells[i].Value.ToString();
        //                //replace comma's with spaces
        //                value = value.Replace(',', ' ');
        //                //replace embedded newlines with spaces
        //                value = value.Replace(Environment.NewLine, " ");

        //                swOut.Write(value);
        //            }
        //        }
        //        swOut.Close();
        //    }
        //}

        private void Date_finish_ValueChanged(object sender, EventArgs e)
        {

        }

       
    }
}