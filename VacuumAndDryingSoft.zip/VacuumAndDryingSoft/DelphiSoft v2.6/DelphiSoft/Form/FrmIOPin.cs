﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DelphiSoft
{
    public partial class FrmIOPin : Form
    {
        public FrmIOPin()
        {
            InitializeComponent();
        }

        private void FrmIOPin_FormClosing(object sender, FormClosingEventArgs e)
        {
            e.Cancel = true;
            this.Hide();
            this.Parent = null;
        }

        
    }
}
