﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//Ini
using Ini;
//Text Write
using System.IO;

namespace DelphiSoft
{
    public partial class FrmRefSettings : Form
    {
        //For Stored Procedures
        StoredProcedures SP = new StoredProcedures();
        //For Ini Files
        IniFile ini_config = new IniFile(System.IO.Directory.GetCurrentDirectory() + @"\Config.ini");

        //All References
        DataTable all_ref_table = new DataTable();

        //Edit Reference
        string Edit_RefName;

        //OK Buton
        string Button_Task;

        //Dynamic TextBox and Label
        private TextBox[] textBoxes = null;
        private Label[] labels = null;
        private int ColumnCount = 0;
        private static int DynamicOffsetLeft = 3;
        private static int DynamicOffsetRight = 2;
       
        
        public FrmRefSettings()
        {
            InitializeComponent();
        }
        private void FrmRefSettings_Load(object sender, EventArgs e)
        {
            // Configure the DataGridView so that users can manually change 
            // only the column widths, which are set to fill mode. 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AllowUserToResizeRows = false;
            dataGridView1.RowHeadersWidthSizeMode =  DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dataGridView1.ColumnHeadersHeight = 40;
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridView1.AutoResizeColumns();
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.AllCells;

            //Delete Button
            DataGridViewImageColumn img_delete = new DataGridViewImageColumn();
            Image image_delete = Image.FromFile(System.IO.Directory.GetCurrentDirectory() + @"\images\DeleteButton.png");
            img_delete.Image = image_delete;
            dataGridView1.Columns.Add(img_delete);
            img_delete.HeaderText = "Sil";
            img_delete.Name = "Delete";

            //Edit Button
            DataGridViewImageColumn img_edit = new DataGridViewImageColumn();
            Image image_edit = Image.FromFile(System.IO.Directory.GetCurrentDirectory() + @"\images\EditButton.png");
            img_edit.Image = image_edit;
            dataGridView1.Columns.Add(img_edit);
            img_edit.HeaderText = "Edt";
            img_edit.Name = "Edit";

            
            //Get All References with SP
            dataGridView1.DataSource = SP.GetAllReferences(GLB.MachineID,GLB.OperationNo,GLB.FixtureNo);
                       
                dataGridView1.EnableHeadersVisualStyles = false;
                dataGridView1.TopLeftHeaderCell.Style.BackColor = Color.White;
                dataGridView1.Columns[0].HeaderCell.Style.BackColor = Color.White;
                dataGridView1.Columns[1].HeaderCell.Style.BackColor = Color.White;
            
            dataGridView1.Columns[dataGridView1.ColumnCount - 1].AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
            dataGridView1.ClearSelection();
         
            //Group Box
            groupBox1.Visible = false;
            groupBox1.AutoSize = true;
            //this.AutoScroll = true;
            ColumnCount = dataGridView1.Columns.Count;
            CreateDynamicObjetcs(ColumnCount - DynamicOffsetLeft - DynamicOffsetRight);
      
        }
        private void dataGridView1_CellPainting(object sender, DataGridViewCellPaintingEventArgs e)
        {
            //TopLeft Cell
            if (e.RowIndex == -1 && e.ColumnIndex == -1)
            {
                Image img = Image.FromFile(System.IO.Directory.GetCurrentDirectory() + @"\images\AddButton.png");
                e.Paint(e.CellBounds, DataGridViewPaintParts.All & ~DataGridViewPaintParts.ContentForeground);
                e.Graphics.DrawImage(img, e.CellBounds);
                e.Handled = true;
            }
            //Column 0
            if (e.RowIndex == -1 && e.ColumnIndex == 0)
            {
                Image img2 = Image.FromFile(System.IO.Directory.GetCurrentDirectory() + @"\images\DelHeader.png");
                e.Paint(e.CellBounds, DataGridViewPaintParts.All & ~DataGridViewPaintParts.ContentForeground);
                e.Graphics.DrawImage(img2, e.CellBounds);
                e.Handled = true;
            }
            //Column 0
            if (e.RowIndex == -1 && e.ColumnIndex == 1)
            {
                Image img3 = Image.FromFile(System.IO.Directory.GetCurrentDirectory() + @"\images\EditHeader.png");
                e.Paint(e.CellBounds, DataGridViewPaintParts.All & ~DataGridViewPaintParts.ContentForeground);
                e.Graphics.DrawImage(img3, e.CellBounds);
                e.Handled = true;
            }

        }
        private void btn_add_Click(object sender, EventArgs e)
        {
            //Get Reference Parameters
            string SpParameter=string.Empty;
            for (int i = 0; i < ColumnCount - DynamicOffsetLeft - DynamicOffsetRight; i++)
            {
                SpParameter = SpParameter + ";" + cmb_ref.Text + textBoxes[i].Text;
            }

            //Remove first char
            SpParameter = SpParameter.Remove(0, 1);
           
                if (Button_Task == "Add")
                {
                                  if (SP.AddReference(
                                      GLB.MachineID,
                                    GLB.OperationNo,
                                    GLB.FixtureNo,
                                          cmb_ref.Text,
                                          textBoxes[4].Text,
                                          textBoxes[5].Text,
                                          textBoxes[6].Text,
                                          textBoxes[7].Text,
                                          textBoxes[8].Text,
                                          textBoxes[9].Text,
                                          textBoxes[10].Text,
                                          textBoxes[11].Text,
                                          textBoxes[12].Text,
                                          textBoxes[13].Text,
                                          textBoxes[14].Text,
                                          textBoxes[15].Text,
                                          textBoxes[16].Text,
                                          textBoxes[17].Text,
                                          textBoxes[18].Text,
                                          textBoxes[19].Text,
                                          textBoxes[20].Text,
                                          textBoxes[21].Text,
                                          textBoxes[22].Text,
                                          textBoxes[23].Text,
                                          textBoxes[24].Text,
                                          textBoxes[25].Text,
                                          textBoxes[26].Text,
                                          textBoxes[27].Text,
                                          textBoxes[28].Text,
                                          textBoxes[29].Text,
                                          textBoxes[30].Text,
                                          textBoxes[31].Text,
                                          textBoxes[32].Text,
                                          textBoxes[33].Text,
                                          textBoxes[34].Text,
                                          textBoxes[35].Text,
                                          textBoxes[36].Text,
                                          textBoxes[37].Text,
                                          textBoxes[38].Text,
                                          textBoxes[39].Text,
                                          textBoxes[40].Text,
                                          textBoxes[41].Text,
                                          textBoxes[42].Text,
                                          textBoxes[43].Text,
                                          textBoxes[44].Text,
                                          textBoxes[45].Text,
                                          textBoxes[46].Text,
                                          textBoxes[47].Text,
                                          textBoxes[48].Text,
                                          textBoxes[49].Text,
                                          textBoxes[50].Text,
                                          textBoxes[51].Text,
                                          textBoxes[52].Text,
                                          textBoxes[53].Text,
                                          textBoxes[54].Text,
                                          textBoxes[55].Text,
                                          textBoxes[56].Text,
                                          textBoxes[57].Text,
                                          textBoxes[58].Text,
                                          textBoxes[59].Text,
                                          textBoxes[60].Text,
                                          textBoxes[61].Text,
                                          textBoxes[62].Text,
                                          textBoxes[63].Text,
                                          textBoxes[64].Text

                                          )) return;
                }
            else
            {
                if (SP.UpdateReference(
                       GLB.MachineID,
                    GLB.OperationNo,
                    GLB.FixtureNo,
                    cmb_ref.Text,
                    textBoxes[4].Text,
                                          textBoxes[5].Text,
                                          textBoxes[6].Text,
                                          textBoxes[7].Text,
                                          textBoxes[8].Text,
                                          textBoxes[9].Text,
                                          textBoxes[10].Text,
                                          textBoxes[11].Text,
                                          textBoxes[12].Text,
                                          textBoxes[13].Text,
                                          textBoxes[14].Text,
                                          textBoxes[15].Text,
                                          textBoxes[16].Text,
                                          textBoxes[17].Text,
                                          textBoxes[18].Text,
                                          textBoxes[19].Text,
                                          textBoxes[20].Text,
                                          textBoxes[21].Text,
                                          textBoxes[22].Text,
                                          textBoxes[23].Text,
                                          textBoxes[24].Text,
                                          textBoxes[25].Text,
                                          textBoxes[26].Text,
                                          textBoxes[27].Text,
                                          textBoxes[28].Text,
                                          textBoxes[29].Text,
                                          textBoxes[30].Text,
                                          textBoxes[31].Text,
                                          textBoxes[32].Text,
                                          textBoxes[33].Text,
                                          textBoxes[34].Text,
                                          textBoxes[35].Text,
                                          textBoxes[36].Text,
                                          textBoxes[37].Text,
                                          textBoxes[38].Text,
                                          textBoxes[39].Text,
                                          textBoxes[40].Text,
                                          textBoxes[41].Text,
                                          textBoxes[42].Text,
                                          textBoxes[43].Text,
                                          textBoxes[44].Text,
                                          textBoxes[45].Text,
                                          textBoxes[46].Text,
                                          textBoxes[47].Text,
                                          textBoxes[48].Text,
                                          textBoxes[49].Text,
                                          textBoxes[50].Text,
                                          textBoxes[51].Text,
                                          textBoxes[52].Text,
                                          textBoxes[53].Text,
                                          textBoxes[54].Text,
                                          textBoxes[55].Text,
                                          textBoxes[56].Text,
                                          textBoxes[57].Text,
                                          textBoxes[58].Text,
                                          textBoxes[59].Text,
                                          textBoxes[60].Text,
                                          textBoxes[61].Text,
                                          textBoxes[62].Text,
                                          textBoxes[63].Text,
                                          textBoxes[64].Text
                    )) return;
            }
            groupBox1.Visible = false;
            dataGridView1.Enabled = true;
            dataGridView1.DataSource = SP.GetAllReferences(GLB.MachineID, GLB.OperationNo,GLB.FixtureNo);
            dataGridView1.RowsDefaultCellStyle.SelectionBackColor = Color.PowderBlue;
            this.dataGridView1.ClearSelection();

            //Update Form Main Combobox
            FrmMain f1 = (FrmMain)Application.OpenForms["FrmMain"];
            f1.UpdateAllReferences();

        }
        private void btn_cancel_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
            dataGridView1.Enabled = true;
            dataGridView1.RowsDefaultCellStyle.SelectionBackColor = Color.PowderBlue;
            this.dataGridView1.ClearSelection();
        }
        private void dataGridView1_CellMouseDown(object sender, DataGridViewCellMouseEventArgs e)
        {
            dataGridView1.Columns[0].DefaultCellStyle.SelectionBackColor = Color.White;
            dataGridView1.Columns[1].DefaultCellStyle.SelectionBackColor = Color.White;

            


            //Get All References to Combobox from TRDB;
            cmb_ref.DataSource = SP.GetAllReferenceFromTRDB();
           

            //ReadOnly Combobox
            cmb_ref.DropDownStyle = ComboBoxStyle.DropDownList;

            //TopLeft
            if (e.RowIndex == -1 && e.ColumnIndex == -1)
            {
                dataGridView1.RowsDefaultCellStyle.SelectionBackColor = Color.White;
                groupBox1.Visible = true;
                groupBox1.Text = "Yeni Referans Ekle";
                dataGridView1.Enabled = false;
                Button_Task = "Add";
                for (int i = 0; i < ColumnCount - DynamicOffsetLeft - DynamicOffsetRight; i++)
                {
                    labels[i].Text = dataGridView1.Columns[i + 3].HeaderText;
                    textBoxes[i].Text = "";
                }

                cmb_ref.Text = cmb_ref.Items[3].ToString();

            }

            //Delete Button Last Column
            if (e.ColumnIndex == 0)
            {
                if (e.RowIndex == -1) return;

                DialogResult sonuc;
                sonuc = MessageBox.Show( dataGridView1.Rows[e.RowIndex].Cells[5].FormattedValue.ToString() + " referansini silmek istediginize emin misiniz ?", "Referans Silme Ekrani", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (sonuc == DialogResult.Yes)
                {
                    SP.DeleteReference(Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[3].FormattedValue.ToString()), Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[4].FormattedValue.ToString()), dataGridView1.Rows[e.RowIndex].Cells[6].FormattedValue.ToString(), Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells[5].FormattedValue.ToString()));
                    //Get All References with SP
                    dataGridView1.DataSource = SP.GetAllReferences(GLB.MachineID, GLB.OperationNo,GLB.FixtureNo);
                }

            }

            //Edit Button
            if (e.ColumnIndex == 1)
            {
                if (e.RowIndex == -1) return;

                Edit_RefName = dataGridView1.Rows[e.RowIndex].Cells[3].FormattedValue.ToString();
                dataGridView1.RowsDefaultCellStyle.SelectionBackColor = Color.White;
                groupBox1.Visible = true;
                groupBox1.Text = "Referans Duzenleme";
                dataGridView1.Enabled = false;
                Button_Task = "Edit";

                for (int i = 0; i < ColumnCount - DynamicOffsetLeft-DynamicOffsetRight; i++)
                {
                    labels[i].Text = dataGridView1.Columns[i+3].HeaderText;
                    textBoxes[i].Text = dataGridView1.Rows[e.RowIndex].Cells[i + DynamicOffsetLeft].FormattedValue.ToString();
                }

                cmb_ref.Text = textBoxes[3].Text;

            }

            textBoxes[0].ReadOnly = true;
            textBoxes[1].ReadOnly = true;
            textBoxes[2].ReadOnly = true;
            textBoxes[0].Text = GLB.MachineID.ToString();
            textBoxes[1].Text = GLB.OperationNo.ToString();
            textBoxes[2].Text = GLB.FixtureNo.ToString();

            cmb_ref.Width = textBoxes[3].Width;
            cmb_ref.Left = textBoxes[3].Left;
            cmb_ref.Top = textBoxes[3].Top;


        }
        private void CreateDynamicObjetcs (int n)
        {


         textBoxes=new TextBox[n];
        labels=new Label[n];
        for (int i = 0; i < n; i++)
        {
            textBoxes[i] = new TextBox();
            textBoxes[i].Size = new System.Drawing.Size(120, 20);
            labels[i] = new Label();
            labels[i].AutoSize = true;
            labels[i].ForeColor = Color.Crimson;
        }

        int Xaxis = 0;
        int TextY = 60;
        int LabelY = 40;
        int Yoffset = 0;
        int k = 0;
            int c = 0;
            

            // This adds the controls to the form (you will need to specify thier co-ordinates etc. first)
            for (int i = 0; i < n; i++)
        {
            groupBox1.Controls.Add(textBoxes[i]);
            groupBox1.Controls.Add(labels[i]);
            Xaxis = 10 + k * 140;
            labels[i].Location = new System.Drawing.Point(Xaxis, LabelY + Yoffset);
            textBoxes[i].Location = new System.Drawing.Point(Xaxis, TextY + Yoffset);

            if (textBoxes[i].Location.X > 1100)
            {
                Xaxis = 10;
                k = 0;
                Yoffset = Yoffset+ 50;
                labels[i].Location = new System.Drawing.Point(Xaxis, LabelY + Yoffset);
                textBoxes[i].Location = new System.Drawing.Point(Xaxis, TextY + Yoffset);
            }

            k = k + 1;
                c = i;
        }

            btn_add.Left = 430;
            btn_cancel.Left = btn_add.Location.X+ btn_cancel.Width+20;

            btn_add.Top = textBoxes[c].Location.Y + 40;
            btn_cancel.Top = btn_add.Top;

        }
        private void groupBox1_VisibleChanged(object sender, EventArgs e)
        {
            if (groupBox1.Visible)
            {
                dataGridView1.Visible = false;
                this.AutoScroll = true;
            }
            else
            {
                dataGridView1.Visible = true;
                this.AutoScroll = false;
            }
        }

        private void Cmb_ref_SelectedIndexChanged(object sender, EventArgs e)
        {
           textBoxes[3].Text = cmb_ref.Text;
        }
    }
}