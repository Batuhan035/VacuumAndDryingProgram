﻿namespace DelphiSoft
{
    partial class FrmQuery
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FrmQuery));
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btn_query = new System.Windows.Forms.Button();
            this.date_start = new System.Windows.Forms.DateTimePicker();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.grp_first = new System.Windows.Forms.GroupBox();
            this.grp_last = new System.Windows.Forms.GroupBox();
            this.date_finish = new System.Windows.Forms.DateTimePicker();
            this.rad_date = new System.Windows.Forms.RadioButton();
            this.rad_dm = new System.Windows.Forms.RadioButton();
            this.txt_data = new System.Windows.Forms.TextBox();
            this.grp_dm = new System.Windows.Forms.GroupBox();
            this.lbl_query_info = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.rad_tagno = new System.Windows.Forms.RadioButton();
            this.btn_export = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.grp_first.SuspendLayout();
            this.grp_last.SuspendLayout();
            this.grp_dm.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AllowUserToResizeRows = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Cursor = System.Windows.Forms.Cursors.Default;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.dataGridView1.EditMode = System.Windows.Forms.DataGridViewEditMode.EditOnF2;
            this.dataGridView1.GridColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.dataGridView1.Location = new System.Drawing.Point(0, 190);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle5;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView1.Size = new System.Drawing.Size(1014, 542);
            this.dataGridView1.TabIndex = 7;
            // 
            // btn_query
            // 
            this.btn_query.Image = ((System.Drawing.Image)(resources.GetObject("btn_query.Image")));
            this.btn_query.Location = new System.Drawing.Point(546, 55);
            this.btn_query.Name = "btn_query";
            this.btn_query.Size = new System.Drawing.Size(164, 88);
            this.btn_query.TabIndex = 8;
            this.btn_query.UseVisualStyleBackColor = true;
            this.btn_query.Click += new System.EventHandler(this.btn_query_Click);
            // 
            // date_start
            // 
            this.date_start.CalendarForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.date_start.CalendarTitleBackColor = System.Drawing.SystemColors.ControlText;
            this.date_start.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.date_start.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date_start.Location = new System.Drawing.Point(2, 38);
            this.date_start.Name = "date_start";
            this.date_start.Size = new System.Drawing.Size(215, 29);
            this.date_start.TabIndex = 9;
            // 
            // grp_first
            // 
            this.grp_first.Controls.Add(this.date_start);
            this.grp_first.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.grp_first.ForeColor = System.Drawing.Color.Crimson;
            this.grp_first.Location = new System.Drawing.Point(29, 55);
            this.grp_first.Name = "grp_first";
            this.grp_first.Size = new System.Drawing.Size(221, 85);
            this.grp_first.TabIndex = 12;
            this.grp_first.TabStop = false;
            this.grp_first.Text = "Başlangış Tarihi ve Saati";
            // 
            // grp_last
            // 
            this.grp_last.Controls.Add(this.date_finish);
            this.grp_last.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.grp_last.ForeColor = System.Drawing.Color.Crimson;
            this.grp_last.Location = new System.Drawing.Point(288, 55);
            this.grp_last.Name = "grp_last";
            this.grp_last.Size = new System.Drawing.Size(221, 86);
            this.grp_last.TabIndex = 13;
            this.grp_last.TabStop = false;
            this.grp_last.Text = "Bitiş Tarihi ve Saati";
            // 
            // date_finish
            // 
            this.date_finish.AllowDrop = true;
            this.date_finish.CalendarForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.date_finish.CalendarTitleBackColor = System.Drawing.SystemColors.ControlText;
            this.date_finish.CalendarTrailingForeColor = System.Drawing.Color.Gray;
            this.date_finish.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.date_finish.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.date_finish.Location = new System.Drawing.Point(3, 38);
            this.date_finish.Name = "date_finish";
            this.date_finish.Size = new System.Drawing.Size(215, 29);
            this.date_finish.TabIndex = 10;
            this.date_finish.ValueChanged += new System.EventHandler(this.Date_finish_ValueChanged);
            // 
            // rad_date
            // 
            this.rad_date.AutoSize = true;
            this.rad_date.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rad_date.ForeColor = System.Drawing.Color.ForestGreen;
            this.rad_date.Location = new System.Drawing.Point(23, 12);
            this.rad_date.Name = "rad_date";
            this.rad_date.Size = new System.Drawing.Size(72, 22);
            this.rad_date.TabIndex = 16;
            this.rad_date.TabStop = true;
            this.rad_date.Text = "Tarih";
            this.rad_date.UseVisualStyleBackColor = true;
            this.rad_date.CheckedChanged += new System.EventHandler(this.rad_dm_CheckedChanged);
            // 
            // rad_dm
            // 
            this.rad_dm.AutoSize = true;
            this.rad_dm.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rad_dm.ForeColor = System.Drawing.Color.ForestGreen;
            this.rad_dm.Location = new System.Drawing.Point(347, 12);
            this.rad_dm.Name = "rad_dm";
            this.rad_dm.Size = new System.Drawing.Size(83, 22);
            this.rad_dm.TabIndex = 17;
            this.rad_dm.TabStop = true;
            this.rad_dm.Text = "DM No";
            this.rad_dm.UseVisualStyleBackColor = true;
            this.rad_dm.CheckedChanged += new System.EventHandler(this.rad_dm_CheckedChanged);
            // 
            // txt_data
            // 
            this.txt_data.Location = new System.Drawing.Point(15, 39);
            this.txt_data.Name = "txt_data";
            this.txt_data.Size = new System.Drawing.Size(221, 23);
            this.txt_data.TabIndex = 19;
            this.txt_data.Text = "123456789012345678901";
            this.txt_data.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // grp_dm
            // 
            this.grp_dm.Controls.Add(this.txt_data);
            this.grp_dm.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.grp_dm.ForeColor = System.Drawing.Color.Crimson;
            this.grp_dm.Location = new System.Drawing.Point(23, 53);
            this.grp_dm.Name = "grp_dm";
            this.grp_dm.Size = new System.Drawing.Size(249, 87);
            this.grp_dm.TabIndex = 13;
            this.grp_dm.TabStop = false;
            this.grp_dm.Text = "DM No";
            // 
            // lbl_query_info
            // 
            this.lbl_query_info.AutoSize = true;
            this.lbl_query_info.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.lbl_query_info.ForeColor = System.Drawing.Color.Crimson;
            this.lbl_query_info.Location = new System.Drawing.Point(32, 153);
            this.lbl_query_info.Name = "lbl_query_info";
            this.lbl_query_info.Size = new System.Drawing.Size(409, 24);
            this.lbl_query_info.TabIndex = 19;
            this.lbl_query_info.Text = "Sorgulama gerceklestiriliyor...Lutfen bekleyiniz...";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.DarkViolet;
            this.label2.Location = new System.Drawing.Point(593, 145);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 16);
            this.label2.TabIndex = 20;
            this.label2.Text = "SORGULA";
            // 
            // rad_tagno
            // 
            this.rad_tagno.AutoSize = true;
            this.rad_tagno.Font = new System.Drawing.Font("Verdana", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.rad_tagno.ForeColor = System.Drawing.Color.ForestGreen;
            this.rad_tagno.Location = new System.Drawing.Point(147, 12);
            this.rad_tagno.Name = "rad_tagno";
            this.rad_tagno.Size = new System.Drawing.Size(148, 22);
            this.rad_tagno.TabIndex = 21;
            this.rad_tagno.TabStop = true;
            this.rad_tagno.Text = "Tag Numarasi";
            this.rad_tagno.UseVisualStyleBackColor = true;
            this.rad_tagno.CheckedChanged += new System.EventHandler(this.rad_dm_CheckedChanged);
            // 
            // btn_export
            // 
            this.btn_export.Image = ((System.Drawing.Image)(resources.GetObject("btn_export.Image")));
            this.btn_export.Location = new System.Drawing.Point(774, 55);
            this.btn_export.Name = "btn_export";
            this.btn_export.Size = new System.Drawing.Size(91, 88);
            this.btn_export.TabIndex = 31;
            this.btn_export.UseVisualStyleBackColor = true;
            this.btn_export.Click += new System.EventHandler(this.btn_export_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.DarkViolet;
            this.label1.Location = new System.Drawing.Point(771, 145);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(103, 16);
            this.label1.TabIndex = 32;
            this.label1.Text = "Excel\'e Aktar";
            // 
            // FrmQuery
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.ClientSize = new System.Drawing.Size(1014, 732);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_export);
            this.Controls.Add(this.rad_tagno);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.grp_dm);
            this.Controls.Add(this.lbl_query_info);
            this.Controls.Add(this.rad_dm);
            this.Controls.Add(this.rad_date);
            this.Controls.Add(this.grp_last);
            this.Controls.Add(this.grp_first);
            this.Controls.Add(this.btn_query);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "FrmQuery";
            this.ShowInTaskbar = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Lokal Veri Tabanı Sonuclari";
            this.Load += new System.EventHandler(this.FrmQuery_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.grp_first.ResumeLayout(false);
            this.grp_last.ResumeLayout(false);
            this.grp_dm.ResumeLayout(false);
            this.grp_dm.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btn_query;
        private System.Windows.Forms.DateTimePicker date_start;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.GroupBox grp_first;
        private System.Windows.Forms.GroupBox grp_last;
        private System.Windows.Forms.RadioButton rad_date;
        private System.Windows.Forms.RadioButton rad_dm;
        private System.Windows.Forms.TextBox txt_data;
        private System.Windows.Forms.GroupBox grp_dm;
        private System.Windows.Forms.Label lbl_query_info;
        private System.Windows.Forms.DateTimePicker date_finish;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton rad_tagno;
        private System.Windows.Forms.Button btn_export;
        private System.Windows.Forms.Label label1;


    }
}