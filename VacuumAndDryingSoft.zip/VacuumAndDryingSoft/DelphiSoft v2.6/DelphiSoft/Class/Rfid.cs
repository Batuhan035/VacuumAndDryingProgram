﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.IO.Ports;
using System.Windows.Forms;

namespace DelphiSoft
{

    public enum RFID_COMMANDS : byte
    {
        MSG_BEGIN = 0xAA,            // All commands begin with this
        MSG_TERM = 0xFF,             // Message Terminator
        BLK_READ = 0x05,             // Block Read command.
        BLK_WRITE = 0x06,            // Block Write command.
        GET_SERIAL = 0x07,           // Get the tag's serial number.
        TAG_SEARCH = 0x08,           // Search for tag.
        READ_CONTINUOUS = 0x0D,      // Continuous read mode.
        RESET = 0x35                 // Reset Controller.
    }
    public class Rfid    {

        public string RfidValue { get; set; }
        private bool _RfidReady;
        private bool _RfidConnection;
      
        public bool RfidReady
        {
            get 
            {
                if (_RfidReady)
                {
                    _RfidReady = false;
                    return true;
                }
                return _RfidReady;  
            }
            set { _RfidReady = value; }
        }
       
        
        //public const byte MSG_BEGIN = 0xAA;         // All commands begin with this
        //public const byte MSG_TERM = 0xFF;          // Message Terminator
        //public const byte BLK_READ = 0x05;          // Block Read command.
        //public const byte BLK_WRITE = 0x06;         // Block Write command.
        //public const byte GET_SERIAL = 0x07;        // Get the tag's serial number.
        //public const byte TAG_SEARCH = 0x08;        // Search for tag.
        //public const byte READ_CONTINUOUS = 0x0D;    // Continuous read mode.
        //public const byte RESET = 0x35;             // Reset Controller.

        private System.IO.Ports.SerialPort serialPort_RfidReader;

        public Rfid()
        {
            serialPort_RfidReader = new System.IO.Ports.SerialPort(GLB.RfidPortName, 9600, System.IO.Ports.Parity.None, 8, System.IO.Ports.StopBits.One);
            serialPort_RfidReader.NewLine = Convert.ToString(0x03);
            serialPort_RfidReader.DataReceived -= new System.IO.Ports.SerialDataReceivedEventHandler(serialPort_RfidReader_DataReceived);
            serialPort_RfidReader.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(serialPort_RfidReader_DataReceived);
            try
            {
                if (!(serialPort_RfidReader.IsOpen))
                {
                    serialPort_RfidReader.Open();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "COM Port Hatası!!!");
            }
        }

        public void InitializeRfid()
        {
            serialPort_RfidReader = new System.IO.Ports.SerialPort(GLB.RfidPortName, 9600, System.IO.Ports.Parity.None, 8, System.IO.Ports.StopBits.One);
            serialPort_RfidReader.DataReceived -= new System.IO.Ports.SerialDataReceivedEventHandler(serialPort_RfidReader_DataReceived);
            serialPort_RfidReader.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(serialPort_RfidReader_DataReceived);
        }

        public bool ReadRFID()
        {
            //byte[] command = new byte[11];

            //command[0] = 0x02;
            //command[1] = 0x02;
            //command[2] = 0x00;
            //command[3] = 0x06;
            //command[4] = 0x0D;
            //command[5] = 0x00;
            //command[6] = 0x00;
            //command[7] = 0x00;
            //command[8] = 0x10;
            //command[9] = 0x01;
            //command[10] = 0x03;

            byte[] command = new byte[12];

            command[0] = 0x02;
            command[1] = 0x02;
            command[2] = 0x00;
            command[3] = 0x07;
            command[4] = 0x05;
            command[5] = 0x00;
            command[6] = 0x00;
            command[7] = 0x00;
            command[8] = 0x10;
            command[9] = 0x03;
            command[10] = 0xE8;
            command[11] = 0x03;


            try
            {
                if (!serialPort_RfidReader.IsOpen)
                    serialPort_RfidReader.Open();

                serialPort_RfidReader.Write(command, 0, command.Length);
            }
            catch(Exception ex)
            {
                System.Windows.Forms.MessageBox.Show(ex.ToString());
                return false;
            }

            return true;
        }

       
        public bool StopRFID()
        {
            byte[] command = new byte[11];

            command[0] = 0x02;
            command[1] = 0x02;
            command[2] = 0x00;
            command[3] = 0x06;
            command[4] = 0x0D;
            command[5] = 0x00;
            command[6] = 0x00;
            command[7] = 0x00;
            command[8] = 0x00;
            command[9] = 0x01;
            command[10] = 0x03;


            try
            {
                if (!serialPort_RfidReader.IsOpen)
                    serialPort_RfidReader.Open();

                serialPort_RfidReader.Write(command, 0, command.Length);
            }
            catch
            {
                return false;
            }

            RfidValue = "";
            return true;
        }

        public bool WriteRFID(string value)
        {
            byte[] command = new byte[28];

            command[0] = 0x02;
            command[1] = 0x02;
            command[2] = 0x00;
            command[3] = 0x17;
            command[4] = 0x06;
            command[5] = 0x00;
            command[6] = 0x00;
            command[7] = 0x00;
            command[8] = 0x10;
            command[9] = 0x03;
            command[10] = 0xE8;
            command[11] = (byte)value[0];
            command[12] = (byte)value[1];
            command[13] = (byte)value[2];
            command[14] = (byte)value[3];
            command[15] = (byte)value[4];
            command[16] = (byte)value[5];
            command[17] = (byte)value[6];
            command[18] = (byte)value[7];
            command[19] = (byte)value[8];
            command[20] = (byte)value[9];
            command[21] = (byte)value[10];
            command[22] = (byte)value[11];
            command[23] = (byte)value[12];
            command[24] = (byte)value[13];
            command[25] = (byte)value[14];
            command[26] = (byte)value[15];
            command[27] = 0x03;

            try
            {
                if (!serialPort_RfidReader.IsOpen)
                    serialPort_RfidReader.Open();

                serialPort_RfidReader.Write(command, 0, command.Length);
            }
            catch
            {
                return false;
            }

            return true;
        }

        private void serialPort_RfidReader_DataReceived(object sender, System.IO.Ports.SerialDataReceivedEventArgs e)
        {
            string line = "";

            try
            {
                while (!line.Contains(Convert.ToChar(0x03)))
                    line = line + serialPort_RfidReader.ReadExisting();
                GLB.RfidError = "";
            }
            catch (Exception ex)
            {
                GLB.RfidError = ex.ToString();
            }

            if (line.Length > 21)
            {
                //this.RfidValue = line.Substring(line.IndexOf("\r") + 1, 16);
                this.RfidValue = line.Substring(5, 16);
                this._RfidReady = true;
            }
            else
            {
                RfidValue = "";
            }
        }
    

    }
   
}

