﻿using DelphiSoft;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DelphiSoft
{
    public static class GLB
    {
       
      
        //Adventech Name
        public static string Adventech_Name;

       
        //User 
        public static string[] AllUsers;
        public static string[] PartReferenceNames;
        public static string UserName;
        public static string UserPassword;
        public static string UserRight;
        //Project
        public static string ProjectName;
        public static string ProjectAuthor;
        public static string ProjectDate;
        //SQL
        public static string Sql_Conn_String="";
        public static string Sql_Conn_String2;
        //Traceability
        public static bool Traceability;
        public static string TraceResult="";
        public static string SpResult = "";
        public static int MachineID;
        public static int OperationNo;
        public static int FixtureNo;
        public static string TraceabilityType = "";
        public static string TagNo = "";

        //Cycle
        public static int Step;
        public static bool Alarm;
        public static bool Emergency_Alarm;
        public static bool Inprogress;
        //Counter
        public static int CountOK;
        public static int CountNOK;
        public static int CountTOTAL;
        //Info Panel
        public static string[] InfoID;
        public static string[] InfoDesc;
        public static string[] InfoColor;
        //Rfid ST1
        public static string RfidPortName;
        public static int RfidBaudRate;
        public static Rfid RfidReader;
        public static string RfidError;


        //Inputs
        public static bool I_Part_Presence;
        public static bool I_Tag_Sensor;
        public static bool I_Alarm_Reset;
        public static bool I_Cycle_Start;
        public static bool I_Auto;
        public static bool I_Emergency_Stop;
        public static bool I_Termik_Ikaz;
        public static bool I_OilTank;
        //Sim_Inputs
        public static string Sim_Active;
        public static bool Sim_I_Part_Presence;
        public static bool Sim_I_Tag_Sensor;
        public static bool Sim_I_Alarm_Reset;
        public static bool Sim_I_Cycle_Start;
        public static bool Sim_I_Auto;
        public static bool Sim_I_Emergency_Stop;
        public static bool Sim_I_Termik_Ikaz;
        public static bool Sim_I_OilTank;
        //Outputs
        public static bool Q_Vacuum_Start;
        public static bool Q_Blow_Start;
        public static bool Q_Tag_Read_Lamp;
        public static bool Q_Alarm_Lamp;
        public static bool Q_OK_Lamp;
        public static bool Q_Valf_Durum;
        public static bool Output_6;
        public static bool Output_7;
        //Ref Parmeters
        public static string Ref_Name;
        public static string Ref_Desc;
        public static string Ref_Desc1;
        public static string Ref_Desc2;
        public static string Ref_Desc3;
        public static string Ref_Desc4;
        public static string Ref_Desc5;
        public static string Ref_Val1;
        public static string Ref_Val2;
        public static string Ref_Val3;
        public static string Ref_Val4;
        public static string Ref_Val5;
        //DM
        public static string DM_IP;
        public static int DM_Port;
        public static string DM_No;
        public static string DM_Status;






    }
}
