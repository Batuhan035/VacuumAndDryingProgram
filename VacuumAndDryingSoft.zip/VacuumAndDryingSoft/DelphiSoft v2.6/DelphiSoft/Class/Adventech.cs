﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//Adventech
using Automation.BDaq;
//BitArray
using System.Collections;
using System.Timers;

namespace DelphiSoft
{

    public class Adventech
    {
        //Create DI Control
        InstantDiCtrl instantDiCtrl = new InstantDiCtrl();
        //Create DO Control
        InstantDoCtrl instantDoCtrl = new InstantDoCtrl();
        //DI variables
        private byte portDataDI;
        private bool[] DI = new bool[8];
        //DI variables
        private byte portDataDO;
        private bool[] DO = new bool[8];



    
        public string Connect_Adventech()
        {
            string Connect_Status;
            try
            {
                instantDiCtrl.SelectedDevice = new DeviceInformation(GLB.Adventech_Name);
                instantDoCtrl.SelectedDevice = new DeviceInformation(GLB.Adventech_Name);
                Connect_Status = "OK";
            }
            catch (Exception err)
            {

                Connect_Status = err.ToString();
                System.Windows.Forms.MessageBox.Show(err.ToString(),"Adventech Baglanti Hatasi",System.Windows.Forms.MessageBoxButtons.OKCancel,System.Windows.Forms.MessageBoxIcon.Information);
            }
            return Connect_Status;
        }
       
        public void Adventech_DI()
        {
            // Read DI port
            HandleError(instantDiCtrl.Read(0, out portDataDI));
            //Convert Int to bool
            for (int i = 0; i < 8; i++)
            {
                DI[i] = ((portDataDI >> i) & 1) == 1;
            }
            //Input
            if (GLB.Sim_Active=="true")
            {
                GLB.I_Part_Presence = GLB.Sim_I_Part_Presence;
                GLB.I_Tag_Sensor = GLB.Sim_I_Tag_Sensor;
                GLB.I_Alarm_Reset = GLB.Sim_I_Alarm_Reset;
                GLB.I_Cycle_Start = GLB.Sim_I_Cycle_Start;
                GLB.I_Auto = GLB.Sim_I_Auto;
                GLB.I_Emergency_Stop = GLB.Sim_I_Emergency_Stop;
                GLB.I_Termik_Ikaz = GLB.Sim_I_Termik_Ikaz;
                GLB.I_OilTank = GLB.Sim_I_OilTank;
            }
            else
            { 
            GLB.I_Part_Presence = DI[0];
            GLB.I_Tag_Sensor = DI[1];
            GLB.I_Alarm_Reset = DI[2];
            GLB.I_Cycle_Start = DI[3];
            GLB.I_Auto = DI[4];
            GLB.I_Emergency_Stop = DI[5];
            GLB.I_Termik_Ikaz= DI[6];
            GLB.I_OilTank = DI[7];
            }
        }

        public void Adventech_DO()
        {
         
            //Output
            DO[0] = GLB.Q_Vacuum_Start;
            DO[1] = GLB.Q_Blow_Start;
            DO[2] = GLB.Q_Tag_Read_Lamp;
            DO[3] = GLB.Q_Alarm_Lamp;
            DO[4] = GLB.Q_OK_Lamp;
            DO[5] = GLB.Q_Valf_Durum;
            DO[6] = GLB.Output_6;
            DO[7] = GLB.Output_7;

            BitArray bits = new BitArray(DO);
            byte[] DOByte = new byte[1];
            bits.CopyTo(DOByte, 0);

            // Write port values to DO port
            HandleError(instantDoCtrl.Write(0, DOByte[0]));

        }
             
        public void HandleError(ErrorCode err)
        {
            if (err != ErrorCode.Success)
            {
                //System.Windows.Forms.MessageBox.Show("Haberleseme koptu! Error: " + err.ToString(), "Adventech IO");
                GLB.Step = 1007;

            }
            else
            {
                if(GLB.Step==1007)
                {
                    GLB.Step = 1008;
                }
            }
          
        }

    }
}
