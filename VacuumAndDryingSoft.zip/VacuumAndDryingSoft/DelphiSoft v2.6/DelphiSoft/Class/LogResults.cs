﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

//Text Write
using System.IO;


namespace DelphiSoft
{
    public class LogResults
    {
      
        public void Send_Log(String Log_Info,String Log_Error)
        {
            DateTime dt = DateTime.Now;
            string csv_path = System.IO.Directory.GetCurrentDirectory() + @"\Results\" + dt.Year.ToString() + @"\" + dt.Month.ToString() + @"\" + dt.ToString("dd/MM/yyyy") + @".txt";
            
            // Results Directory
            if (!Directory.Exists(System.IO.Directory.GetCurrentDirectory() + @"\Results"))
            {
                Directory.CreateDirectory(System.IO.Directory.GetCurrentDirectory() + @"\Results\");
            }
            // Year Directory
            if (!Directory.Exists(System.IO.Directory.GetCurrentDirectory() + @"\Results\" + dt.Year.ToString())) 
            {
                Directory.CreateDirectory(System.IO.Directory.GetCurrentDirectory() + @"\Results\" + dt.Year.ToString());
            }
            // Month Directory
            if (!Directory.Exists(System.IO.Directory.GetCurrentDirectory() + @"\Results\" + dt.Year.ToString() + @"\" + dt.Month.ToString())) 
            {
                Directory.CreateDirectory(System.IO.Directory.GetCurrentDirectory() + @"\Results\" + dt.Year.ToString() + @"\" + dt.Month.ToString());
            }
            //File Directory
            if (!File.Exists(csv_path))
            {
                //Create path and close
                FileStream fs = File.Create(csv_path);
                fs.Close();
                //Open file,write captions and close
                StreamWriter cp = File.AppendText(csv_path);
                string cp_string = "Tarih;Saat;Kullanici Adi;Referans Tipi;Aciklama;Hata;Cycle Step";
                cp.WriteLine(cp_string);
                cp.Close();

            }
            //Write to log file
            StreamWriter oFile = File.AppendText(csv_path);
            oFile.WriteLine(String.Format("{0:dd/MM/yyyy}", dt) + ";" + dt.TimeOfDay + ";" + GLB.UserName + ";" + "Reference" + ";" + Log_Info + ";" + Log_Error+ ";" + 0);
            oFile.Close();
        }
    }
}
